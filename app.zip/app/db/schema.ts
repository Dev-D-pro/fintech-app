import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  decimal,
  bigint,
  boolean,
  json,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).unique(),
  email: varchar("email", { length: 320 }).unique(),
  name: varchar("name", { length: 255 }),
  phone: varchar("phone", { length: 20 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  tier: mysqlEnum("tier", ["tier1", "tier2", "tier3"]).default("tier1").notNull(),
  kycStatus: mysqlEnum("kycStatus", ["pending", "submitted", "verified", "rejected"]).default("pending").notNull(),
  bvn: varchar("bvn", { length: 11 }),
  nin: varchar("nin", { length: 20 }),
  dateOfBirth: varchar("dateOfBirth", { length: 20 }),
  address: text("address"),
  googleId: varchar("googleId", { length: 255 }).unique(),
  emailVerified: boolean("emailVerified").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export const wallets = mysqlTable("wallets", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  balance: decimal("balance", { precision: 15, scale: 2 }).default("0.00").notNull(),
  owealthBalance: decimal("owealthBalance", { precision: 15, scale: 2 }).default("0.00").notNull(),
  currency: varchar("currency", { length: 3 }).default("NGN").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export const transactions = mysqlTable("transactions", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  type: mysqlEnum("type", [
    "deposit",
    "transfer_out",
    "transfer_in",
    "withdrawal",
    "airtime",
    "data",
    "bill_payment",
    "card_funding",
    "savings",
    "interest",
    "bonus",
    "refund",
    "other",
  ]).notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  fee: decimal("fee", { precision: 15, scale: 2 }).default("0.00").notNull(),
  totalAmount: decimal("totalAmount", { precision: 15, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "successful", "failed", "reversed"]).default("pending").notNull(),
  reference: varchar("reference", { length: 255 }).notNull().unique(),
  paystackRef: varchar("paystackRef", { length: 255 }),
  recipientName: varchar("recipientName", { length: 255 }),
  recipientAccount: varchar("recipientAccount", { length: 255 }),
  recipientBank: varchar("recipientBank", { length: 255 }),
  recipientBankCode: varchar("recipientBankCode", { length: 20 }),
  description: text("description"),
  category: mysqlEnum("category", ["transfer", "deposit", "withdrawal", "airtime", "data", "bills", "savings", "other"]).default("other").notNull(),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export const savingsGoals = mysqlTable("savingsGoals", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["owealth", "targets", "safebox", "fixed"]).notNull(),
  targetAmount: decimal("targetAmount", { precision: 15, scale: 2 }),
  currentAmount: decimal("currentAmount", { precision: 15, scale: 2 }).default("0.00").notNull(),
  interestRate: decimal("interestRate", { precision: 5, scale: 2 }),
  maturityDate: timestamp("maturityDate"),
  autoSave: boolean("autoSave").default(false),
  autoSaveAmount: decimal("autoSaveAmount", { precision: 15, scale: 2 }),
  autoSaveFrequency: mysqlEnum("autoSaveFrequency", ["daily", "weekly", "monthly"]),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export const cards = mysqlTable("cards", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  cardType: mysqlEnum("cardType", ["virtual", "physical"]).notNull(),
  cardBrand: mysqlEnum("cardBrand", ["verve", "visa", "mastercard"]).default("verve").notNull(),
  cardName: varchar("cardName", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["active", "inactive", "frozen", "pending", "expired"]).default("pending").notNull(),
  maskedPan: varchar("maskedPan", { length: 20 }),
  expiryMonth: varchar("expiryMonth", { length: 2 }),
  expiryYear: varchar("expiryYear", { length: 4 }),
  paystackAuthorizationCode: varchar("paystackAuthorizationCode", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export const bankAccounts = mysqlTable("bankAccounts", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  bankName: varchar("bankName", { length: 255 }).notNull(),
  bankCode: varchar("bankCode", { length: 20 }).notNull(),
  accountNumber: varchar("accountNumber", { length: 20 }).notNull(),
  accountName: varchar("accountName", { length: 255 }).notNull(),
  isDefault: boolean("isDefault").default(false),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const beneficiaries = mysqlTable("beneficiaries", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  accountNumber: varchar("accountNumber", { length: 20 }).notNull(),
  bankCode: varchar("bankCode", { length: 20 }).notNull(),
  bankName: varchar("bankName", { length: 255 }).notNull(),
  isFavorite: boolean("isFavorite").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const kycDocuments = mysqlTable("kycDocuments", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  type: mysqlEnum("type", ["bvn", "nin", "passport", "drivers_license", "voters_card", "utility_bill"]).notNull(),
  documentNumber: varchar("documentNumber", { length: 255 }),
  documentUrl: text("documentUrl"),
  status: mysqlEnum("status", ["submitted", "verified", "rejected"]).default("submitted").notNull(),
  reviewNotes: text("reviewNotes"),
  reviewedBy: bigint("reviewedBy", { mode: "number", unsigned: true }),
  reviewedAt: timestamp("reviewedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const notifications = mysqlTable("notifications", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  type: mysqlEnum("type", ["transaction", "promo", "security", "system", "savings", "kyc"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  isRead: boolean("isRead").default(false),
  actionUrl: varchar("actionUrl", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const airtimePurchases = mysqlTable("airtimePurchases", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  phoneNumber: varchar("phoneNumber", { length: 20 }).notNull(),
  network: mysqlEnum("network", ["mtn", "airtel", "glo", "9mobile"]).notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  cashback: decimal("cashback", { precision: 15, scale: 2 }).default("0.00"),
  status: mysqlEnum("status", ["pending", "successful", "failed"]).default("pending").notNull(),
  reference: varchar("reference", { length: 255 }).notNull().unique(),
  apiResponse: json("apiResponse"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const billsPayments = mysqlTable("billsPayments", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  biller: varchar("biller", { length: 255 }).notNull(),
  billerCode: varchar("billerCode", { length: 50 }).notNull(),
  product: varchar("product", { length: 255 }).notNull(),
  customerId: varchar("customerId", { length: 255 }).notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "successful", "failed"]).default("pending").notNull(),
  reference: varchar("reference", { length: 255 }).notNull().unique(),
  apiResponse: json("apiResponse"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const paystackTransactions = mysqlTable("paystackTransactions", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  reference: varchar("reference", { length: 255 }).notNull().unique(),
  paystackRef: varchar("paystackRef", { length: 255 }),
  authorizationUrl: text("authorizationUrl"),
  accessCode: varchar("accessCode", { length: 255 }),
  status: mysqlEnum("status", ["pending", "success", "failed"]).default("pending").notNull(),
  metadata: json("metadata"),
  verifiedAt: timestamp("verifiedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const virtualAccounts = mysqlTable("virtualAccounts", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull().unique(),
  customerCode: varchar("customerCode", { length: 255 }).notNull(),
  accountNumber: varchar("accountNumber", { length: 20 }).notNull(),
  bankName: varchar("bankName", { length: 255 }).notNull(),
  bankSlug: varchar("bankSlug", { length: 50 }).notNull(),
  active: boolean("active").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const dataPurchases = mysqlTable("dataPurchases", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  phoneNumber: varchar("phoneNumber", { length: 20 }).notNull(),
  network: mysqlEnum("network", ["mtn", "airtel", "glo", "9mobile"]).notNull(),
  planName: varchar("planName", { length: 255 }).notNull(),
  planCode: varchar("planCode", { length: 50 }).notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "successful", "failed"]).default("pending").notNull(),
  reference: varchar("reference", { length: 255 }).notNull().unique(),
  apiResponse: json("apiResponse"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Wallet = typeof wallets.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type SavingsGoal = typeof savingsGoals.$inferSelect;
export type Card = typeof cards.$inferSelect;
export type BankAccount = typeof bankAccounts.$inferSelect;
export type Beneficiary = typeof beneficiaries.$inferSelect;
export type KycDocument = typeof kycDocuments.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type AirtimePurchase = typeof airtimePurchases.$inferSelect;
export type BillsPayment = typeof billsPayments.$inferSelect;
export type PaystackTransaction = typeof paystackTransactions.$inferSelect;
export type VirtualAccount = typeof virtualAccounts.$inferSelect;
export type DataPurchase = typeof dataPurchases.$inferSelect;
