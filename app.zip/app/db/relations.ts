import { relations } from "drizzle-orm";
import {
  users,
  wallets,
  transactions,
  savingsGoals,
  cards,
  bankAccounts,
  beneficiaries,
  kycDocuments,
  notifications,
  airtimePurchases,
  billsPayments,
  paystackTransactions,
  virtualAccounts,
  dataPurchases,
} from "./schema";

export const usersRelations = relations(users, ({ one, many }) => ({
  wallet: one(wallets, {
    fields: [users.id],
    references: [wallets.userId],
  }),
  transactions: many(transactions),
  savingsGoals: many(savingsGoals),
  cards: many(cards),
  bankAccounts: many(bankAccounts),
  beneficiaries: many(beneficiaries),
  kycDocuments: many(kycDocuments),
  notifications: many(notifications),
  airtimePurchases: many(airtimePurchases),
  billsPayments: many(billsPayments),
  paystackTransactions: many(paystackTransactions),
  virtualAccount: one(virtualAccounts, {
    fields: [users.id],
    references: [virtualAccounts.userId],
  }),
  dataPurchases: many(dataPurchases),
}));

export const walletsRelations = relations(wallets, ({ one }) => ({
  user: one(users, {
    fields: [wallets.userId],
    references: [users.id],
  }),
}));

export const transactionsRelations = relations(transactions, ({ one }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id],
  }),
}));

export const savingsGoalsRelations = relations(savingsGoals, ({ one }) => ({
  user: one(users, {
    fields: [savingsGoals.userId],
    references: [users.id],
  }),
}));

export const cardsRelations = relations(cards, ({ one }) => ({
  user: one(users, {
    fields: [cards.userId],
    references: [users.id],
  }),
}));

export const bankAccountsRelations = relations(bankAccounts, ({ one }) => ({
  user: one(users, {
    fields: [bankAccounts.userId],
    references: [users.id],
  }),
}));

export const beneficiariesRelations = relations(beneficiaries, ({ one }) => ({
  user: one(users, {
    fields: [beneficiaries.userId],
    references: [users.id],
  }),
}));

export const kycDocumentsRelations = relations(kycDocuments, ({ one }) => ({
  user: one(users, {
    fields: [kycDocuments.userId],
    references: [users.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
}));

export const airtimePurchasesRelations = relations(airtimePurchases, ({ one }) => ({
  user: one(users, {
    fields: [airtimePurchases.userId],
    references: [users.id],
  }),
}));

export const billsPaymentsRelations = relations(billsPayments, ({ one }) => ({
  user: one(users, {
    fields: [billsPayments.userId],
    references: [users.id],
  }),
}));

export const paystackTransactionsRelations = relations(paystackTransactions, ({ one }) => ({
  user: one(users, {
    fields: [paystackTransactions.userId],
    references: [users.id],
  }),
}));

export const virtualAccountsRelations = relations(virtualAccounts, ({ one }) => ({
  user: one(users, {
    fields: [virtualAccounts.userId],
    references: [users.id],
  }),
}));

export const dataPurchasesRelations = relations(dataPurchases, ({ one }) => ({
  user: one(users, {
    fields: [dataPurchases.userId],
    references: [users.id],
  }),
}));
