import { MobileLayout } from "@/components/MobileLayout"
import { trpc } from "@/providers/trpc"
import { useState } from "react"
import { Link, useNavigate } from "react-router"
import { ArrowLeft, ArrowUpRight, ArrowDownLeft, Download, ChevronDown, Gift, Wifi, Receipt, Smartphone } from "lucide-react"
import { cn } from "@/lib/utils"

export default function Transactions() {
  const navigate = useNavigate()
  const [category] = useState("all")
  const [status] = useState("all")
  const [showFilters, setShowFilters] = useState(false)
  const [offset, setOffset] = useState(0)

  const { data } = trpc.wallet.getTransactions.useQuery({
    limit: 20,
    offset,
    category: category !== "all" ? category : undefined,
    status: status !== "all" ? status : undefined,
  })



  const getIcon = (type: string) => {
    switch (type) {
      case "transfer_in": return ArrowDownLeft
      case "transfer_out": return ArrowUpRight
      case "airtime": return Smartphone
      case "data": return Wifi
      case "bill_payment": return Receipt
      case "bonus": return Gift
      default: return ArrowUpRight
    }
  }

  // Group transactions by month
  const grouped: Record<string, any[]> = {}
  const txList = data?.transactions || []
  for (const tx of txList) {
    const date = new Date(tx.createdAt)
    const key = `${date.toLocaleString("default", { month: "long" })} ${date.getFullYear()}`
    if (!grouped[key]) grouped[key] = []
    grouped[key].push(tx)
  }

  return (
    <MobileLayout hideNav>
      <div className="bg-white min-h-screen">
        <div className="flex items-center gap-3 px-4 py-3 border-b">
          <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5" /></button>
          <h1 className="font-semibold">Transactions</h1>
          <button className="ml-auto text-sm text-emerald-600 flex items-center gap-1">
            <Download className="w-4 h-4" /> Download
          </button>
        </div>

        {/* Filters */}
        <div className="flex gap-2 p-3 border-b">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-1 px-3 py-2 border rounded-lg text-sm"
          >
            {category === "all" ? "All Categories" : category} <ChevronDown className="w-3 h-3" />
          </button>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-1 px-3 py-2 border rounded-lg text-sm"
          >
            {status === "all" ? "All Status" : status} <ChevronDown className="w-3 h-3" />
          </button>
        </div>

        {/* Monthly Summary */}
        {data?.monthlyStats && (
          <div className="px-4 py-3 bg-gray-50 flex items-center justify-between">
            <div className="text-sm">
              <span className="text-emerald-600">In: ₦{data.monthlyStats.in.toLocaleString()}</span>
              <span className="mx-2 text-gray-300">|</span>
              <span className="text-red-500">Out: ₦{data.monthlyStats.out.toLocaleString()}</span>
            </div>
          </div>
        )}

        {/* Transaction List */}
        <div className="divide-y">
          {Object.entries(grouped).map(([month, txs]) => (
            <div key={month}>
              <div className="px-4 py-2 bg-gray-50 sticky top-0">
                <p className="text-xs font-semibold text-gray-600">{month}</p>
              </div>
              {txs.map((tx) => {
                const Icon = getIcon(tx.type)
                return (
                  <Link
                    key={tx.id}
                    to={`/transactions/${tx.id}`}
                    className="flex items-center gap-3 px-4 py-3 hover:bg-gray-50"
                  >
                    <div className={cn(
                      "w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0",
                      tx.type === "transfer_in" || tx.type === "deposit" || tx.type === "bonus"
                        ? "bg-emerald-50 text-emerald-600"
                        : "bg-red-50 text-red-600"
                    )}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 truncate">
                        {tx.description || tx.type}
                      </p>
                      <p className="text-[10px] text-gray-400">
                        {new Date(tx.createdAt).toLocaleString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className={cn(
                        "text-sm font-semibold",
                        tx.type === "transfer_in" || tx.type === "deposit" || tx.type === "bonus"
                          ? "text-emerald-600"
                          : "text-gray-800"
                      )}>
                        {tx.type === "transfer_in" || tx.type === "deposit" || tx.type === "bonus" ? "+" : "-"}
                        ₦{parseFloat(tx.amount).toLocaleString()}
                      </p>
                      <p className="text-[10px] text-emerald-500">{tx.status}</p>
                    </div>
                  </Link>
                )
              })}
            </div>
          ))}

          {(!data?.transactions || data.transactions.length === 0) && (
            <div className="text-center py-12 text-gray-400">
              <p>No transactions found</p>
            </div>
          )}
        </div>

        {/* Load More */}
        {data && data.total > offset + 20 && (
          <div className="p-4 text-center">
            <button
              onClick={() => setOffset(offset + 20)}
              className="text-sm text-emerald-600 font-medium"
            >
              Load More
            </button>
          </div>
        )}
      </div>
    </MobileLayout>
  )
}
