import { useState, useRef } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { ArrowLeft, User, Camera, Mail, Phone, MapPin, Calendar, Shield } from "lucide-react";

export default function Profile() {
  const navigate = useNavigate();
  const { user } = useAuth({ redirectOnUnauthenticated: true });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [name, setName] = useState(user?.name || "");
  const [phone, setPhone] = useState(user?.phone || "");
  const [address, setAddress] = useState(user?.address || "");
  const [dateOfBirth, setDateOfBirth] = useState(user?.dateOfBirth || "");
  const [isSaving, setIsSaving] = useState(false);

  const { data: profile, refetch } = trpc.auth.getUserProfile.useQuery(undefined, {
    enabled: !!user,
  });

  const updateProfile = trpc.auth.updateProfile.useMutation({
    onSuccess: () => {
      toast.success("Profile updated successfully");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Update failed");
      setIsSaving(false);
    },
  });

  const updateAvatar = trpc.auth.updateProfile.useMutation({
    onSuccess: () => {
      toast.success("Photo updated");
      refetch();
    },
  });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    updateProfile.mutate({
      name: name || undefined,
      phone: phone || undefined,
      address: address || undefined,
      // dateOfBirth: dateOfBirth || undefined,
    });
    setIsSaving(false);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      if (base64) {
        updateAvatar.mutate({ avatar: base64 });
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-emerald-600 text-white px-4 py-4 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-1 rounded-full hover:bg-white/20">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">Profile</h1>
      </div>

      <div className="p-4 space-y-4">
        {/* Photo Upload */}
        <div className="flex flex-col items-center">
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-emerald-100 flex items-center justify-center overflow-hidden border-4 border-white shadow-lg">
              {profile?.avatar ? (
                <img src={profile.avatar} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <User className="w-10 h-10 text-emerald-600" />
              )}
            </div>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="absolute bottom-0 right-0 w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center text-white shadow-md hover:bg-emerald-700 transition"
            >
              <Camera className="w-4 h-4" />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handlePhotoUpload}
              className="hidden"
            />
          </div>
          <h2 className="mt-3 font-semibold text-lg">{profile?.name || user?.name || "User"}</h2>
          <p className="text-sm text-gray-500">{profile?.email || user?.email || ""}</p>
          <div className="mt-2 inline-flex items-center gap-1 px-3 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs font-medium">
            <Shield className="w-3 h-3" />
            {(profile?.tier || "tier1").toUpperCase()}
          </div>
        </div>

        {/* Profile Form */}
        <form onSubmit={handleSave} className="space-y-4">
          <Card>
            <CardContent className="p-4 space-y-3">
              <h3 className="font-semibold">Personal Information</h3>

              <div>
                <Label className="flex items-center gap-1"><User className="w-3 h-3" /> Full Name</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your full name" />
              </div>

              <div>
                <Label className="flex items-center gap-1"><Phone className="w-3 h-3" /> Phone Number</Label>
                <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="08012345678" />
              </div>

              <div>
                <Label className="flex items-center gap-1"><Mail className="w-3 h-3" /> Email</Label>
                <Input value={profile?.email || user?.email || ""} disabled className="bg-gray-50" />
              </div>

              <div>
                <Label className="flex items-center gap-1"><Calendar className="w-3 h-3" /> Date of Birth</Label>
                <Input
                  type="date"
                  value={dateOfBirth}
                  onChange={(e) => setDateOfBirth(e.target.value)}
                />
              </div>

              <div>
                <Label className="flex items-center gap-1"><MapPin className="w-3 h-3" /> Address</Label>
                <Input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Your address" />
              </div>
            </CardContent>
          </Card>

          <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700" disabled={isSaving}>
            {isSaving ? "Saving..." : "Save Changes"}
          </Button>
        </form>

        {/* Stats */}
        <Card>
          <CardContent className="p-4">
            <h3 className="font-semibold mb-3">Account Stats</h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-gray-50 rounded-lg p-3 text-center">
                <p className="text-xs text-gray-500">KYC Status</p>
                <p className="font-semibold text-sm capitalize">{(profile?.kycStatus || "pending")}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3 text-center">
                <p className="text-xs text-gray-500">Member Since</p>
                <p className="font-semibold text-sm">
                  {profile?.createdAt ? new Date(profile.createdAt).toLocaleDateString("en-NG", { month: "short", year: "numeric" }) : "N/A"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
