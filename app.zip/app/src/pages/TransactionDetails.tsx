import { MobileLayout } from "@/components/MobileLayout"
import { trpc } from "@/providers/trpc"
import { useParams, useNavigate, Link } from "react-router"
import { ArrowLeft, Copy, Share2, AlertCircle, CheckCircle, ArrowRightLeft, Clock } from "lucide-react"
import { useState } from "react"
import { cn } from "@/lib/utils"

export default function TransactionDetails() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const [copied, setCopied] = useState(false)

  const { data: tx } = trpc.wallet.getTransactionById.useQuery(
    { id: parseInt(id || "0") },
    { enabled: !!id }
  )

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  if (!tx) {
    return (
      <MobileLayout hideNav>
        <div className="flex items-center justify-center h-screen">
          <p className="text-gray-400">Loading...</p>
        </div>
      </MobileLayout>
    )
  }

  return (
    <MobileLayout hideNav>
      <div className="bg-white min-h-screen">
        <div className="flex items-center gap-3 px-4 py-3 border-b">
          <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5" /></button>
          <h1 className="font-semibold">Transaction Details</h1>
        </div>

        {/* Header */}
        <div className="text-center py-6">
          <div className={cn(
            "w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3",
            tx.status === "successful" ? "bg-emerald-100" : tx.status === "pending" ? "bg-amber-100" : "bg-red-100"
          )}>
            {tx.status === "successful" ? (
              <CheckCircle className="w-8 h-8 text-emerald-600" />
            ) : tx.status === "pending" ? (
              <Clock className="w-8 h-8 text-amber-600" />
            ) : (
              <AlertCircle className="w-8 h-8 text-red-600" />
            )}
          </div>
          <p className="text-sm text-gray-500 mb-1">{tx.description}</p>
          <p className="text-3xl font-bold text-gray-800">
            {tx.type === "transfer_in" || tx.type === "deposit" || tx.type === "bonus" ? "+" : "-"}
            ₦{parseFloat(tx.amount).toLocaleString()}
          </p>
          <p className={cn(
            "text-sm font-medium mt-1",
            tx.status === "successful" ? "text-emerald-600" : tx.status === "pending" ? "text-amber-600" : "text-red-600"
          )}>
            {tx.status}
          </p>
        </div>

        {/* Details */}
        <div className="mx-4 border rounded-xl divide-y">
          <div className="flex justify-between p-3">
            <span className="text-sm text-gray-500">Transaction Type</span>
            <span className="text-sm font-medium capitalize">{tx.type.replace("_", " ")}</span>
          </div>
          {tx.recipientName && (
            <div className="flex justify-between p-3">
              <span className="text-sm text-gray-500">Recipient</span>
              <span className="text-sm font-medium">{tx.recipientName}</span>
            </div>
          )}
          {tx.recipientAccount && (
            <div className="flex justify-between p-3">
              <span className="text-sm text-gray-500">Account</span>
              <span className="text-sm font-medium">{tx.recipientAccount}</span>
            </div>
          )}
          {tx.recipientBank && (
            <div className="flex justify-between p-3">
              <span className="text-sm text-gray-500">Bank</span>
              <span className="text-sm font-medium">{tx.recipientBank}</span>
            </div>
          )}
          <div className="flex justify-between p-3">
            <span className="text-sm text-gray-500">Amount</span>
            <span className="text-sm font-medium">₦{parseFloat(tx.amount).toLocaleString()}</span>
          </div>
          <div className="flex justify-between p-3">
            <span className="text-sm text-gray-500">Fee</span>
            <span className="text-sm font-medium">₦{parseFloat(tx.fee).toLocaleString()}</span>
          </div>
          <div className="flex justify-between p-3">
            <span className="text-sm text-gray-500">Reference</span>
            <button
              onClick={() => handleCopy(tx.reference)}
              className="text-sm font-medium flex items-center gap-1"
            >
              {tx.reference.slice(0, 20)}... <Copy className="w-3 h-3" />
            </button>
          </div>
          <div className="flex justify-between p-3">
            <span className="text-sm text-gray-500">Date</span>
            <span className="text-sm font-medium">{new Date(tx.createdAt).toLocaleString()}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 p-4 mt-4">
          <Link
            to="/transfer/bank"
            className="flex-1 py-3 rounded-full border border-emerald-600 text-emerald-600 font-semibold text-center flex items-center justify-center gap-2"
          >
            <ArrowRightLeft className="w-4 h-4" /> Transfer Again
          </Link>
          <button
            onClick={() => {
              if (navigator.share) {
                navigator.share({
                  title: "Transaction Receipt",
                  text: `${tx.description}: ₦${parseFloat(tx.amount).toLocaleString()} - ${tx.status}`,
                })
              }
            }}
            className="flex-1 py-3 rounded-full bg-emerald-600 text-white font-semibold text-center flex items-center justify-center gap-2"
          >
            <Share2 className="w-4 h-4" /> Share Receipt
          </button>
        </div>

        {copied && (
          <div className="fixed bottom-20 left-1/2 -translate-x-1/2 bg-gray-800 text-white px-4 py-2 rounded-lg text-sm">
            Copied to clipboard
          </div>
        )}
      </div>
    </MobileLayout>
  )
}
