import { MobileLayout } from "@/components/MobileLayout"
import { useNavigate } from "react-router"
import { ArrowLeft, MessageCircle, Phone, Mail } from "lucide-react"

const FAQS = [
  { q: "How do I fund my wallet?", a: "You can fund your wallet via bank transfer or Paystack payment." },
  { q: "What is the transfer limit?", a: "Transfer limits depend on your KYC tier. Tier 1: ₦50k/day, Tier 2: ₦200k/day, Tier 3: ₦5M/day." },
  { q: "How do I upgrade my tier?", a: "Submit your BVN and NIN in the KYC section to upgrade your account tier." },
  { q: "Is my money safe?", a: "Yes, we use bank-grade encryption and are fully licensed by the CBN." },
]

export default function Help() {
  const navigate = useNavigate()

  return (
    <MobileLayout hideNav>
      <div className="bg-white min-h-screen">
        <div className="flex items-center gap-3 px-4 py-3 border-b">
          <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5" /></button>
          <h1 className="font-semibold">Help & Support</h1>
        </div>

        <div className="p-4 space-y-4">
          <div className="grid grid-cols-3 gap-3">
            {[
              { icon: MessageCircle, label: "Chat" },
              { icon: Phone, label: "Call" },
              { icon: Mail, label: "Email" },
            ].map((item) => {
              const Icon = item.icon
              return (
                <button key={item.label} className="flex flex-col items-center gap-2 p-3 border rounded-xl hover:bg-gray-50">
                  <Icon className="w-6 h-6 text-emerald-600" />
                  <span className="text-xs font-medium">{item.label}</span>
                </button>
              )
            })}
          </div>

          <h3 className="font-semibold text-sm">Frequently Asked Questions</h3>
          <div className="space-y-2">
            {FAQS.map((faq, i) => (
              <div key={i} className="border rounded-xl p-3">
                <p className="text-sm font-medium mb-1">{faq.q}</p>
                <p className="text-xs text-gray-500">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </MobileLayout>
  )
}
