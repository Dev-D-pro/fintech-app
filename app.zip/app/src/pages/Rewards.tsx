import { MobileLayout } from "@/components/MobileLayout"
import { Link, useNavigate } from "react-router"
import { ArrowLeft, Gift, Share2, Star, Ticket } from "lucide-react"
import { useState } from "react"
import { cn } from "@/lib/utils"

export default function Rewards() {
  const navigate = useNavigate()
  const [tab, setTab] = useState<"hot" | "betting">("hot")

  return (
    <MobileLayout>
      <div className="bg-white min-h-screen">
        <div className="flex items-center gap-3 px-4 py-3 border-b">
          <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5" /></button>
          <h1 className="font-semibold">Rewards</h1>
        </div>

        <div className="p-4 space-y-4">
          {/* Cashback & Vouchers */}
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-gray-400">Cashback</p>
              <p className="text-xl font-bold">₦26.00</p>
            </div>
            <div>
              <p className="text-xs text-gray-400">Voucher</p>
              <p className="text-xl font-bold">2</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-4 gap-2">
            {[
              { icon: Gift, label: "Friday Bonus" },
              { icon: Share2, label: "Refer Friends" },
              { icon: Star, label: "Play4aChild" },
              { icon: Ticket, label: "Voucher Pack" },
            ].map((item) => {
              const Icon = item.icon
              return (
                <div key={item.label} className="flex flex-col items-center gap-1 p-2">
                  <div className="w-12 h-12 rounded-xl bg-emerald-50 flex items-center justify-center">
                    <Icon className="w-6 h-6 text-emerald-600" />
                  </div>
                  <span className="text-[10px] text-center font-medium">{item.label}</span>
                </div>
              )
            })}
          </div>

          {/* Vouchers */}
          <div>
            <h3 className="font-semibold text-sm mb-3">Hot Vouchers</h3>
            <div className="flex gap-2 mb-3">
              <button
                onClick={() => setTab("hot")}
                className={cn("px-3 py-1 rounded-full text-xs font-medium", tab === "hot" ? "bg-red-100 text-red-600" : "bg-gray-100")}
              >
                Hot
              </button>
              <button
                onClick={() => setTab("betting")}
                className={cn("px-3 py-1 rounded-full text-xs font-medium", tab === "betting" ? "bg-gray-800 text-white" : "bg-gray-100")}
              >
                Betting
              </button>
            </div>

            <div className="bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-xl p-4 text-white">
              <p className="text-2xl font-bold">₦30</p>
              <p className="text-sm">Betting Voucher</p>
              <p className="text-xs text-emerald-100 mt-1">₦300 available</p>
              <button className="mt-3 px-4 py-1.5 bg-white text-emerald-600 rounded-full text-xs font-semibold">
                Use
              </button>
            </div>
          </div>

          {/* Daily Bonus */}
          <div>
            <h3 className="font-semibold text-sm mb-3">Daily Bonus</h3>
            {[
              { name: "Glo Airtime", cashback: "6%" },
              { name: "9 Mobile Airtime", cashback: "5%" },
            ].map((item) => (
              <div key={item.name} className="flex items-center justify-between p-3 border rounded-xl mb-2">
                <div>
                  <p className="text-sm font-medium">{item.name}</p>
                  <p className="text-xs text-gray-400">Buy Airtime and get up to {item.cashback} Cashback</p>
                </div>
                <Link to="/airtime" className="px-3 py-1.5 bg-emerald-600 text-white rounded-full text-xs font-medium">
                  Go
                </Link>
              </div>
            ))}
          </div>
        </div>
      </div>
    </MobileLayout>
  )
}
