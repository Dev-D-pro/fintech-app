import { MobileLayout } from "@/components/MobileLayout"
import { trpc } from "@/providers/trpc"
import { useNavigate } from "react-router"
import { ArrowLeft, Award, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

export default function AccountLimits() {
  const navigate = useNavigate()
  const { data } = trpc.kyc.getStatus.useQuery()

  const tiers = [
    { id: "tier1", name: "Tier 1", daily: 50000, max: 300000 },
    { id: "tier2", name: "Tier 2", daily: 200000, max: 500000 },
    { id: "tier3", name: "Tier 3", daily: 5000000, max: -1 },
  ]

  return (
    <MobileLayout hideNav>
      <div className="bg-white min-h-screen">
        <div className="flex items-center gap-3 px-4 py-3 border-b">
          <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5" /></button>
          <h1 className="font-semibold">Account Limits</h1>
        </div>

        <div className="p-4 space-y-4">
          {/* User Card */}
          <div className="bg-gray-100 rounded-xl p-4 flex items-center justify-between">
            <div>
              <p className="text-lg font-bold">{data?.bvn || "703 166 8278"}</p>
              <p className="text-xs text-gray-500">{data?.documents?.[0]?.documentNumber || "DAUDA SAEED"}</p>
            </div>
            <div className="flex items-center gap-1 bg-emerald-100 px-2 py-1 rounded-full">
              <Award className="w-4 h-4 text-emerald-600" />
              <span className="text-xs text-emerald-600 font-medium">{data?.tier?.replace("tier", "") || "2"}</span>
            </div>
          </div>

          {/* Tier Table */}
          <div className="border rounded-xl overflow-hidden">
            <div className="grid grid-cols-3 gap-2 p-3 bg-gray-50 text-xs font-medium text-gray-500">
              <span>Tier</span>
              <span className="text-center">Daily Limit</span>
              <span className="text-right">Max Balance</span>
            </div>
            {tiers.map((tier) => (
              <div
                key={tier.id}
                className={cn(
                  "grid grid-cols-3 gap-2 p-3 border-t",
                  data?.tier === tier.id ? "bg-emerald-50" : ""
                )}
              >
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{tier.name}</span>
                  {data?.tier === tier.id && (
                    <span className="text-[10px] bg-emerald-100 text-emerald-600 px-1.5 rounded">Current</span>
                  )}
                  {tier.id === "tier3" && data?.tier !== "tier3" && (
                    <span className="text-[10px] bg-amber-100 text-amber-600 px-1.5 rounded">Up Next</span>
                  )}
                </div>
                <span className="text-center text-sm">₦{tier.daily.toLocaleString()}</span>
                <span className="text-right text-sm">{tier.max === -1 ? "Unlimited" : `₦${tier.max.toLocaleString()}`}</span>
              </div>
            ))}
          </div>

          <button className="w-full py-3.5 rounded-full font-semibold bg-emerald-600 text-white flex items-center justify-center gap-2">
            View Tier 3 Progress <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </MobileLayout>
  )
}
