import { MobileLayout } from "@/components/MobileLayout"
import { trpc } from "@/providers/trpc"
import { useState } from "react"
import { Link, useNavigate } from "react-router"
import { ArrowLeft, ChevronRight, Search, X, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"

const POPULAR_BANKS = [
  { name: "OPay", code: "999992" },
  { name: "Access Bank", code: "044" },
  { name: "United Bank For Africa", code: "033" },
  { name: "First Bank Of Nigeria", code: "011" },
  { name: "Guaranty Trust Bank", code: "058" },
  { name: "Zenith Bank", code: "057" },
]

export default function TransferBank() {
  const navigate = useNavigate()
  const [step, setStep] = useState<"account" | "amount" | "confirm">("account")
  const [accountNumber, setAccountNumber] = useState("")
  const [selectedBank, setSelectedBank] = useState<{name: string; code: string} | null>(null)
  const [accountName, setAccountName] = useState("")
  const [amount, setAmount] = useState("")
  const [description, setDescription] = useState("")
  const [showBankList, setShowBankList] = useState(false)
  const [searchBank, setSearchBank] = useState("")
  const [error, setError] = useState("")

  const { data: banks } = trpc.paystack.getBanks.useQuery()
  const verifyMutation = trpc.paystack.verifyAccount.useMutation()
  const transferMutation = trpc.paystack.bankTransfer.useMutation()

  const filteredBanks = (banks || []).filter((b: {name: string; code: string}) =>
    b.name.toLowerCase().includes(searchBank.toLowerCase())
  )

  const handleVerify = async () => {
    if (accountNumber.length !== 10 || !selectedBank) return
    setError("")
    try {
      const result = await verifyMutation.mutateAsync({
        accountNumber,
        bankCode: selectedBank.code,
      })
      if (result.success && result.accountName) {
        setAccountName(result.accountName)
        setStep("amount")
      }
    } catch (e: any) {
      setError(e.message || "Verification failed")
    }
  }

  const handleTransfer = async () => {
    const amt = parseFloat(amount)
    if (isNaN(amt) || amt < 10) {
      setError("Enter a valid amount")
      return
    }
    setError("")
    setStep("confirm")
  }

  const confirmTransfer = async () => {
    try {
      const result = await transferMutation.mutateAsync({
        bankCode: selectedBank!.code,
        bankName: selectedBank!.name,
        accountNumber,
        accountName,
        amount: parseFloat(amount),
        description,
        saveAsBeneficiary: false,
      })
      if (result.success) {
        navigate(`/transactions?ref=${result.reference}`)
      }
    } catch (e: any) {
      setError(e.message || "Transfer failed")
      setStep("amount")
    }
  }

  return (
    <MobileLayout hideNav>
      <div className="bg-white min-h-screen">
        {/* Header */}
        <div className="flex items-center gap-3 px-4 py-3 border-b">
          <button onClick={() => step === "account" ? navigate(-1) : setStep(step === "confirm" ? "amount" : "account")}>
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-semibold">Transfer to Bank</h1>
          <Link to="/transactions" className="ml-auto text-sm text-emerald-600">History</Link>
        </div>

        {error && (
          <div className="mx-4 mt-3 p-3 bg-red-50 rounded-lg flex items-center gap-2 text-red-600 text-sm">
            <AlertCircle className="w-4 h-4" /> {error}
          </div>
        )}

        {step === "account" && (
          <div className="p-4 space-y-4">
            <div>
              <label className="text-sm text-gray-500 mb-1 block">Account Number</label>
              <input
                type="text"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, ""))}
                maxLength={10}
                placeholder="Enter 10 digits account number"
                className="w-full p-3 border rounded-xl text-lg font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="text-sm text-gray-500 mb-1 block">Bank</label>
              <button
                onClick={() => setShowBankList(true)}
                className="w-full p-3 border rounded-xl text-left flex items-center justify-between hover:border-emerald-400"
              >
                <span className={selectedBank ? "font-medium" : "text-gray-400"}>
                  {selectedBank?.name || "Select Bank"}
                </span>
                <ChevronRight className="w-4 h-4 text-gray-400" />
              </button>
            </div>

            {/* Popular Banks */}
            <div className="grid grid-cols-3 gap-2">
              {POPULAR_BANKS.map((bank) => (
                <button
                  key={bank.code}
                  onClick={() => setSelectedBank(bank)}
                  className={cn(
                    "p-2 rounded-xl border text-center text-xs font-medium transition-colors",
                    selectedBank?.code === bank.code
                      ? "border-emerald-500 bg-emerald-50 text-emerald-700"
                      : "border-gray-200 hover:border-emerald-300"
                  )}
                >
                  {bank.name}
                </button>
              ))}
            </div>

            <button
              onClick={handleVerify}
              disabled={accountNumber.length !== 10 || !selectedBank || verifyMutation.isPending}
              className={cn(
                "w-full py-3.5 rounded-full font-semibold text-white transition-all",
                accountNumber.length === 10 && selectedBank
                  ? "bg-emerald-600 hover:bg-emerald-700"
                  : "bg-gray-300 cursor-not-allowed"
              )}
            >
              {verifyMutation.isPending ? "Verifying..." : "Next"}
            </button>
          </div>
        )}

        {step === "amount" && (
          <div className="p-4 space-y-4">
            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-sm text-gray-500">Recipient</p>
              <p className="font-semibold text-lg">{accountName}</p>
              <p className="text-sm text-gray-400">{accountNumber} · {selectedBank?.name}</p>
            </div>

            <div>
              <label className="text-sm text-gray-500 mb-1 block">Amount</label>
              <div className="flex items-center border rounded-xl px-3">
                <span className="text-2xl font-bold text-gray-800 mr-2">&#8358;</span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full py-3 text-2xl font-bold focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {["500", "1000", "2000", "5000", "10000", "50000"].map((amt) => (
                <button
                  key={amt}
                  onClick={() => setAmount(amt)}
                  className="py-2 border rounded-lg text-sm font-medium hover:border-emerald-400 hover:bg-emerald-50"
                >
                  &#8358;{parseInt(amt).toLocaleString()}
                </button>
              ))}
            </div>

            <div>
              <label className="text-sm text-gray-500 mb-1 block">Remark (Optional)</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What's this for?"
                className="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <button
              onClick={handleTransfer}
              disabled={!amount || parseFloat(amount) < 10}
              className={cn(
                "w-full py-3.5 rounded-full font-semibold text-white transition-all",
                amount && parseFloat(amount) >= 10
                  ? "bg-emerald-600 hover:bg-emerald-700"
                  : "bg-gray-300 cursor-not-allowed"
              )}
            >
              Continue
            </button>
          </div>
        )}

        {step === "confirm" && (
          <div className="p-4 space-y-4">
            <div className="bg-emerald-50 rounded-xl p-4 text-center">
              <p className="text-sm text-emerald-600 mb-2">You are about to send</p>
              <p className="text-3xl font-bold text-gray-800">&#8358;{parseFloat(amount).toLocaleString()}</p>
            </div>

            <div className="bg-white border rounded-xl divide-y">
              <div className="flex justify-between p-3">
                <span className="text-sm text-gray-500">Recipient</span>
                <span className="text-sm font-medium text-right">{accountName}</span>
              </div>
              <div className="flex justify-between p-3">
                <span className="text-sm text-gray-500">Account</span>
                <span className="text-sm font-medium">{accountNumber}</span>
              </div>
              <div className="flex justify-between p-3">
                <span className="text-sm text-gray-500">Bank</span>
                <span className="text-sm font-medium">{selectedBank?.name}</span>
              </div>
              <div className="flex justify-between p-3">
                <span className="text-sm text-gray-500">Amount</span>
                <span className="text-sm font-medium">&#8358;{parseFloat(amount).toLocaleString()}</span>
              </div>
              <div className="flex justify-between p-3">
                <span className="text-sm text-gray-500">Fee</span>
                <span className="text-sm font-medium text-emerald-600">&#8358;0.00</span>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setStep("amount")}
                className="flex-1 py-3.5 rounded-full font-semibold border border-emerald-600 text-emerald-600"
              >
                Recheck
              </button>
              <button
                onClick={confirmTransfer}
                disabled={transferMutation.isPending}
                className="flex-1 py-3.5 rounded-full font-semibold bg-emerald-600 text-white hover:bg-emerald-700 disabled:opacity-50"
              >
                {transferMutation.isPending ? "Processing..." : "Confirm"}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Bank List Modal */}
      {showBankList && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
          <div className="bg-white w-full max-w-md mx-auto rounded-t-2xl max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="font-semibold">Select Bank</h2>
              <button onClick={() => setShowBankList(false)}>
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  value={searchBank}
                  onChange={(e) => setSearchBank(e.target.value)}
                  placeholder="Search bank name"
                  className="w-full pl-9 pr-3 py-2.5 bg-gray-100 rounded-xl text-sm focus:outline-none"
                />
              </div>
            </div>
            <div className="overflow-y-auto flex-1">
              {filteredBanks.map((bank: {name: string; code: string; id?: number}) => (
                <button
                  key={bank.code}
                  onClick={() => {
                    setSelectedBank({ name: bank.name, code: bank.code })
                    setShowBankList(false)
                  }}
                  className="w-full text-left px-4 py-3 hover:bg-gray-50 border-b border-gray-50 flex items-center justify-between"
                >
                  <span className="font-medium">{bank.name}</span>
                  {selectedBank?.code === bank.code && (
                    <div className="w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center">
                      <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </MobileLayout>
  )
}
