import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { ArrowLeft, Landmark, Copy, Check, Plus, Loader2 } from "lucide-react";

export default function Funding() {
  const navigate = useNavigate();
  const { user } = useAuth({ redirectOnUnauthenticated: true });
  const [copied, setCopied] = useState(false);
  const [showPaystack, setShowPaystack] = useState(false);
  const [amount, setAmount] = useState("");

  const { data: virtualAccount, refetch } = trpc.paystack.getVirtualAccount.useQuery(undefined, {
    enabled: !!user,
  });

  const createVA = trpc.paystack.createVirtualAccount.useMutation({
    onSuccess: (_data) => {
      toast.success("Virtual account created!");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to create virtual account");
    },
  });

  const initPayment = trpc.paystack.initializePayment.useMutation({
    onSuccess: (data) => {
      if (data.authorizationUrl) {
        window.location.href = data.authorizationUrl;
      }
    },
    onError: (error) => toast.error(error.message),
  });

  const copyAccount = () => {
    if (virtualAccount?.accountNumber) {
      navigator.clipboard.writeText(virtualAccount.accountNumber);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast.success("Account number copied!");
    }
  };

  const handlePaystack = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(amount);
    if (!amountNum || amountNum < 50) {
      toast.error("Minimum amount is ₦50");
      return;
    }
    initPayment.mutate({ amount: amountNum });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-emerald-600 text-white px-4 py-4 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-1 rounded-full hover:bg-white/20">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">Fund Account</h1>
      </div>

      <div className="p-4 space-y-4">
        {/* Virtual Account */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-4">
              <Landmark className="w-5 h-5 text-emerald-600" />
              <h3 className="font-semibold">Bank Transfer (Virtual Account)</h3>
            </div>

            {virtualAccount ? (
              <div className="text-center space-y-3">
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4">
                  <p className="text-sm text-gray-500 mb-1">Bank Name</p>
                  <p className="font-semibold text-lg">{virtualAccount.bankName}</p>
                </div>

                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <p className="text-sm text-gray-500 mb-1">Account Number</p>
                  <div className="flex items-center justify-center gap-2">
                    <p className="text-2xl font-bold font-mono tracking-wider">
                      {virtualAccount.accountNumber}
                    </p>
                    <button
                      onClick={copyAccount}
                      className="p-2 rounded-full hover:bg-gray-200 transition"
                    >
                      {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <p className="text-sm text-gray-500 mb-1">Account Name</p>
                  <p className="font-semibold">NairaFlow / {user?.name || "User"}</p>
                </div>

                <p className="text-xs text-gray-500">
                  Transfer to this account to fund your wallet instantly
                </p>
              </div>
            ) : (
              <div className="text-center py-6">
                <p className="text-gray-500 mb-3">No virtual account yet</p>
                <Button
                  onClick={() => createVA.mutate()}
                  disabled={createVA.isPending}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  {createVA.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Plus className="w-4 h-4 mr-1" />}
                  Create Virtual Account
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Paystack Card Payment */}
        <Card>
          <CardContent className="p-4">
            <h3 className="font-semibold mb-3">Pay with Card (Paystack)</h3>

            {showPaystack ? (
              <form onSubmit={handlePaystack} className="space-y-3">
                <div>
                  <label className="text-sm text-gray-500">Amount (₦)</label>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="1000"
                    className="w-full border rounded-md p-2"
                    min="50"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full bg-emerald-600 hover:bg-emerald-700"
                  disabled={initPayment.isPending}
                >
                  {initPayment.isPending ? "Processing..." : "Pay with Card"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => setShowPaystack(false)}
                >
                  Cancel
                </Button>
              </form>
            ) : (
              <Button
                onClick={() => setShowPaystack(true)}
                variant="outline"
                className="w-full"
              >
                Pay with Debit/Credit Card
              </Button>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
