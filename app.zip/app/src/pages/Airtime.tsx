import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ArrowLeft, Smartphone, Zap } from "lucide-react";

export default function Airtime() {
  const navigate = useNavigate();
  const { user } = useAuth({ redirectOnUnauthenticated: true });
  const [phoneNumber, setPhoneNumber] = useState("");
  const [amount, setAmount] = useState("");
  const [selectedNetwork, setSelectedNetwork] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const { data: walletData } = trpc.wallet.getBalance.useQuery(undefined, { enabled: !!user });
  const { data: networks } = trpc.airtime.getNetworks.useQuery(undefined, { enabled: !!user });
  const { data: history } = trpc.airtime.getHistory.useQuery(
    { limit: 5, offset: 0 },
    { enabled: !!user }
  );

  const purchase = trpc.airtime.purchase.useMutation({
    onSuccess: (data) => {
      setIsLoading(false);
      toast.success(`Airtime purchased! Cashback: ₦${data.cashback}`);
      setPhoneNumber("");
      setAmount("");
      setSelectedNetwork(null);
    },
    onError: (error) => {
      setIsLoading(false);
      toast.error(error.message || "Purchase failed");
    },
  });

  const handlePurchase = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(amount);
    if (!phoneNumber || !amountNum || !selectedNetwork) {
      toast.error("Please fill all fields");
      return;
    }
    if (amountNum > parseFloat(walletData?.balance || "0")) {
      toast.error("Insufficient balance");
      return;
    }
    setIsLoading(true);
    purchase.mutate({
      phoneNumber,
      network: selectedNetwork as any,
      amount: amountNum,
    });
  };

  const quickAmounts = [100, 200, 500, 1000, 2000, 5000];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-emerald-600 text-white px-4 py-4 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-1 rounded-full hover:bg-white/20">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">Buy Airtime</h1>
      </div>

      <div className="p-4 space-y-4">
        {/* Network Selection */}
        <div>
          <Label>Select Network</Label>
          <div className="grid grid-cols-4 gap-2 mt-2">
            {networks?.map((network: any) => (
              <button
                key={network.code}
                onClick={() => setSelectedNetwork(network.code)}
                className={`flex flex-col items-center gap-1 p-3 rounded-lg border transition ${
                  selectedNetwork === network.code
                    ? "border-emerald-500 bg-emerald-50"
                    : "border-gray-200 bg-white hover:border-gray-300"
                }`}
              >
                <img
                  src={network.logo}
                  alt={network.name}
                  className="w-8 h-8 object-contain"
                  onError={(e) => {
                    e.currentTarget.style.display = "none";
                    e.currentTarget.nextElementSibling?.classList.remove("hidden");
                  }}
                />
                <span className={`text-[10px] font-medium hidden`}>{network.name[0]}</span>
                <span className="text-[10px] font-medium">{network.name}</span>
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={handlePurchase} className="space-y-4">
          <div>
            <Label>Phone Number</Label>
            <Input
              type="tel"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              placeholder="08012345678"
              maxLength={11}
            />
          </div>

          <div>
            <Label>Amount (₦)</Label>
            <Input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount"
            />
            <div className="flex gap-2 mt-2 flex-wrap">
              {quickAmounts.map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setAmount(amt.toString())}
                  className={`px-3 py-1 rounded-full text-xs font-medium border transition ${
                    amount === amt.toString()
                      ? "bg-emerald-600 text-white border-emerald-600"
                      : "bg-white text-gray-600 border-gray-200 hover:border-emerald-400"
                  }`}
                >
                  ₦{amt}
                </button>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Available: ₦{parseFloat(walletData?.balance || "0").toLocaleString("en-NG", { minimumFractionDigits: 2 })}
            </p>
          </div>

          <Button
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-700"
            disabled={isLoading || !selectedNetwork}
          >
            {isLoading ? "Processing..." : <><Zap className="w-4 h-4 mr-1" /> Buy Airtime</>}
          </Button>
        </form>

        {/* Recent History */}
        {history && history.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold text-sm">Recent Purchases</h3>
              <button onClick={() => navigate("/transactions")} className="text-xs text-emerald-600">
                See All
              </button>
            </div>
            <div className="space-y-2">
              {history.map((item: any) => (
                <div key={item.id} className="flex items-center justify-between p-2 bg-white rounded-lg">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-gray-400" />
                    <div>
                      <p className="text-sm font-medium">{item.phoneNumber}</p>
                      <p className="text-[10px] text-gray-500 capitalize">{item.network}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold">₦{parseFloat(item.amount).toLocaleString()}</p>
                    <p className={`text-[10px] ${item.status === "successful" ? "text-emerald-500" : "text-red-500"}`}>
                      {item.status}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
