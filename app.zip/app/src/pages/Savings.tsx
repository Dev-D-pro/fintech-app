import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { ArrowLeft, PiggyBank, Plus, Trash2, ArrowUpRight, ArrowDownLeft } from "lucide-react";

export default function Savings() {
  const navigate = useNavigate();
  const { user } = useAuth({ redirectOnUnauthenticated: true });
  const [showCreate, setShowCreate] = useState(false);
  const [goalName, setGoalName] = useState("");
  const [goalType, setGoalType] = useState("targets");
  const [targetAmount, setTargetAmount] = useState("");
  const [depositAmount, setDepositAmount] = useState("");
  const [selectedGoal, setSelectedGoal] = useState<any>(null);

  const { data: goals, refetch } = trpc.savings.getGoals.useQuery(undefined, { enabled: !!user });
  const { data: stats } = trpc.savings.getStats.useQuery(undefined, { enabled: !!user });
  // const { data: walletData } = trpc.wallet.getBalance.useQuery(undefined, { enabled: !!user });

  const createGoal = trpc.savings.createGoal.useMutation({
    onSuccess: () => {
      toast.success("Savings goal created!");
      setShowCreate(false);
      setGoalName("");
      setTargetAmount("");
      refetch();
    },
    onError: (error) => toast.error(error.message),
  });

  const deposit = trpc.savings.deposit.useMutation({
    onSuccess: (_data) => {
      toast.success(`Deposited ₦${depositAmount}`);
      setDepositAmount("");
      setSelectedGoal(null);
      refetch();
    },
    onError: (error) => toast.error(error.message),
  });

  // const withdraw = trpc.savings.withdraw.useMutation({
  //   onSuccess: () => {
  //     toast.success("Withdrawal successful");
  //     setDepositAmount("");
  //     setSelectedGoal(null);
  //     refetch();
  //   },
  //   onError: (error) => toast.error(error.message),
  // });

  const deleteGoal = trpc.savings.deleteGoal.useMutation({
    onSuccess: () => {
      toast.success("Goal removed");
      refetch();
    },
    onError: (error) => toast.error(error.message),
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalName || !targetAmount) {
      toast.error("Please fill all fields");
      return;
    }
    createGoal.mutate({
      name: goalName,
      type: goalType as any,
      targetAmount: parseFloat(targetAmount),
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-emerald-600 text-white px-4 py-4 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-1 rounded-full hover:bg-white/20">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">Savings</h1>
        <button
          onClick={() => setShowCreate(!showCreate)}
          className="ml-auto p-1.5 rounded-full bg-white/20 hover:bg-white/30"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      <div className="p-4 space-y-4">
        {/* Stats */}
        <div className="grid grid-cols-2 gap-3">
          <Card className="bg-emerald-50 border-emerald-200">
            <CardContent className="p-4">
              <p className="text-xs text-gray-500">Total Saved</p>
              <p className="text-xl font-bold text-emerald-700">
                ₦{(stats?.totalSaved || 0).toLocaleString("en-NG", { minimumFractionDigits: 2 })}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <p className="text-xs text-gray-500">Active Goals</p>
              <p className="text-xl font-bold">{stats?.activeGoals || 0}</p>
            </CardContent>
          </Card>
        </div>

        {/* Create Goal Form */}
        {showCreate && (
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold mb-3">Create Savings Goal</h3>
              <form onSubmit={handleCreate} className="space-y-3">
                <div>
                  <Label>Goal Name</Label>
                  <Input value={goalName} onChange={(e) => setGoalName(e.target.value)} placeholder="e.g. New Laptop" />
                </div>
                <div>
                  <Label>Type</Label>
                  <select
                    value={goalType}
                    onChange={(e) => setGoalType(e.target.value)}
                    className="w-full border rounded-md p-2 text-sm"
                  >
                    <option value="owealth">Owealth</option>
                    <option value="targets">Targets</option>
                    <option value="safebox">Safebox</option>
                    <option value="fixed">Fixed</option>
                  </select>
                </div>
                <div>
                  <Label>Target Amount (₦)</Label>
                  <Input
                    type="number"
                    value={targetAmount}
                    onChange={(e) => setTargetAmount(e.target.value)}
                    placeholder="50000"
                  />
                </div>
                <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700">
                  Create Goal
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Goals List */}
        <div className="space-y-3">
          {goals?.map((goal: any) => (
            <Card key={goal.id} className="overflow-hidden">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center">
                      <PiggyBank className="w-5 h-5 text-emerald-600" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{goal.name}</p>
                      <p className="text-[10px] text-gray-500 capitalize">{goal.type}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => deleteGoal.mutate({ id: goal.id })}
                    className="p-1.5 rounded-full hover:bg-red-100 text-red-500 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Progress */}
                {goal.targetAmount && (
                  <div className="mb-3">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span>Progress</span>
                      <span>
                        ₦{parseFloat(goal.currentAmount).toLocaleString()} / ₦{parseFloat(goal.targetAmount).toLocaleString()}
                      </span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-500 rounded-full transition-all"
                        style={{
                          width: `${Math.min(100, (parseFloat(goal.currentAmount) / parseFloat(goal.targetAmount)) * 100)}%`,
                        }}
                      />
                    </div>
                  </div>
                )}

                <div className="flex gap-2">
                  {selectedGoal?.id === goal.id ? (
                    <div className="flex gap-2 flex-1">
                      <Input
                        type="number"
                        value={depositAmount}
                        onChange={(e) => setDepositAmount(e.target.value)}
                        placeholder="Amount"
                        className="flex-1"
                      />
                      <Button
                        size="sm"
                        className="bg-emerald-600"
                        onClick={() => deposit.mutate({ goalId: goal.id, amount: parseFloat(depositAmount) })}
                        disabled={!depositAmount}
                      >
                        <ArrowUpRight className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setDepositAmount("");
                          setSelectedGoal(null);
                        }}
                      >
                        Cancel
                      </Button>
                    </div>
                  ) : (
                    <>
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1"
                        onClick={() => setSelectedGoal(goal)}
                      >
                        <ArrowUpRight className="w-3 h-3 mr-1" /> Deposit
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1"
                        onClick={() => {
                          setSelectedGoal(goal);
                          setDepositAmount("");
                        }}
                      >
                        <ArrowDownLeft className="w-3 h-3 mr-1" /> Withdraw
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {(!goals || goals.length === 0) && !showCreate && (
          <div className="text-center py-12 text-gray-500">
            <PiggyBank className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>No savings goals yet</p>
            <Button onClick={() => setShowCreate(true)} className="mt-3 bg-emerald-600">
              Create Goal
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
