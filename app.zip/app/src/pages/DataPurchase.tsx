import { MobileLayout } from "@/components/MobileLayout"
import { useState } from "react"
import { useNavigate } from "react-router"
import { ArrowLeft, Wifi, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"

const NETWORKS = [
  { id: "mtn", name: "MTN", color: "bg-yellow-400", plans: [
    { name: "500MB", price: 150, validity: "1 Day" },
    { name: "1GB", price: 300, validity: "1 Day" },
    { name: "2GB", price: 600, validity: "7 Days" },
    { name: "3GB", price: 1000, validity: "30 Days" },
    { name: "5GB", price: 1500, validity: "30 Days" },
    { name: "10GB", price: 3000, validity: "30 Days" },
  ]},
  { id: "airtel", name: "Airtel", color: "bg-red-500", plans: [
    { name: "500MB", price: 150, validity: "1 Day" },
    { name: "1.5GB", price: 500, validity: "7 Days" },
    { name: "3GB", price: 1000, validity: "30 Days" },
    { name: "6GB", price: 1500, validity: "30 Days" },
    { name: "10GB", price: 2500, validity: "30 Days" },
    { name: "20GB", price: 5000, validity: "30 Days" },
  ]},
  { id: "glo", name: "GLO", color: "bg-green-500", plans: [
    { name: "1GB", price: 200, validity: "1 Day" },
    { name: "2.5GB", price: 500, validity: "7 Days" },
    { name: "5.8GB", price: 1000, validity: "30 Days" },
    { name: "7.7GB", price: 1500, validity: "30 Days" },
    { name: "10GB", price: 2000, validity: "30 Days" },
    { name: "18GB", price: 4000, validity: "30 Days" },
  ]},
  { id: "9mobile", name: "9mobile", color: "bg-teal-500", plans: [
    { name: "500MB", price: 150, validity: "1 Day" },
    { name: "1GB", price: 350, validity: "7 Days" },
    { name: "2.5GB", price: 800, validity: "30 Days" },
    { name: "4GB", price: 1200, validity: "30 Days" },
    { name: "7GB", price: 2000, validity: "30 Days" },
    { name: "12GB", price: 3500, validity: "30 Days" },
  ]},
]

export default function DataPurchase() {
  const navigate = useNavigate()
  const [network, setNetwork] = useState("mtn")
  const [phone, setPhone] = useState("")
  const [selectedPlan, setSelectedPlan] = useState<{name: string; price: number; validity: string} | null>(null)
  const [error, setError] = useState("")

  const currentNetwork = NETWORKS.find(n => n.id === network)

  const handlePurchase = async () => {
    if (!selectedPlan) {
      setError("Select a data plan")
      return
    }
    if (phone.length < 10) {
      setError("Enter a valid phone number")
      return
    }
    setError("")
    // Simulate data purchase - in real app would call API
    navigate(`/transactions`)
  }

  return (
    <MobileLayout hideNav>
      <div className="bg-white min-h-screen">
        <div className="flex items-center gap-3 px-4 py-3 border-b">
          <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5" /></button>
          <h1 className="font-semibold">Data Purchase</h1>
        </div>

        {error && (
          <div className="mx-4 mt-3 p-3 bg-red-50 rounded-lg flex items-center gap-2 text-red-600 text-sm">
            <AlertCircle className="w-4 h-4" /> {error}
          </div>
        )}

        <div className="p-4 space-y-4">
          {/* Network Selection */}
          <div className="grid grid-cols-4 gap-2">
            {NETWORKS.map((n) => (
              <button
                key={n.id}
                onClick={() => { setNetwork(n.id); setSelectedPlan(null) }}
                className={cn(
                  "p-3 rounded-xl border-2 flex flex-col items-center gap-1 transition-all",
                  network === n.id ? "border-emerald-500 bg-emerald-50" : "border-gray-100"
                )}
              >
                <div className={cn("w-8 h-8 rounded-full", n.color)} />
                <span className="text-xs font-medium">{n.name}</span>
              </button>
            ))}
          </div>

          {/* Phone Number */}
          <div>
            <label className="text-sm text-gray-500 mb-1 block">Phone Number</label>
            <div className="flex items-center border rounded-xl px-3">
              <Wifi className="w-5 h-5 text-gray-400 mr-2" />
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, ""))}
                maxLength={11}
                placeholder="08012345678"
                className="w-full py-3 text-lg font-medium focus:outline-none"
              />
            </div>
          </div>

          {/* Plans */}
          <div>
            <label className="text-sm text-gray-500 mb-2 block">Select Plan</label>
            <div className="grid grid-cols-2 gap-2">
              {currentNetwork?.plans.map((plan) => (
                <button
                  key={plan.name}
                  onClick={() => setSelectedPlan(plan)}
                  className={cn(
                    "p-3 rounded-xl border-2 text-left transition-all",
                    selectedPlan?.name === plan.name ? "border-emerald-500 bg-emerald-50" : "border-gray-100"
                  )}
                >
                  <p className="font-semibold text-sm">{plan.name}</p>
                  <p className="text-emerald-600 font-bold">&#8358;{plan.price}</p>
                  <p className="text-xs text-gray-400">{plan.validity}</p>
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handlePurchase}
            disabled={!selectedPlan || phone.length < 10}
            className={cn(
              "w-full py-3.5 rounded-full font-semibold text-white transition-all",
              selectedPlan && phone.length >= 10
                ? "bg-emerald-600 hover:bg-emerald-700"
                : "bg-gray-300 cursor-not-allowed"
            )}
          >
            Pay &#8358;{selectedPlan?.price || 0}
          </button>
        </div>
      </div>
    </MobileLayout>
  )
}
