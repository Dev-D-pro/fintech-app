import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Eye, EyeOff, Send, Plus, Smartphone, Receipt, CreditCard, PiggyBank, ChevronRight, Bell, User, ArrowUpRight, ArrowDownLeft, Shield } from "lucide-react";

export default function Dashboard() {
  const navigate = useNavigate();
  const { user, isLoading: authLoading } = useAuth({ redirectOnUnauthenticated: true });
  const [showBalance, setShowBalance] = useState(true);

  const { data: walletData, isLoading: walletLoading } = trpc.wallet.getBalance.useQuery(undefined, {
    enabled: !!user,
    staleTime: 30000,
  });

  const { data: txData, isLoading: txLoading } = trpc.wallet.getTransactions.useQuery(
    { limit: 5, offset: 0 },
    { enabled: !!user, staleTime: 30000 }
  );

  const { data: unreadCount } = trpc.notification.getNotifications.useQuery(
    { limit: 1, offset: 0, unreadOnly: true },
    { enabled: !!user }
  );

  const isLoading = authLoading || walletLoading;
  const balance = walletData?.balance || "0.00";
  const owealthBalance = walletData?.owealthBalance || "0.00";

  const quickActions = [
    { icon: Send, label: "Transfer", path: "/transfer", color: "bg-emerald-500" },
    { icon: Plus, label: "Fund", path: "/funding", color: "bg-blue-500" },
    { icon: Smartphone, label: "Airtime", path: "/airtime", color: "bg-purple-500" },
    { icon: Receipt, label: "Bills", path: "/bills", color: "bg-orange-500" },
  ];

  const moreActions = [
    { icon: PiggyBank, label: "Savings", path: "/savings", color: "bg-emerald-600" },
    { icon: CreditCard, label: "Cards", path: "/cards", color: "bg-indigo-500" },
    { icon: ArrowUpRight, label: "Data", path: "/data", color: "bg-cyan-500" },
    { icon: Shield, label: "KYC", path: "/kyc", color: "bg-rose-500" },
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-emerald-600 text-white px-4 pt-4 pb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
              <User className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm opacity-80">Welcome back</p>
              <p className="font-semibold">{user?.name || "User"}</p>
            </div>
          </div>
          <button
            onClick={() => navigate("/notifications")}
            className="relative p-2 rounded-full bg-white/20 hover:bg-white/30 transition"
          >
            <Bell className="w-5 h-5" />
            {unreadCount && unreadCount.unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs flex items-center justify-center">
                {unreadCount.unreadCount}
              </span>
            )}
          </button>
        </div>

        {/* Balance Card */}
        <Card className="bg-emerald-700 border-0 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm opacity-80">Total Balance</span>
              <button
                onClick={() => setShowBalance(!showBalance)}
                className="p-1 rounded hover:bg-white/20 transition"
              >
                {showBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-2xl font-bold mb-1">
              {showBalance ? `₦${parseFloat(balance).toLocaleString("en-NG", { minimumFractionDigits: 2 })}` : "****"}
            </p>
            <div className="flex items-center justify-between mt-3">
              <div>
                <p className="text-xs opacity-70">Owealth Savings</p>
                <p className="text-sm font-semibold">
                  {showBalance ? `₦${parseFloat(owealthBalance).toLocaleString("en-NG", { minimumFractionDigits: 2 })}` : "****"}
                </p>
              </div>
              <Button
                size="sm"
                variant="secondary"
                className="bg-white/20 text-white hover:bg-white/30 border-0"
                onClick={() => navigate("/savings")}
              >
                View
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="px-4 -mt-3">
        <div className="grid grid-cols-4 gap-3">
          {quickActions.map((action) => (
            <button
              key={action.label}
              onClick={() => navigate(action.path)}
              className="flex flex-col items-center gap-2"
            >
              <div className={`w-12 h-12 rounded-xl ${action.color} text-white flex items-center justify-center shadow-lg`}>
                <action.icon className="w-5 h-5" />
              </div>
              <span className="text-xs font-medium text-gray-700">{action.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* More Actions */}
      <div className="px-4 mt-6">
        <div className="grid grid-cols-4 gap-3">
          {moreActions.map((action) => (
            <button
              key={action.label}
              onClick={() => navigate(action.path)}
              className="flex flex-col items-center gap-2"
            >
              <div className={`w-12 h-12 rounded-xl ${action.color} text-white flex items-center justify-center shadow-lg`}>
                <action.icon className="w-5 h-5" />
              </div>
              <span className="text-xs font-medium text-gray-700">{action.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="px-4 mt-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-gray-800">Recent Transactions</h3>
          <button
            onClick={() => navigate("/transactions")}
            className="text-sm text-emerald-600 flex items-center gap-1"
          >
            See All <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {txLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 bg-gray-100 rounded-lg animate-pulse"></div>
            ))}
          </div>
        ) : txData?.transactions && txData.transactions.length > 0 ? (
          <div className="space-y-2">
            {txData.transactions.map((tx: any) => (
              <button
                key={tx.id}
                onClick={() => navigate(`/transaction/${tx.id}`)}
                className="w-full flex items-center gap-3 p-3 bg-white rounded-lg shadow-sm hover:shadow-md transition text-left"
              >
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  ["deposit", "transfer_in", "interest", "bonus", "refund"].includes(tx.type)
                    ? "bg-emerald-100 text-emerald-600"
                    : "bg-red-100 text-red-600"
                }`}>
                  {["deposit", "transfer_in", "interest", "bonus", "refund"].includes(tx.type)
                    ? <ArrowDownLeft className="w-5 h-5" />
                    : <ArrowUpRight className="w-5 h-5" />
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{tx.description || tx.type}</p>
                  <p className="text-xs text-gray-500">{new Date(tx.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="text-right">
                  <p className={`font-semibold text-sm ${
                    ["deposit", "transfer_in", "interest", "bonus", "refund"].includes(tx.type)
                      ? "text-emerald-600"
                      : "text-red-600"
                  }`}>
                    {["deposit", "transfer_in", "interest", "bonus", "refund"].includes(tx.type) ? "+" : "-"}
                    ₦{parseFloat(tx.amount).toLocaleString("en-NG", { minimumFractionDigits: 2 })}
                  </p>
                  <p className="text-xs text-gray-400">{tx.status}</p>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <Receipt className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>No transactions yet</p>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2">
        <div className="flex items-center justify-around max-w-md mx-auto">
          <button onClick={() => navigate("/dashboard")} className="flex flex-col items-center gap-1 text-emerald-600">
            <div className="w-6 h-6 flex items-center justify-center"><span className="text-lg">🏠</span></div>
            <span className="text-[10px]">Home</span>
          </button>
          <button onClick={() => navigate("/transactions")} className="flex flex-col items-center gap-1 text-gray-400 hover:text-emerald-600">
            <div className="w-6 h-6 flex items-center justify-center"><Receipt className="w-5 h-5" /></div>
            <span className="text-[10px]">History</span>
          </button>
          <button onClick={() => navigate("/savings")} className="flex flex-col items-center gap-1 text-gray-400 hover:text-emerald-600">
            <div className="w-6 h-6 flex items-center justify-center"><PiggyBank className="w-5 h-5" /></div>
            <span className="text-[10px]">Finance</span>
          </button>
          <button onClick={() => navigate("/cards")} className="flex flex-col items-center gap-1 text-gray-400 hover:text-emerald-600">
            <div className="w-6 h-6 flex items-center justify-center"><CreditCard className="w-5 h-5" /></div>
            <span className="text-[10px]">Cards</span>
          </button>
          <button onClick={() => navigate("/profile")} className="flex flex-col items-center gap-1 text-gray-400 hover:text-emerald-600">
            <div className="w-6 h-6 flex items-center justify-center"><User className="w-5 h-5" /></div>
            <span className="text-[10px]">Me</span>
          </button>
        </div>
      </div>
    </div>
  );
}
