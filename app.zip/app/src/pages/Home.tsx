import { useNavigate } from "react-router";
import { Button } from "@/components/ui/button";
import { Shield, Zap, Smartphone } from "lucide-react";

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-emerald-600 text-white flex flex-col">
      {/* Hero */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 text-center">
        <div className="w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center mb-6">
          <Shield className="w-10 h-10" />
        </div>
        <h1 className="text-3xl font-bold mb-3">NairaFlow</h1>
        <p className="text-lg opacity-90 mb-2">Nigeria's Most Trusted</p>
        <p className="text-sm opacity-70 mb-8">Send money, pay bills, buy airtime & data, and save with confidence.</p>

        <div className="grid grid-cols-3 gap-4 mb-8 w-full max-w-xs">
          <div className="flex flex-col items-center gap-1">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
              <Zap className="w-5 h-5" />
            </div>
            <span className="text-[10px]">Instant</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
              <Shield className="w-5 h-5" />
            </div>
            <span className="text-[10px]">Secure</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
              <Smartphone className="w-5 h-5" />
            </div>
            <span className="text-[10px]">Easy</span>
          </div>
        </div>

        <Button
          onClick={() => navigate("/login")}
          className="w-full max-w-xs bg-white text-emerald-600 hover:bg-gray-100 font-semibold py-6"
        >
          Get Started
        </Button>
        <p className="mt-4 text-xs opacity-60">
          Licensed by CBN • Secured by Paystack
        </p>
      </div>
    </div>
  );
}
