import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, ArrowUpRight, ArrowDownLeft, Receipt, Filter } from "lucide-react";

export default function TransactionHistory() {
  const navigate = useNavigate();
  const { user } = useAuth({ redirectOnUnauthenticated: true });
  const [filter, setFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [offset, setOffset] = useState(0);
  const limit = 20;

  const { data, isLoading } = trpc.wallet.getTransactions.useQuery(
    {
      limit,
      offset,
      type: filter !== "all" ? filter : undefined,
      category: categoryFilter !== "all" ? categoryFilter : undefined,
    },
    { enabled: !!user }
  );

  const categories = [
    { value: "all", label: "All Categories" },
    { value: "transfer", label: "Transfers" },
    { value: "deposit", label: "Deposits" },
    { value: "airtime", label: "Airtime" },
    { value: "data", label: "Data" },
    { value: "bills", label: "Bills" },
    { value: "savings", label: "Savings" },
    { value: "withdrawal", label: "Withdrawals" },
    { value: "other", label: "Other" },
  ];

  const types = [
    { value: "all", label: "All Types" },
    { value: "transfer_out", label: "Transfer Out" },
    { value: "transfer_in", label: "Transfer In" },
    { value: "deposit", label: "Deposit" },
    { value: "airtime", label: "Airtime" },
    { value: "data", label: "Data" },
    { value: "bill_payment", label: "Bill Payment" },
    { value: "savings", label: "Savings" },
    { value: "withdrawal", label: "Withdrawal" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-emerald-600 text-white px-4 py-4 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-1 rounded-full hover:bg-white/20">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">Transaction History</h1>
      </div>

      {/* Filters */}
      <div className="px-4 py-3 flex gap-2">
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-[140px] text-xs">
            <Filter className="w-3 h-3 mr-1" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {categories.map((c) => (
              <SelectItem key={c.value} value={c.value} className="text-xs">{c.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-[140px] text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {types.map((t) => (
              <SelectItem key={t.value} value={t.value} className="text-xs">{t.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="px-4 pb-4 space-y-2">
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-16 bg-gray-100 rounded-lg animate-pulse"></div>
            ))}
          </div>
        ) : data?.transactions && data.transactions.length > 0 ? (
          <>
            <div className="text-xs text-gray-500 mb-2">
              Showing {data.transactions.length} of {data.total} transactions
            </div>
            {data.transactions.map((tx: any) => (
              <button
                key={tx.id}
                onClick={() => navigate(`/transaction/${tx.id}`)}
                className="w-full flex items-center gap-3 p-3 bg-white rounded-lg shadow-sm hover:shadow-md transition text-left"
              >
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  ["deposit", "transfer_in", "interest", "bonus", "refund"].includes(tx.type)
                    ? "bg-emerald-100 text-emerald-600"
                    : "bg-red-100 text-red-600"
                }`}>
                  {["deposit", "transfer_in", "interest", "bonus", "refund"].includes(tx.type)
                    ? <ArrowDownLeft className="w-5 h-5" />
                    : <ArrowUpRight className="w-5 h-5" />
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{tx.description || tx.type}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(tx.createdAt).toLocaleDateString("en-NG", {
                      day: "numeric",
                      month: "short",
                      year: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
                <div className="text-right">
                  <p className={`font-semibold text-sm ${
                    ["deposit", "transfer_in", "interest", "bonus", "refund"].includes(tx.type)
                      ? "text-emerald-600"
                      : "text-red-600"
                  }`}>
                    {["deposit", "transfer_in", "interest", "bonus", "refund"].includes(tx.type) ? "+" : "-"}
                    ₦{parseFloat(tx.amount).toLocaleString("en-NG", { minimumFractionDigits: 2 })}
                  </p>
                  <p className={`text-xs ${tx.status === "successful" ? "text-emerald-500" : tx.status === "pending" ? "text-yellow-500" : "text-red-500"}`}>
                    {tx.status}
                  </p>
                </div>
              </button>
            ))}

            {/* Pagination */}
            <div className="flex justify-center gap-2 pt-4">
              <Button
                variant="outline"
                size="sm"
                disabled={offset === 0}
                onClick={() => setOffset(Math.max(0, offset - limit))}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={!data || data.transactions.length < limit}
                onClick={() => setOffset(offset + limit)}
              >
                Next
              </Button>
            </div>
          </>
        ) : (
          <div className="text-center py-12 text-gray-500">
            <Receipt className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>No transactions found</p>
          </div>
        )}
      </div>
    </div>
  );
}
