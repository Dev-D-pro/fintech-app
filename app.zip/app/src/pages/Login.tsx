import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { Smartphone, Globe, ArrowLeft, Eye, EyeOff } from "lucide-react";

export default function Login() {
  const navigate = useNavigate();
  // const [searchParams] = useSearchParams();
  const { user } = useAuth();
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Redirect if already logged in
  if (user) {
    navigate("/dashboard", { replace: true });
    return null;
  }

  const redirectUri = typeof window !== "undefined"
    ? `${window.location.origin}/api/oauth/callback`
    : "http://localhost:3000/api/oauth/callback";

  const googleRedirectUri = typeof window !== "undefined"
    ? `${window.location.origin}/api/oauth/google/callback`
    : "http://localhost:3000/api/oauth/google/callback";

  const { data: kimiAuthUrl } = trpc.auth.getAuthUrl.useQuery({
    redirectUri,
    provider: "kimi",
  });

  const { data: googleAuthUrl } = trpc.auth.getAuthUrl.useQuery(
    { redirectUri: googleRedirectUri, provider: "google" },
    { enabled: !!process.env.VITE_GOOGLE_CLIENT_ID }
  );

  const handleKimiLogin = () => {
    if (kimiAuthUrl?.url) {
      window.location.href = kimiAuthUrl.url;
    }
  };

  const handleGoogleLogin = () => {
    if (googleAuthUrl?.url) {
      window.location.href = googleAuthUrl.url;
    }
  };

  const handlePhoneLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || !password) {
      toast.error("Please enter phone number and password");
      return;
    }
    setIsLoading(true);
    // Phone login would require a separate auth system
    // For now, just show a message to use OAuth
    toast.info("Please use Kimi or Google login for now");
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-emerald-600 text-white px-4 py-4 flex items-center gap-3">
        <button onClick={() => navigate("/")} className="p-1 rounded-full hover:bg-white/20 transition">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">Login to NairaFlow</h1>
      </div>

      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-xl">Welcome Back</CardTitle>
            <p className="text-sm text-gray-500">Sign in to access your account</p>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Phone Login Form */}
            <form onSubmit={handlePhoneLogin} className="space-y-3">
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="08012345678"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700" disabled={isLoading}>
                {isLoading ? "Signing in..." : "Sign In"}
              </Button>
            </form>

            <div className="flex items-center gap-3">
              <Separator className="flex-1" />
              <span className="text-xs text-gray-400">OR</span>
              <Separator className="flex-1" />
            </div>

            {/* OAuth Buttons */}
            <div className="space-y-2">
              <Button
                variant="outline"
                className="w-full flex items-center gap-2"
                onClick={handleKimiLogin}
                disabled={!kimiAuthUrl}
              >
                <Smartphone className="w-4 h-4" />
                Sign in with Kimi
              </Button>

              <Button
                variant="outline"
                className="w-full flex items-center gap-2 border-gray-300"
                onClick={handleGoogleLogin}
                disabled={!googleAuthUrl}
              >
                <Globe className="w-4 h-4" />
                Sign in with Google
              </Button>
            </div>

            <p className="text-center text-sm text-gray-500">
              Don't have an account?{" "}
              <button
                onClick={() => {
                  // Sign up also uses OAuth
                  toast.info("Click 'Sign in with Kimi' or 'Sign in with Google' to create an account");
                }}
                className="text-emerald-600 font-medium"
              >
                Sign Up
              </button>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
