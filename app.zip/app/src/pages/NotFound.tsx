import { useNavigate } from "react-router";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Home } from "lucide-react";

export default function NotFound() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-6xl font-bold text-emerald-600 mb-2">404</h1>
        <p className="text-lg text-gray-600 mb-6">Page not found</p>
        <div className="flex gap-2 justify-center">
          <Button variant="outline" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-4 h-4 mr-1" /> Go Back
          </Button>
          <Button className="bg-emerald-600" onClick={() => navigate("/dashboard")}>
            <Home className="w-4 h-4 mr-1" /> Dashboard
          </Button>
        </div>
      </div>
    </div>
  );
}
