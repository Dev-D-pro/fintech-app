import { MobileLayout } from "@/components/MobileLayout"
import { trpc } from "@/providers/trpc"
import { useState } from "react"
import { useNavigate } from "react-router"
import { ArrowLeft, AlertCircle } from "lucide-react"

export default function CardApply() {
  const navigate = useNavigate()
  const [cardName, setCardName] = useState("")
  const [error, setError] = useState("")

  const applyMutation = trpc.card.applyForCard.useMutation()

  const handleApply = async () => {
    if (!cardName.trim()) {
      setError("Enter card name")
      return
    }
    setError("")
    try {
      const result = await applyMutation.mutateAsync({
        cardType: "virtual",
        cardBrand: "verve",
        cardName,
      })
      if (result.success) {
        navigate("/cards")
      }
    } catch (e: any) {
      setError(e.message || "Application failed")
    }
  }

  return (
    <MobileLayout hideNav>
      <div className="bg-white min-h-screen">
        <div className="flex items-center gap-3 px-4 py-3 border-b">
          <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5" /></button>
          <h1 className="font-semibold">Apply for Card</h1>
        </div>

        {error && (
          <div className="mx-4 mt-3 p-3 bg-red-50 rounded-lg flex items-center gap-2 text-red-600 text-sm">
            <AlertCircle className="w-4 h-4" /> {error}
          </div>
        )}

        <div className="p-4 space-y-4">
          <div className="bg-gradient-to-r from-amber-400 to-amber-500 rounded-xl p-4 text-white shadow-lg">
            <div className="flex justify-between items-start mb-6">
              <span className="font-bold text-lg">NairaFlow</span>
              <span className="text-xs bg-white/20 px-2 py-1 rounded">VERVE</span>
            </div>
            <p className="text-lg tracking-wider mb-2">**** **** **** ****</p>
            <div className="flex justify-between text-xs">
              <span>{cardName || "Your Name"}</span>
              <span>MM/YY</span>
            </div>
          </div>

          <div>
            <label className="text-sm text-gray-500 mb-1 block">Card Name</label>
            <input
              type="text"
              value={cardName}
              onChange={(e) => setCardName(e.target.value)}
              placeholder="Name on card"
              className="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="flex items-start gap-2">
            <input type="checkbox" className="mt-1 w-4 h-4 accent-emerald-600" defaultChecked />
            <p className="text-xs text-gray-500">
              I agree to the Terms & Conditions for using the NairaFlow virtual card service
            </p>
          </div>

          <button
            onClick={handleApply}
            disabled={applyMutation.isPending}
            className="w-full py-3.5 rounded-full font-semibold bg-emerald-600 text-white hover:bg-emerald-700 disabled:opacity-50"
          >
            {applyMutation.isPending ? "Applying..." : "Apply Now"}
          </button>
        </div>
      </div>
    </MobileLayout>
  )
}
