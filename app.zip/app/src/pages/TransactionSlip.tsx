import { useNavigate, useParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { ArrowLeft, Download, Share2, CheckCircle, Clock, XCircle, Copy } from "lucide-react";

export default function TransactionSlip() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth({ redirectOnUnauthenticated: true });

  const { data: tx, isLoading } = trpc.wallet.getTransactionById.useQuery(
    { id: parseInt(id || "0") },
    { enabled: !!user && !!id }
  );

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard");
  };

  const isCredit = tx && ["deposit", "transfer_in", "interest", "bonus", "refund"].includes(tx.type);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  if (!tx) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <XCircle className="w-12 h-12 mx-auto mb-2 text-red-500" />
          <p>Transaction not found</p>
          <Button onClick={() => navigate("/transactions")} className="mt-4">
            Go Back
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-emerald-600 text-white px-4 py-4 flex items-center gap-3">
        <button onClick={() => navigate("/transactions")} className="p-1 rounded-full hover:bg-white/20">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">Transaction Slip</h1>
      </div>

      <div className="p-4">
        <Card className="overflow-hidden">
          {/* Header */}
          <div className="bg-emerald-600 text-white p-6 text-center">
            {tx.status === "successful" ? (
              <CheckCircle className="w-12 h-12 mx-auto mb-2" />
            ) : tx.status === "pending" ? (
              <Clock className="w-12 h-12 mx-auto mb-2" />
            ) : (
              <XCircle className="w-12 h-12 mx-auto mb-2" />
            )}
            <p className="text-lg font-semibold capitalize">{tx.status}</p>
            <p className="text-3xl font-bold mt-2">
              {isCredit ? "+" : "-"}₦{parseFloat(tx.amount).toLocaleString("en-NG", { minimumFractionDigits: 2 })}
            </p>
          </div>

          <CardContent className="p-6 space-y-4">
            {/* Transaction Details */}
            <div className="space-y-3">
              <DetailRow label="Reference" value={tx.reference} onCopy={() => copyToClipboard(tx.reference)} />
              <DetailRow label="Transaction Type" value={tx.type.replace("_", " ").toUpperCase()} />
              <DetailRow label="Category" value={tx.category?.toUpperCase() || "OTHER"} />
              {tx.recipientName && <DetailRow label="Recipient Name" value={tx.recipientName} />}
              {tx.recipientAccount && <DetailRow label="Recipient Account" value={tx.recipientAccount} />}
              {tx.recipientBank && <DetailRow label="Bank" value={tx.recipientBank} />}
              {tx.description && <DetailRow label="Description" value={tx.description} />}
              <DetailRow label="Fee" value={`₦${parseFloat(tx.fee || "0").toLocaleString("en-NG", { minimumFractionDigits: 2 })}`} />
              <DetailRow label="Total Amount" value={`₦${parseFloat(tx.totalAmount).toLocaleString("en-NG", { minimumFractionDigits: 2 })}`} />
              <DetailRow
                label="Date & Time"
                value={new Date(tx.createdAt || new Date()).toLocaleString("en-NG", {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                  second: "2-digit",
                })}
              />
              {tx.paystackRef && <DetailRow label="Paystack Ref" value={tx.paystackRef} onCopy={() => copyToClipboard(tx.paystackRef!)} />}
            </div>

            {/* Actions */}
            <div className="flex gap-2 pt-4">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => {
                  toast.info("Download feature coming soon");
                }}
              >
                <Download className="w-4 h-4 mr-1" /> Download
              </Button>
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => {
                  if (navigator.share) {
                    navigator.share({
                      title: "NairaFlow Transaction",
                      text: `Transaction ${tx.reference} - ${isCredit ? "+" : "-"}₦${tx.amount}`,
                    });
                  } else {
                    toast.info("Share feature not available");
                  }
                }}
              >
                <Share2 className="w-4 h-4 mr-1" /> Share
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function DetailRow({ label, value, onCopy }: { label: string; value: string; onCopy?: () => void }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <span className="text-sm text-gray-500 flex-shrink-0">{label}</span>
      <div className="text-right flex items-center gap-1">
        <span className="text-sm font-medium">{value}</span>
        {onCopy && (
          <button onClick={onCopy} className="text-gray-400 hover:text-emerald-600">
            <Copy className="w-3 h-3" />
          </button>
        )}
      </div>
    </div>
  );
}
