import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ArrowLeft, Zap, Receipt, Tv, Wifi, Lightbulb } from "lucide-react";

export default function Bills() {
  const navigate = useNavigate();
  const { user } = useAuth({ redirectOnUnauthenticated: true });
  const [selectedBiller, setSelectedBiller] = useState<any>(null);
  const [customerId, setCustomerId] = useState("");
  const [amount, setAmount] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const { data: walletData } = trpc.wallet.getBalance.useQuery(undefined, { enabled: !!user });
  const { data: billers } = trpc.bills.getBillers.useQuery(undefined, { enabled: !!user });
  const { data: history } = trpc.bills.getHistory.useQuery(
    { limit: 5, offset: 0 },
    { enabled: !!user }
  );

  const payBill = trpc.bills.payBill.useMutation({
    onSuccess: () => {
      setIsLoading(false);
      toast.success("Bill payment successful!");
      setCustomerId("");
      setAmount("");
      setSelectedBiller(null);
    },
    onError: (error) => {
      setIsLoading(false);
      toast.error(error.message || "Payment failed");
    },
  });

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(amount);
    if (!selectedBiller || !customerId || !amountNum) {
      toast.error("Please fill all fields");
      return;
    }
    if (amountNum > parseFloat(walletData?.balance || "0")) {
      toast.error("Insufficient balance");
      return;
    }
    setIsLoading(true);
    payBill.mutate({
      billerCode: selectedBiller.code,
      biller: selectedBiller.name,
      product: selectedBiller.category,
      customerId,
      amount: amountNum,
    });
  };

  const getBillerIcon = (category: string) => {
    switch (category) {
      case "tv": return <Tv className="w-5 h-5" />;
      case "internet": return <Wifi className="w-5 h-5" />;
      case "electricity": return <Lightbulb className="w-5 h-5" />;
      default: return <Receipt className="w-5 h-5" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-emerald-600 text-white px-4 py-4 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-1 rounded-full hover:bg-white/20">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">Pay Bills</h1>
      </div>

      <div className="p-4 space-y-4">
        {/* Billers */}
        <div>
          <Label>Select Biller</Label>
          <div className="grid grid-cols-3 gap-2 mt-2">
            {billers?.map((biller: any) => (
              <button
                key={biller.code}
                onClick={() => setSelectedBiller(biller)}
                className={`flex flex-col items-center gap-1 p-3 rounded-lg border transition ${
                  selectedBiller?.code === biller.code
                    ? "border-emerald-500 bg-emerald-50"
                    : "border-gray-200 bg-white hover:border-gray-300"
                }`}
              >
                <div className="text-gray-400">{getBillerIcon(biller.category)}</div>
                <span className="text-[10px] font-medium text-center leading-tight">{biller.name}</span>
              </button>
            ))}
          </div>
        </div>

        {selectedBiller && (
          <form onSubmit={handlePay} className="space-y-4">
            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3">
              <p className="text-sm font-medium">{selectedBiller.name}</p>
              <p className="text-xs text-gray-500 capitalize">{selectedBiller.category}</p>
            </div>

            <div>
              <Label>Customer ID / Meter Number / Smartcard</Label>
              <Input
                value={customerId}
                onChange={(e) => setCustomerId(e.target.value)}
                placeholder="Enter customer ID"
              />
            </div>

            <div>
              <Label>Amount (₦)</Label>
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount"
              />
              <p className="text-xs text-gray-500 mt-1">
                Available: ₦{parseFloat(walletData?.balance || "0").toLocaleString("en-NG", { minimumFractionDigits: 2 })}
              </p>
            </div>

            <Button
              type="submit"
              className="w-full bg-emerald-600 hover:bg-emerald-700"
              disabled={isLoading}
            >
              {isLoading ? "Processing..." : <><Zap className="w-4 h-4 mr-1" /> Pay Bill</>}
            </Button>
          </form>
        )}

        {/* Recent History */}
        {history && history.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold text-sm">Recent Payments</h3>
              <button onClick={() => navigate("/transactions")} className="text-xs text-emerald-600">
                See All
              </button>
            </div>
            <div className="space-y-2">
              {history.map((item: any) => (
                <div key={item.id} className="flex items-center justify-between p-2 bg-white rounded-lg">
                  <div className="flex items-center gap-2">
                    <Receipt className="w-4 h-4 text-gray-400" />
                    <div>
                      <p className="text-sm font-medium">{item.biller}</p>
                      <p className="text-[10px] text-gray-500">{item.customerId}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold">₦{parseFloat(item.amount).toLocaleString()}</p>
                    <p className={`text-[10px] ${item.status === "successful" ? "text-emerald-500" : "text-red-500"}`}>
                      {item.status}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
