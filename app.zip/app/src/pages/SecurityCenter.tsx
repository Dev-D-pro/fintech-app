import { MobileLayout } from "@/components/MobileLayout"
import { useNavigate } from "react-router"
import { ArrowLeft, Shield, Lock, Eye, Smartphone, AlertTriangle } from "lucide-react"

export default function SecurityCenter() {
  const navigate = useNavigate()

  return (
    <MobileLayout hideNav>
      <div className="bg-white min-h-screen">
        <div className="flex items-center gap-3 px-4 py-3 border-b">
          <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5" /></button>
          <h1 className="font-semibold">Security Center</h1>
        </div>

        <div className="p-4 space-y-4">
          <div className="bg-emerald-50 rounded-xl p-4 flex items-center gap-3">
            <Shield className="w-10 h-10 text-emerald-600" />
            <div>
              <p className="font-semibold">6 Safety Tips</p>
              <p className="text-xs text-gray-500">Make your account more secure</p>
            </div>
          </div>

          {[
            { icon: Lock, title: "Change PIN", desc: "Update your transaction PIN" },
            { icon: Eye, title: "Biometric Login", desc: "Enable fingerprint/face ID" },
            { icon: Smartphone, title: "Device Management", desc: "Manage connected devices" },
            { icon: AlertTriangle, title: "Report Fraud", desc: "Report suspicious activity" },
          ].map((item) => {
            const Icon = item.icon
            return (
              <div key={item.title} className="flex items-center gap-3 p-3 border rounded-xl hover:bg-gray-50">
                <div className="w-10 h-10 rounded-full bg-emerald-50 flex items-center justify-center">
                  <Icon className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">{item.title}</p>
                  <p className="text-xs text-gray-400">{item.desc}</p>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </MobileLayout>
  )
}
