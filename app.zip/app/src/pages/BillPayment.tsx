import { MobileLayout } from "@/components/MobileLayout"
import { trpc } from "@/providers/trpc"
import { useState } from "react"
import { useNavigate } from "react-router"
import { ArrowLeft, Tv, Zap, Wifi, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"

const BILL_CATEGORIES = [
  { id: "tv", name: "Cable TV", icon: Tv, color: "bg-purple-100 text-purple-600" },
  { id: "electricity", name: "Electricity", icon: Zap, color: "bg-amber-100 text-amber-600" },
  { id: "internet", name: "Internet", icon: Wifi, color: "bg-blue-100 text-blue-600" },
]

export default function BillPayment() {
  const navigate = useNavigate()
  const [category, setCategory] = useState("tv")
  const [customerId, setCustomerId] = useState("")
  const [amount, setAmount] = useState("")
  const [error, setError] = useState("")

  const payMutation = trpc.bills.payBill.useMutation()

  const handlePay = async () => {
    const amt = parseFloat(amount)
    if (isNaN(amt) || amt < 50) {
      setError("Enter a valid amount")
      return
    }
    if (!customerId) {
      setError("Enter customer ID")
      return
    }
    setError("")
    try {
      const result = await payMutation.mutateAsync({
        billerCode: category.toUpperCase(),
        biller: category,
        product: category,
        customerId,
        amount: amt,
      })
      if (result.success) {
        navigate(`/transactions?ref=${result.reference}`)
      }
    } catch (e: any) {
      setError(e.message || "Payment failed")
    }
  }

  return (
    <MobileLayout hideNav>
      <div className="bg-white min-h-screen">
        <div className="flex items-center gap-3 px-4 py-3 border-b">
          <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5" /></button>
          <h1 className="font-semibold">Bill Payment</h1>
        </div>

        {error && (
          <div className="mx-4 mt-3 p-3 bg-red-50 rounded-lg flex items-center gap-2 text-red-600 text-sm">
            <AlertCircle className="w-4 h-4" /> {error}
          </div>
        )}

        <div className="p-4 space-y-4">
          {/* Categories */}
          <div className="grid grid-cols-3 gap-2">
            {BILL_CATEGORIES.map((cat) => {
              const Icon = cat.icon
              return (
                <button
                  key={cat.id}
                  onClick={() => setCategory(cat.id)}
                  className={cn(
                    "p-3 rounded-xl border-2 flex flex-col items-center gap-1 transition-all",
                    category === cat.id ? "border-emerald-500 bg-emerald-50" : "border-gray-100"
                  )}
                >
                  <div className={cn("w-10 h-10 rounded-full flex items-center justify-center", cat.color)}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-medium">{cat.name}</span>
                </button>
              )
            })}
          </div>

          {/* Customer ID */}
          <div>
            <label className="text-sm text-gray-500 mb-1 block">Customer ID / Meter Number</label>
            <input
              type="text"
              value={customerId}
              onChange={(e) => setCustomerId(e.target.value)}
              placeholder="Enter ID number"
              className="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Amount */}
          <div>
            <label className="text-sm text-gray-500 mb-1 block">Amount</label>
            <div className="flex items-center border rounded-xl px-3">
              <span className="text-xl font-bold text-gray-800 mr-2">&#8358;</span>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full py-3 text-xl font-bold focus:outline-none"
              />
            </div>
          </div>

          <button
            onClick={handlePay}
            disabled={payMutation.isPending || !amount || !customerId}
            className={cn(
              "w-full py-3.5 rounded-full font-semibold text-white transition-all",
              amount && customerId
                ? "bg-emerald-600 hover:bg-emerald-700"
                : "bg-gray-300 cursor-not-allowed"
            )}
          >
            {payMutation.isPending ? "Processing..." : "Pay Bill"}
          </button>
        </div>
      </div>
    </MobileLayout>
  )
}
