import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ArrowLeft, Wifi } from "lucide-react";

export default function Data() {
  const navigate = useNavigate();
  const { user } = useAuth({ redirectOnUnauthenticated: true });
  const [phoneNumber, setPhoneNumber] = useState("");
  const [selectedNetwork, setSelectedNetwork] = useState<string | null>(null);
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  const { data: walletData } = trpc.wallet.getBalance.useQuery(undefined, { enabled: !!user });
  const { data: networks } = trpc.data.getNetworks.useQuery(undefined, { enabled: !!user });
  const { data: plans } = trpc.data.getPlans.useQuery(
    { network: selectedNetwork as any },
    { enabled: !!selectedNetwork }
  );
  const { data: history } = trpc.data.getHistory.useQuery(
    { limit: 5, offset: 0 },
    { enabled: !!user }
  );

  const purchase = trpc.data.purchase.useMutation({
    onSuccess: () => {
      setIsLoading(false);
      toast.success("Data bundle purchased successfully!");
      setPhoneNumber("");
      setSelectedNetwork(null);
      setSelectedPlan(null);
    },
    onError: (error) => {
      setIsLoading(false);
      toast.error(error.message || "Purchase failed");
    },
  });

  const handlePurchase = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber || !selectedNetwork || !selectedPlan) {
      toast.error("Please select network, plan, and enter phone number");
      return;
    }
    if (selectedPlan.price > parseFloat(walletData?.balance || "0")) {
      toast.error("Insufficient balance");
      return;
    }
    setIsLoading(true);
    purchase.mutate({
      phoneNumber,
      network: selectedNetwork as any,
      planCode: selectedPlan.code,
      planName: selectedPlan.name,
      amount: selectedPlan.price,
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-emerald-600 text-white px-4 py-4 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-1 rounded-full hover:bg-white/20">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">Buy Data</h1>
      </div>

      <div className="p-4 space-y-4">
        {/* Network Selection */}
        <div>
          <Label>Select Network</Label>
          <div className="grid grid-cols-4 gap-2 mt-2">
            {networks?.map((network: any) => (
              <button
                key={network.code}
                onClick={() => {
                  setSelectedNetwork(network.code);
                  setSelectedPlan(null);
                }}
                className={`flex flex-col items-center gap-1 p-3 rounded-lg border transition ${
                  selectedNetwork === network.code
                    ? "border-emerald-500 bg-emerald-50"
                    : "border-gray-200 bg-white hover:border-gray-300"
                }`}
              >
                <img
                  src={network.logo}
                  alt={network.name}
                  className="w-8 h-8 object-contain"
                  onError={(e) => { e.currentTarget.style.display = "none"; }}
                />
                <span className="text-[10px] font-medium">{network.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Plans */}
        {plans && plans.length > 0 && (
          <div>
            <Label>Select Plan</Label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {plans.map((plan: any) => (
                <button
                  key={plan.code}
                  onClick={() => setSelectedPlan(plan)}
                  className={`p-3 rounded-lg border text-left transition ${
                    selectedPlan?.code === plan.code
                      ? "border-emerald-500 bg-emerald-50"
                      : "border-gray-200 bg-white hover:border-gray-300"
                  }`}
                >
                  <p className="font-medium text-sm">{plan.name}</p>
                  <p className="text-emerald-600 font-bold">₦{plan.price.toLocaleString()}</p>
                  <p className="text-[10px] text-gray-500">{plan.validity}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        <form onSubmit={handlePurchase} className="space-y-4">
          <div>
            <Label>Phone Number</Label>
            <Input
              type="tel"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              placeholder="08012345678"
              maxLength={11}
            />
          </div>

          {selectedPlan && (
            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3">
              <p className="text-sm font-medium">Selected Plan</p>
              <p className="text-emerald-700 font-bold">{selectedPlan.name} - ₦{selectedPlan.price.toLocaleString()}</p>
            </div>
          )}

          <p className="text-xs text-gray-500">
            Available: ₦{parseFloat(walletData?.balance || "0").toLocaleString("en-NG", { minimumFractionDigits: 2 })}
          </p>

          <Button
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-700"
            disabled={isLoading || !selectedPlan}
          >
            {isLoading ? "Processing..." : <><Wifi className="w-4 h-4 mr-1" /> Buy Data Bundle</>}
          </Button>
        </form>

        {/* Recent History */}
        {history && history.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold text-sm">Recent Purchases</h3>
              <button onClick={() => navigate("/transactions")} className="text-xs text-emerald-600">
                See All
              </button>
            </div>
            <div className="space-y-2">
              {history.map((item: any) => (
                <div key={item.id} className="flex items-center justify-between p-2 bg-white rounded-lg">
                  <div className="flex items-center gap-2">
                    <Wifi className="w-4 h-4 text-gray-400" />
                    <div>
                      <p className="text-sm font-medium">{item.planName}</p>
                      <p className="text-[10px] text-gray-500">{item.phoneNumber}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold">₦{parseFloat(item.amount).toLocaleString()}</p>
                    <p className={`text-[10px] ${item.status === "successful" ? "text-emerald-500" : "text-red-500"}`}>
                      {item.status}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
