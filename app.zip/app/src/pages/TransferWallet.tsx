import { MobileLayout } from "@/components/MobileLayout"
import { trpc } from "@/providers/trpc"
import { useState } from "react"
import { useNavigate } from "react-router"
import { ArrowLeft, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"

export default function TransferWallet() {
  const navigate = useNavigate()
  const [step, setStep] = useState<"recipient" | "amount" | "confirm">("recipient")
  const [recipientEmail, setRecipientEmail] = useState("")
  const [amount, setAmount] = useState("")
  const [description, setDescription] = useState("")
  const [error, setError] = useState("")

  const transferMutation = trpc.wallet.walletTransfer.useMutation()

  const handleTransfer = () => {
    const amt = parseFloat(amount)
    if (isNaN(amt) || amt < 10) {
      setError("Enter a valid amount")
      return
    }
    setError("")
    setStep("confirm")
  }

  const confirmTransfer = async () => {
    try {
      const result = await transferMutation.mutateAsync({
        recipientEmail,
        amount: parseFloat(amount),
        description,
      })
      if (result.success) {
        navigate(`/transactions?ref=${result.reference}`)
      }
    } catch (e: any) {
      setError(e.message || "Transfer failed")
      setStep("amount")
    }
  }

  return (
    <MobileLayout hideNav>
      <div className="bg-white min-h-screen">
        <div className="flex items-center gap-3 px-4 py-3 border-b">
          <button onClick={() => step === "recipient" ? navigate(-1) : setStep(step === "confirm" ? "amount" : "recipient")}>
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-semibold">Transfer to Wallet</h1>
        </div>

        {error && (
          <div className="mx-4 mt-3 p-3 bg-red-50 rounded-lg flex items-center gap-2 text-red-600 text-sm">
            <AlertCircle className="w-4 h-4" /> {error}
          </div>
        )}

        {step === "recipient" && (
          <div className="p-4 space-y-4">
            <div>
              <label className="text-sm text-gray-500 mb-1 block">Recipient Email</label>
              <input
                type="email"
                value={recipientEmail}
                onChange={(e) => setRecipientEmail(e.target.value)}
                placeholder="Enter recipient email"
                className="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <button
              onClick={() => recipientEmail.includes("@") && setStep("amount")}
              disabled={!recipientEmail.includes("@")}
              className={cn(
                "w-full py-3.5 rounded-full font-semibold text-white transition-all",
                recipientEmail.includes("@")
                  ? "bg-emerald-600 hover:bg-emerald-700"
                  : "bg-gray-300 cursor-not-allowed"
              )}
            >
              Next
            </button>
          </div>
        )}

        {step === "amount" && (
          <div className="p-4 space-y-4">
            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-sm text-gray-500">Sending to</p>
              <p className="font-semibold">{recipientEmail}</p>
            </div>
            <div>
              <label className="text-sm text-gray-500 mb-1 block">Amount</label>
              <div className="flex items-center border rounded-xl px-3">
                <span className="text-2xl font-bold text-gray-800 mr-2">&#8358;</span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full py-3 text-2xl font-bold focus:outline-none"
                />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {["500", "1000", "2000", "5000", "10000", "50000"].map((amt) => (
                <button
                  key={amt}
                  onClick={() => setAmount(amt)}
                  className="py-2 border rounded-lg text-sm font-medium hover:border-emerald-400 hover:bg-emerald-50"
                >
                  &#8358;{parseInt(amt).toLocaleString()}
                </button>
              ))}
            </div>
            <div>
              <label className="text-sm text-gray-500 mb-1 block">Remark (Optional)</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What's this for?"
                className="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <button
              onClick={handleTransfer}
              disabled={!amount || parseFloat(amount) < 10}
              className={cn(
                "w-full py-3.5 rounded-full font-semibold text-white transition-all",
                amount && parseFloat(amount) >= 10
                  ? "bg-emerald-600 hover:bg-emerald-700"
                  : "bg-gray-300 cursor-not-allowed"
              )}
            >
              Continue
            </button>
          </div>
        )}

        {step === "confirm" && (
          <div className="p-4 space-y-4">
            <div className="bg-emerald-50 rounded-xl p-4 text-center">
              <p className="text-sm text-emerald-600 mb-2">You are about to send</p>
              <p className="text-3xl font-bold text-gray-800">&#8358;{parseFloat(amount).toLocaleString()}</p>
            </div>
            <div className="bg-white border rounded-xl divide-y">
              <div className="flex justify-between p-3">
                <span className="text-sm text-gray-500">Recipient</span>
                <span className="text-sm font-medium">{recipientEmail}</span>
              </div>
              <div className="flex justify-between p-3">
                <span className="text-sm text-gray-500">Amount</span>
                <span className="text-sm font-medium">&#8358;{parseFloat(amount).toLocaleString()}</span>
              </div>
              <div className="flex justify-between p-3">
                <span className="text-sm text-gray-500">Fee</span>
                <span className="text-sm font-medium text-emerald-600">&#8358;0.00</span>
              </div>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setStep("amount")}
                className="flex-1 py-3.5 rounded-full font-semibold border border-emerald-600 text-emerald-600"
              >
                Recheck
              </button>
              <button
                onClick={confirmTransfer}
                disabled={transferMutation.isPending}
                className="flex-1 py-3.5 rounded-full font-semibold bg-emerald-600 text-white hover:bg-emerald-700 disabled:opacity-50"
              >
                {transferMutation.isPending ? "Processing..." : "Pay"}
              </button>
            </div>
          </div>
        )}
      </div>
    </MobileLayout>
  )
}
