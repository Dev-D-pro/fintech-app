import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { ArrowLeft, Shield, CheckCircle, Clock, AlertTriangle, Upload, FileText } from "lucide-react";

export default function KYC() {
  const navigate = useNavigate();
  const { user } = useAuth({ redirectOnUnauthenticated: true });
  const [bvn, setBvn] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<string | null>(null);
  const [docNumber, setDocNumber] = useState("");

  const { data: kycData, refetch } = trpc.kyc.getStatus.useQuery(undefined, {
    enabled: !!user,
  });

  const verifyBVN = trpc.kyc.verifyBVN.useMutation({
    onSuccess: (data) => {
      setIsVerifying(false);
      toast.success(`BVN verified! Upgraded to ${data.tier.toUpperCase()}`);
      refetch();
    },
    onError: (error) => {
      setIsVerifying(false);
      toast.error(error.message || "BVN verification failed");
    },
  });

  const submitDoc = trpc.kyc.submitDocument.useMutation({
    onSuccess: () => {
      toast.success("Document submitted for review");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Submission failed");
    },
  });

  const handleBVNVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (bvn.length !== 11) {
      toast.error("BVN must be 11 digits");
      return;
    }
    setIsVerifying(true);
    verifyBVN.mutate({ bvn });
  };

  const handleSubmitDoc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDoc) {
      toast.error("Please select document type");
      return;
    }
    submitDoc.mutate({
      type: selectedDoc as any,
      documentNumber: docNumber || undefined,
    });
  };

  const tierInfo = {
    tier1: { name: "Tier 1", daily: "₦50,000", maxBalance: "₦300,000", color: "bg-yellow-100 text-yellow-800" },
    tier2: { name: "Tier 2", daily: "₦200,000", maxBalance: "₦500,000", color: "bg-blue-100 text-blue-800" },
    tier3: { name: "Tier 3", daily: "₦5,000,000", maxBalance: "Unlimited", color: "bg-emerald-100 text-emerald-800" },
  };

  const currentTier = kycData?.tier || "tier1";
  const tier = tierInfo[currentTier as keyof typeof tierInfo] || tierInfo.tier1;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-emerald-600 text-white px-4 py-4 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-1 rounded-full hover:bg-white/20">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">KYC Verification</h1>
      </div>

      <div className="p-4 space-y-4">
        {/* Current Status */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center">
                <Shield className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <p className="font-semibold">Verification Status</p>
                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
                  kycData?.kycStatus === "verified" ? "bg-emerald-100 text-emerald-800" :
                  kycData?.kycStatus === "submitted" ? "bg-yellow-100 text-yellow-800" :
                  "bg-gray-100 text-gray-800"
                }`}>
                  {kycData?.kycStatus === "verified" ? <CheckCircle className="w-3 h-3" /> :
                   kycData?.kycStatus === "submitted" ? <Clock className="w-3 h-3" /> :
                   <AlertTriangle className="w-3 h-3" />}
                  {kycData?.kycStatus?.toUpperCase() || "PENDING"}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-gray-50 rounded-lg p-2">
                <p className="text-xs text-gray-500">Current Tier</p>
                <p className="font-semibold text-sm">{tier.name}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-2">
                <p className="text-xs text-gray-500">Daily Limit</p>
                <p className="font-semibold text-sm">{tier.daily}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-2">
                <p className="text-xs text-gray-500">Max Balance</p>
                <p className="font-semibold text-sm">{tier.maxBalance}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* BVN Verification */}
        {kycData?.kycStatus !== "verified" && (
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-600" />
                Verify BVN (Instant Upgrade to Tier 2)
              </h3>
              <form onSubmit={handleBVNVerify} className="space-y-3">
                <div>
                  <Label>Bank Verification Number (BVN)</Label>
                  <Input
                    value={bvn}
                    onChange={(e) => setBvn(e.target.value.replace(/\D/g, ""))}
                    maxLength={11}
                    placeholder="Enter 11-digit BVN"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full bg-emerald-600 hover:bg-emerald-700"
                  disabled={isVerifying || bvn.length !== 11}
                >
                  {isVerifying ? "Verifying..." : "Verify BVN"}
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Document Upload */}
        <Card>
          <CardContent className="p-4">
            <h3 className="font-semibold mb-3 flex items-center gap-2">
              <Upload className="w-5 h-5 text-emerald-600" />
              Submit Documents
            </h3>
            <form onSubmit={handleSubmitDoc} className="space-y-3">
              <div>
                <Label>Document Type</Label>
                <select
                  value={selectedDoc || ""}
                  onChange={(e) => setSelectedDoc(e.target.value)}
                  className="w-full border rounded-md p-2 text-sm"
                >
                  <option value="">Select document type</option>
                  <option value="passport">International Passport</option>
                  <option value="drivers_license">Driver's License</option>
                  <option value="voters_card">Voter's Card</option>
                  <option value="nin">National ID (NIN)</option>
                  <option value="utility_bill">Utility Bill</option>
                </select>
              </div>
              <div>
                <Label>Document Number (Optional)</Label>
                <Input
                  value={docNumber}
                  onChange={(e) => setDocNumber(e.target.value)}
                  placeholder="Enter document number"
                />
              </div>
              <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700">
                Submit Document
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Submitted Documents */}
        {kycData?.documents && kycData.documents.length > 0 && (
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold mb-3">Submitted Documents</h3>
              <div className="space-y-2">
                {kycData.documents.map((doc: any) => (
                  <div key={doc.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-gray-400" />
                      <span className="text-sm capitalize">{doc.type.replace("_", " ")}</span>
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      doc.status === "verified" ? "bg-emerald-100 text-emerald-800" :
                      doc.status === "submitted" ? "bg-yellow-100 text-yellow-800" :
                      "bg-red-100 text-red-800"
                    }`}>
                      {doc.status}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
