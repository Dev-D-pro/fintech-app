import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { ArrowLeft, Wallet, Landmark } from "lucide-react";

export default function Transfer() {
  const navigate = useNavigate();
  const { user } = useAuth({ redirectOnUnauthenticated: true });
  const [recipientEmail, setRecipientEmail] = useState("");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const { data: walletData } = trpc.wallet.getBalance.useQuery(undefined, {
    enabled: !!user,
  });

  const transferMutation = trpc.wallet.walletTransfer.useMutation({
    onSuccess: (data) => {
      toast.success("Transfer successful!");
      navigate(`/transaction/${data.reference}`);
    },
    onError: (error) => {
      toast.error(error.message || "Transfer failed");
      setIsLoading(false);
    },
  });

  const handleTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(amount);
    if (!recipientEmail || !amountNum || amountNum <= 0) {
      toast.error("Please fill all fields");
      return;
    }
    if (amountNum > parseFloat(walletData?.balance || "0")) {
      toast.error("Insufficient balance");
      return;
    }
    setIsLoading(true);
    transferMutation.mutate({
      recipientEmail,
      amount: amountNum,
      description: description || undefined,
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-emerald-600 text-white px-4 py-4 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-1 rounded-full hover:bg-white/20">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">Transfer</h1>
      </div>

      <div className="p-4 space-y-4">
        {/* Transfer Options */}
        <div className="grid grid-cols-2 gap-3">
          <Card className="border-emerald-200 bg-emerald-50">
            <CardContent className="p-4 flex flex-col items-center gap-2">
              <Wallet className="w-8 h-8 text-emerald-600" />
              <span className="font-medium text-sm">Wallet Transfer</span>
            </CardContent>
          </Card>
          <button onClick={() => navigate("/transfer/bank")} className="block">
            <Card className="hover:bg-gray-50 transition">
              <CardContent className="p-4 flex flex-col items-center gap-2">
                <Landmark className="w-8 h-8 text-gray-400" />
                <span className="font-medium text-sm text-gray-600">Bank Transfer</span>
              </CardContent>
            </Card>
          </button>
        </div>

        {/* Wallet Transfer Form */}
        <form onSubmit={handleTransfer} className="space-y-4">
          <div>
            <Label>Recipient Email</Label>
            <Input
              type="email"
              placeholder="recipient@email.com"
              value={recipientEmail}
              onChange={(e) => setRecipientEmail(e.target.value)}
              required
            />
          </div>

          <div>
            <Label>Amount (₦)</Label>
            <Input
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              min="10"
              required
            />
            <p className="text-xs text-gray-500 mt-1">
              Available: ₦{parseFloat(walletData?.balance || "0").toLocaleString("en-NG", { minimumFractionDigits: 2 })}
            </p>
          </div>

          <div>
            <Label>Description (Optional)</Label>
            <Input
              placeholder="What is this for?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-700"
            disabled={isLoading}
          >
            {isLoading ? "Processing..." : "Send Money"}
          </Button>
        </form>
      </div>
    </div>
  );
}
