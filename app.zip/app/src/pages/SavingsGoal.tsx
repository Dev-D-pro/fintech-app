import { MobileLayout } from "@/components/MobileLayout"
import { trpc } from "@/providers/trpc"
import { useState } from "react"
import { useNavigate } from "react-router"
import { ArrowLeft, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"

const GOAL_TYPES = [
  { id: "owealth", name: "OWealth", desc: "Daily interest on your savings" },
  { id: "targets", name: "Target Savings", desc: "Save towards a specific goal" },
  { id: "safebox", name: "SafeBox", desc: "Lock your savings away" },
  { id: "fixed", name: "Fixed Savings", desc: "Earn higher interest over a fixed period" },
]

export default function SavingsGoal() {
  const navigate = useNavigate()
  const [step, setStep] = useState(1)
  const [name, setName] = useState("")
  const [type, setType] = useState("owealth")
  const [targetAmount, setTargetAmount] = useState("")
  const [autoSave, setAutoSave] = useState(false)
  const [autoSaveAmount, setAutoSaveAmount] = useState("")
  const [error, setError] = useState("")

  const createMutation = trpc.savings.createGoal.useMutation()

  const handleCreate = async () => {
    if (!name.trim()) {
      setError("Enter a goal name")
      return
    }
    setError("")
    try {
      const result = await createMutation.mutateAsync({
        name,
        type: type as any,
        targetAmount: targetAmount ? parseFloat(targetAmount) : undefined,
        autoSave,
        autoSaveAmount: autoSaveAmount ? parseFloat(autoSaveAmount) : undefined,
      })
      if (result.success) {
        navigate("/savings")
      }
    } catch (e: any) {
      setError(e.message || "Failed to create goal")
    }
  }

  return (
    <MobileLayout hideNav>
      <div className="bg-white min-h-screen">
        <div className="flex items-center gap-3 px-4 py-3 border-b">
          <button onClick={() => step > 1 ? setStep(step - 1) : navigate(-1)}>
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-semibold">Create Savings Goal</h1>
        </div>

        {error && (
          <div className="mx-4 mt-3 p-3 bg-red-50 rounded-lg flex items-center gap-2 text-red-600 text-sm">
            <AlertCircle className="w-4 h-4" /> {error}
          </div>
        )}

        {/* Step indicator */}
        <div className="flex items-center gap-2 px-4 mt-4">
          {[1, 2].map((s) => (
            <div key={s} className={cn("h-1 flex-1 rounded-full", s <= step ? "bg-emerald-500" : "bg-gray-200")} />
          ))}
        </div>

        {step === 1 && (
          <div className="p-4 space-y-4">
            <div>
              <label className="text-sm text-gray-500 mb-1 block">Goal Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., New Car, Emergency Fund"
                className="w-full p-3 border rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="text-sm text-gray-500 mb-2 block">Savings Type</label>
              <div className="space-y-2">
                {GOAL_TYPES.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setType(t.id)}
                    className={cn(
                      "w-full p-3 rounded-xl border-2 text-left transition-all",
                      type === t.id ? "border-emerald-500 bg-emerald-50" : "border-gray-100"
                    )}
                  >
                    <p className="font-medium text-sm">{t.name}</p>
                    <p className="text-xs text-gray-400">{t.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => name.trim() && setStep(2)}
              className={cn(
                "w-full py-3.5 rounded-full font-semibold text-white transition-all",
                name.trim() ? "bg-emerald-600 hover:bg-emerald-700" : "bg-gray-300 cursor-not-allowed"
              )}
            >
              Continue
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="p-4 space-y-4">
            <div>
              <label className="text-sm text-gray-500 mb-1 block">Target Amount (Optional)</label>
              <div className="flex items-center border rounded-xl px-3">
                <span className="text-lg font-bold text-gray-800 mr-2">&#8358;</span>
                <input
                  type="number"
                  value={targetAmount}
                  onChange={(e) => setTargetAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full py-3 text-lg font-bold focus:outline-none"
                />
              </div>
            </div>

            <div className="flex items-center gap-3 p-3 border rounded-xl">
              <input
                type="checkbox"
                id="autosave"
                checked={autoSave}
                onChange={(e) => setAutoSave(e.target.checked)}
                className="w-5 h-5 accent-emerald-600"
              />
              <label htmlFor="autosave" className="text-sm font-medium">Enable Auto-Save</label>
            </div>

            {autoSave && (
              <div>
                <label className="text-sm text-gray-500 mb-1 block">Auto-Save Amount</label>
                <div className="flex items-center border rounded-xl px-3">
                  <span className="text-lg font-bold text-gray-800 mr-2">&#8358;</span>
                  <input
                    type="number"
                    value={autoSaveAmount}
                    onChange={(e) => setAutoSaveAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full py-3 text-lg font-bold focus:outline-none"
                  />
                </div>
              </div>
            )}

            <button
              onClick={handleCreate}
              disabled={createMutation.isPending}
              className={cn(
                "w-full py-3.5 rounded-full font-semibold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 transition-all"
              )}
            >
              {createMutation.isPending ? "Creating..." : "Create Goal"}
            </button>
          </div>
        )}
      </div>
    </MobileLayout>
  )
}
