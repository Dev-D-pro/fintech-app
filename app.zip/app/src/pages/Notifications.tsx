import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { ArrowLeft, Bell, Check, Trash2 } from "lucide-react";

export default function Notifications() {
  const navigate = useNavigate();
  const { user } = useAuth({ redirectOnUnauthenticated: true });

  const { data, isLoading, refetch } = trpc.notification.getNotifications.useQuery(
    { limit: 50, offset: 0 },
    { enabled: !!user }
  );

  const markAsRead = trpc.notification.markAsRead.useMutation({
    onSuccess: () => refetch(),
  });

  const markAllAsRead = trpc.notification.markAllAsRead.useMutation({
    onSuccess: () => {
      toast.success("All notifications marked as read");
      refetch();
    },
  });

  const deleteNotification = trpc.notification.deleteNotification.useMutation({
    onSuccess: () => refetch(),
  });

  const getIcon = (type: string) => {
    switch (type) {
      case "transaction": return "💰";
      case "promo": return "🎁";
      case "security": return "🔒";
      case "savings": return "💎";
      case "kyc": return "🆔";
      default: return "📢";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-emerald-600 text-white px-4 py-4 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-1 rounded-full hover:bg-white/20">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">Notifications</h1>
        {data && data.unreadCount > 0 && (
          <Button
            size="sm"
            variant="ghost"
            className="ml-auto text-white hover:bg-white/20"
            onClick={() => markAllAsRead.mutate()}
          >
            <Check className="w-4 h-4 mr-1" /> Read All
          </Button>
        )}
      </div>

      <div className="p-4 space-y-2">
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-20 bg-gray-100 rounded-lg animate-pulse"></div>
            ))}
          </div>
        ) : data?.notifications && data.notifications.length > 0 ? (
          data.notifications.map((notif: any) => (
            <div
              key={notif.id}
              className={`flex items-start gap-3 p-3 rounded-lg transition ${
                notif.isRead ? "bg-white" : "bg-emerald-50 border border-emerald-100"
              }`}
            >
              <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-lg flex-shrink-0">
                {getIcon(notif.type)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm">{notif.title}</p>
                <p className="text-xs text-gray-500 mt-0.5">{notif.message}</p>
                <p className="text-[10px] text-gray-400 mt-1">
                  {new Date(notif.createdAt).toLocaleDateString("en-NG", {
                    day: "numeric",
                    month: "short",
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
              </div>
              <div className="flex flex-col gap-1">
                {!notif.isRead && (
                  <button
                    onClick={() => markAsRead.mutate({ id: notif.id })}
                    className="p-1.5 rounded-full hover:bg-emerald-100 text-emerald-600 transition"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={() => deleteNotification.mutate({ id: notif.id })}
                  className="p-1.5 rounded-full hover:bg-red-100 text-red-500 transition"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-12 text-gray-500">
            <Bell className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>No notifications yet</p>
          </div>
        )}
      </div>
    </div>
  );
}
