import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { ArrowLeft, Check, Loader2 } from "lucide-react";

export default function BankTransfer() {
  const navigate = useNavigate();
  const { user } = useAuth({ redirectOnUnauthenticated: true });
  const [bankCode, setBankCode] = useState("");
  const [bankName, setBankName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [accountName, setAccountName] = useState("");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [saveBeneficiary, setSaveBeneficiary] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const { data: walletData } = trpc.wallet.getBalance.useQuery(undefined, { enabled: !!user });
  const { data: banks } = trpc.paystack.getBanks.useQuery();
  const { data: beneficiaries } = trpc.bank.getBeneficiaries.useQuery(undefined, { enabled: !!user });

  const verifyAccount = trpc.paystack.verifyAccount.useMutation({
    onSuccess: (data) => {
      setAccountName(data.accountName);
      setIsVerifying(false);
      toast.success(`Account verified: ${data.accountName}`);
    },
    onError: (error) => {
      setIsVerifying(false);
      toast.error(error.message || "Verification failed");
    },
  });

  const transferMutation = trpc.paystack.bankTransfer.useMutation({
    onSuccess: (data) => {
      toast.success("Transfer successful!");
      navigate(`/transaction/${data.reference}`);
    },
    onError: (error) => {
      toast.error(error.message || "Transfer failed");
      setIsLoading(false);
    },
  });

  const handleVerify = () => {
    if (!bankCode || !accountNumber || accountNumber.length !== 10) {
      toast.error("Please select bank and enter 10-digit account number");
      return;
    }
    setIsVerifying(true);
    verifyAccount.mutate({ bankCode, accountNumber });
  };

  const handleTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(amount);
    if (!bankCode || !accountNumber || !accountName || !amountNum) {
      toast.error("Please fill all fields and verify account");
      return;
    }
    if (amountNum > parseFloat(walletData?.balance || "0")) {
      toast.error("Insufficient balance");
      return;
    }
    setIsLoading(true);
    transferMutation.mutate({
      bankCode,
      bankName,
      accountNumber,
      accountName,
      amount: amountNum,
      description: description || undefined,
      saveAsBeneficiary: saveBeneficiary,
    });
  };

  const handleSelectBank = (code: string) => {
    setBankCode(code);
    const bank = banks?.find((b: any) => b.code === code);
    if (bank) setBankName(bank.name);
  };

  const handleSelectBeneficiary = (bene: any) => {
    setBankCode(bene.bankCode);
    setBankName(bene.bankName);
    setAccountNumber(bene.accountNumber);
    setAccountName(bene.name);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-emerald-600 text-white px-4 py-4 flex items-center gap-3">
        <button onClick={() => navigate("/transfer")} className="p-1 rounded-full hover:bg-white/20">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">Bank Transfer</h1>
      </div>

      <div className="p-4 space-y-4">
        {/* Beneficiaries */}
        {beneficiaries && beneficiaries.length > 0 && (
          <div>
            <Label className="text-sm text-gray-500">Saved Beneficiaries</Label>
            <div className="flex gap-2 overflow-x-auto py-2">
              {beneficiaries.map((bene: any) => (
                <button
                  key={bene.id}
                  onClick={() => handleSelectBeneficiary(bene)}
                  className="flex-shrink-0 bg-white border rounded-lg p-3 text-left min-w-[140px] hover:border-emerald-400 transition"
                >
                  <p className="font-medium text-sm truncate">{bene.name}</p>
                  <p className="text-xs text-gray-500">{bene.bankName}</p>
                  <p className="text-xs text-gray-400">{bene.accountNumber}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        <form onSubmit={handleTransfer} className="space-y-4">
          <div>
            <Label>Select Bank</Label>
            <Select value={bankCode} onValueChange={handleSelectBank}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a bank" />
              </SelectTrigger>
              <SelectContent className="max-h-[300px]">
                {banks?.map((bank: any) => (
                  <SelectItem key={bank.code} value={bank.code}>
                    <div className="flex items-center gap-2">
                      {bank.logo && (
                        <img src={bank.logo} alt="" className="w-5 h-5 object-contain" onError={(e) => (e.currentTarget.style.display = "none")} />
                      )}
                      {bank.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Account Number</Label>
            <div className="flex gap-2">
              <Input
                value={accountNumber}
                onChange={(e) => {
                  setAccountNumber(e.target.value);
                  setAccountName("");
                }}
                maxLength={10}
                placeholder="10 digits"
              />
              <Button
                type="button"
                variant="outline"
                onClick={handleVerify}
                disabled={isVerifying || accountNumber.length !== 10 || !bankCode}
              >
                {isVerifying ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          {accountName && (
            <Card className="bg-emerald-50 border-emerald-200">
              <CardContent className="p-3">
                <p className="text-sm font-medium text-emerald-800">{accountName}</p>
              </CardContent>
            </Card>
          )}

          <div>
            <Label>Amount (₦)</Label>
            <Input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              min="10"
              placeholder="0.00"
            />
            <p className="text-xs text-gray-500 mt-1">
              Available: ₦{parseFloat(walletData?.balance || "0").toLocaleString("en-NG", { minimumFractionDigits: 2 })}
            </p>
          </div>

          <div>
            <Label>Description (Optional)</Label>
            <Input
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What is this for?"
            />
          </div>

          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={saveBeneficiary}
              onChange={(e) => setSaveBeneficiary(e.target.checked)}
              className="rounded border-gray-300"
            />
            Save as beneficiary
          </label>

          <Button
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-700"
            disabled={isLoading || !accountName}
          >
            {isLoading ? "Processing..." : "Transfer to Bank"}
          </Button>
        </form>
      </div>
    </div>
  );
}
