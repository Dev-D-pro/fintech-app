import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { ArrowLeft, Users, Wallet, ArrowUpRight, CheckCircle, Shield, Search } from "lucide-react";

export default function Admin() {
  const navigate = useNavigate();
  const { user } = useAuth({ redirectOnUnauthenticated: true });
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("dashboard");

  const { data: stats } = trpc.admin.adminStats.useQuery();
  const { data: dashboardStats } = trpc.admin.getDashboardStats.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  const { data: usersData } = trpc.admin.getUsers.useQuery(
    { limit: 20, offset: 0 },
    { enabled: user?.role === "admin" && activeTab === "users" }
  );

  const { data: transactionsData } = trpc.admin.getTransactions.useQuery(
    { limit: 20, offset: 0 },
    { enabled: user?.role === "admin" && activeTab === "transactions" }
  );

  const { data: kycData } = trpc.admin.getKycReviews.useQuery(
    { limit: 20, offset: 0, status: "submitted" },
    { enabled: user?.role === "admin" && activeTab === "kyc" }
  );

  const reviewKyc = trpc.kyc.reviewKyc.useMutation({
    onSuccess: () => toast.success("KYC reviewed"),
    onError: (error) => toast.error(error.message),
  });

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-12 h-12 mx-auto mb-2 text-red-500" />
          <p className="font-semibold">Access Denied</p>
          <p className="text-sm text-gray-500">Admin access only</p>
          <Button onClick={() => navigate("/dashboard")} className="mt-4 bg-emerald-600">
            Go to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: "dashboard", label: "Dashboard", icon: Wallet },
    { id: "users", label: "Users", icon: Users },
    { id: "transactions", label: "Transactions", icon: ArrowUpRight },
    { id: "kyc", label: "KYC", icon: Shield },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-emerald-800 text-white px-4 py-4 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-1 rounded-full hover:bg-white/20">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">Admin Panel</h1>
      </div>

      <div className="p-4">
        {/* Tabs */}
        <div className="flex gap-2 mb-4 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1 px-3 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition ${
                activeTab === tab.id ? "bg-emerald-600 text-white" : "bg-white text-gray-600 hover:bg-gray-100"
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Dashboard */}
        {activeTab === "dashboard" && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-gray-500">Total Users</p>
                  <p className="text-2xl font-bold">{stats?.totalUsers || 0}</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-gray-500">Total Volume</p>
                  <p className="text-2xl font-bold">
                    ₦{parseFloat(stats?.totalVolume || "0").toLocaleString("en-NG", { minimumFractionDigits: 0 })}
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-gray-500">Transactions</p>
                  <p className="text-2xl font-bold">{stats?.totalTransactions || 0}</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-gray-500">Pending KYC</p>
                  <p className="text-2xl font-bold">{stats?.pendingKyc || 0}</p>
                </CardContent>
              </Card>
            </div>

            {dashboardStats?.transactions?.recent && (
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-3">Recent Transactions</h3>
                  <div className="space-y-2">
                    {dashboardStats.transactions.recent.slice(0, 5).map((tx: any) => (
                      <div key={tx.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                        <div>
                          <p className="text-sm font-medium">{tx.description || tx.type}</p>
                          <p className="text-[10px] text-gray-500">{tx.user?.name || "User"}</p>
                        </div>
                        <p className="font-semibold text-sm">₦{parseFloat(tx.amount).toLocaleString()}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Users */}
        {activeTab === "users" && (
          <div className="space-y-2">
            <div className="flex gap-2 mb-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search users..."
                  className="pl-9"
                />
              </div>
            </div>
            {usersData?.users?.map((u: any) => (
              <Card key={u.id}>
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm">{u.name || "No name"}</p>
                      <p className="text-xs text-gray-500">{u.email || u.unionId}</p>
                      <div className="flex gap-1 mt-1">
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-100 text-gray-600">{u.tier}</span>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                          u.kycStatus === "verified" ? "bg-emerald-100 text-emerald-600" : "bg-yellow-100 text-yellow-600"
                        }`}>
                          {u.kycStatus}
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold">
                        ₦{parseFloat(u.wallet?.balance || "0").toLocaleString()}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Transactions */}
        {activeTab === "transactions" && (
          <div className="space-y-2">
            {transactionsData?.transactions?.map((tx: any) => (
              <Card key={tx.id}>
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm">{tx.description || tx.type}</p>
                      <p className="text-xs text-gray-500">{tx.user?.name || "User"}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-sm">₦{parseFloat(tx.amount).toLocaleString()}</p>
                      <p className={`text-[10px] ${tx.status === "successful" ? "text-emerald-500" : "text-red-500"}`}>
                        {tx.status}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* KYC */}
        {activeTab === "kyc" && (
          <div className="space-y-2">
            {kycData?.documents?.map((doc: any) => (
              <Card key={doc.id}>
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm capitalize">{doc.type.replace("_", " ")}</p>
                      <p className="text-xs text-gray-500">{doc.user?.name || "User"}</p>
                      {doc.documentNumber && <p className="text-xs text-gray-400">{doc.documentNumber}</p>}
                    </div>
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        className="bg-emerald-600"
                        onClick={() => reviewKyc.mutate({ documentId: doc.id, status: "verified" })}
                      >
                        <CheckCircle className="w-3 h-3 mr-1" /> Approve
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-red-600 border-red-200 hover:bg-red-50"
                        onClick={() => reviewKyc.mutate({ documentId: doc.id, status: "rejected", reviewNotes: "Rejected by admin" })}
                      >
                        Reject
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
