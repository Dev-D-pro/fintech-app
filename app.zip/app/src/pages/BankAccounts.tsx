import { MobileLayout } from "@/components/MobileLayout"
import { trpc } from "@/providers/trpc"
import { useNavigate } from "react-router"
import { ArrowLeft, Trash2, Building2, Plus } from "lucide-react"

export default function BankAccounts() {
  const navigate = useNavigate()

  const { data: accounts, refetch } = trpc.bankAccount.getBankAccounts.useQuery()
  const deleteMutation = trpc.bankAccount.deleteBankAccount.useMutation({
    onSuccess: () => refetch(),
  })

  return (
    <MobileLayout hideNav>
      <div className="bg-white min-h-screen">
        <div className="flex items-center gap-3 px-4 py-3 border-b">
          <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5" /></button>
          <h1 className="font-semibold">Bank Cards and Accounts</h1>
        </div>

        <div className="p-4 space-y-3">
          {accounts && accounts.length > 0 ? accounts.map((acc) => (
            <div key={acc.id} className="flex items-center gap-3 p-3 border rounded-xl">
              <div className="w-10 h-10 rounded-full bg-emerald-50 flex items-center justify-center">
                <Building2 className="w-5 h-5 text-emerald-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">{acc.bankName}</p>
                <p className="text-xs text-gray-400">{acc.accountNumber.replace(/(\d{4})$/, "****")} {acc.isDefault && "· Default"}</p>
              </div>
              <button
                onClick={() => deleteMutation.mutate({ id: acc.id })}
                className="p-2 text-red-400 hover:text-red-600"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          )) : (
            <div className="text-center py-8 text-gray-400">
              <Building2 className="w-12 h-12 mx-auto mb-2 text-gray-300" />
              <p>No linked accounts yet</p>
            </div>
          )}
        </div>

        <div className="px-4">
          <button className="w-full py-3.5 rounded-full font-semibold bg-emerald-600 text-white flex items-center justify-center gap-2">
            <Plus className="w-4 h-4" /> Add a Bank Card/Account
          </button>
        </div>
      </div>
    </MobileLayout>
  )
}
