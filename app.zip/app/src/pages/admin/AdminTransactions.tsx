import { useAuth } from "@/hooks/useAuth"
import { trpc } from "@/providers/trpc"
import { Link, useNavigate } from "react-router"
import { useEffect, useState } from "react"
import {
  Activity, ArrowLeft,
  BarChart3, Users, Shield
} from "lucide-react"
import { cn } from "@/lib/utils"

export default function AdminTransactions() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const [offset] = useState(0)
  const [status, setStatus] = useState("")

  useEffect(() => {
    if (user && user.role !== "admin") navigate("/")
  }, [user, navigate])

  const { data } = trpc.admin.getTransactions.useQuery({
    limit: 50,
    offset,
    status: status || undefined,
  }, { enabled: user?.role === "admin" })

  const transactions = data?.transactions || []
  const total = data?.total || 0

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-gray-900 text-white px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/admin")} className="lg:hidden">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-bold text-lg">Transactions</h1>
        </div>
      </header>

      <div className="flex">
        <aside className="hidden lg:flex w-64 bg-white min-h-[calc(100vh-48px)] border-r flex-col">
          <nav className="p-4 space-y-1">
            {[
              { icon: BarChart3, label: "Dashboard", path: "/admin" },
              { icon: Users, label: "Users", path: "/admin/users" },
              { icon: Activity, label: "Transactions", path: "/admin/transactions", active: true },
              { icon: Shield, label: "KYC Reviews", path: "/admin/kyc" },
            ].map((item) => {
              const Icon = item.icon
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                    item.active ? "bg-emerald-50 text-emerald-600" : "text-gray-600 hover:bg-gray-50"
                  )}
                >
                  <Icon className="w-4 h-4" /> {item.label}
                </Link>
              )
            })}
          </nav>
        </aside>

        <main className="flex-1 p-4 lg:p-6">
          <div className="mb-4">
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="px-3 py-2 border rounded-lg text-sm"
            >
              <option value="">All Status</option>
              <option value="successful">Successful</option>
              <option value="pending">Pending</option>
              <option value="failed">Failed</option>
            </select>
          </div>

          <div className="bg-white rounded-xl shadow-sm">
            <div className="p-4 border-b">
              <h3 className="font-semibold">Transactions ({total})</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">User</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Type</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Amount</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Status</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {transactions.map((tx: any) => (
                    <tr key={tx.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm">{tx.user?.name || "N/A"}</td>
                      <td className="px-4 py-3 text-sm capitalize">{tx.type.replace("_", " ")}</td>
                      <td className="px-4 py-3 text-sm font-medium">₦{parseFloat(tx.amount).toLocaleString()}</td>
                      <td className="px-4 py-3">
                        <span className={cn(
                          "text-xs px-2 py-1 rounded-full",
                          tx.status === "successful" ? "bg-emerald-100 text-emerald-600" :
                          tx.status === "pending" ? "bg-amber-100 text-amber-600" : "bg-red-100 text-red-600"
                        )}>
                          {tx.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-500">
                        {new Date(tx.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
