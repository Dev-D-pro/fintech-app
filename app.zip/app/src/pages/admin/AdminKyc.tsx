import { useAuth } from "@/hooks/useAuth"
import { trpc } from "@/providers/trpc"
import { Link, useNavigate } from "react-router"
import { useEffect, useState } from "react"
import {
  Shield, ArrowLeft, CheckCircle, XCircle, Clock,
  BarChart3, Users, Activity
} from "lucide-react"
import { cn } from "@/lib/utils"

export default function AdminKyc() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const [offset] = useState(0)

  useEffect(() => {
    if (user && user.role !== "admin") navigate("/")
  }, [user, navigate])

  const { data, refetch } = trpc.admin.getKycReviews.useQuery({
    limit: 50,
    offset,
  }, { enabled: user?.role === "admin" })

  const reviewMutation = trpc.kyc.reviewKyc.useMutation({
    onSuccess: () => refetch(),
  })

  const docs = data?.documents || []

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-gray-900 text-white px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/admin")} className="lg:hidden">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-bold text-lg">KYC Reviews</h1>
        </div>
      </header>

      <div className="flex">
        <aside className="hidden lg:flex w-64 bg-white min-h-[calc(100vh-48px)] border-r flex-col">
          <nav className="p-4 space-y-1">
            {[
              { icon: BarChart3, label: "Dashboard", path: "/admin" },
              { icon: Users, label: "Users", path: "/admin/users" },
              { icon: Activity, label: "Transactions", path: "/admin/transactions" },
              { icon: Shield, label: "KYC Reviews", path: "/admin/kyc", active: true },
            ].map((item) => {
              const Icon = item.icon
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                    item.active ? "bg-emerald-50 text-emerald-600" : "text-gray-600 hover:bg-gray-50"
                  )}
                >
                  <Icon className="w-4 h-4" /> {item.label}
                </Link>
              )
            })}
          </nav>
        </aside>

        <main className="flex-1 p-4 lg:p-6">
          <div className="bg-white rounded-xl shadow-sm">
            <div className="p-4 border-b">
              <h3 className="font-semibold">Pending KYC Reviews</h3>
            </div>
            <div className="divide-y">
              {docs.map((doc: any) => (
                <div key={doc.id} className="flex items-center gap-3 p-4">
                  <div className="w-10 h-10 rounded-full bg-amber-50 flex items-center justify-center">
                    <Clock className="w-5 h-5 text-amber-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{doc.user?.name || "User"}</p>
                    <p className="text-xs text-gray-400">{doc.type.toUpperCase()} · {doc.documentNumber || "N/A"}</p>
                    <p className="text-xs text-gray-400">
                      Submitted {new Date(doc.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => reviewMutation.mutate({ documentId: doc.id, status: "verified" })}
                      className="p-2 rounded-lg bg-emerald-100 text-emerald-600 hover:bg-emerald-200"
                    >
                      <CheckCircle className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => reviewMutation.mutate({ documentId: doc.id, status: "rejected", reviewNotes: "Invalid document" })}
                      className="p-2 rounded-lg bg-red-100 text-red-600 hover:bg-red-200"
                    >
                      <XCircle className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
              {docs.length === 0 && (
                <p className="p-6 text-center text-gray-400">No pending KYC reviews</p>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
