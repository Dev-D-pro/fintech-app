import { useAuth } from "@/hooks/useAuth"
import { trpc } from "@/providers/trpc"
import { Link, useNavigate } from "react-router"
import { useEffect, useState } from "react"
import {
  Users, ArrowLeft, Search, Shield,
  BarChart3, Activity
} from "lucide-react"
import { cn } from "@/lib/utils"

export default function AdminUsers() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const [search, setSearch] = useState("")
  const [offset, setOffset] = useState(0)
  const [tier, setTier] = useState("")

  useEffect(() => {
    if (user && user.role !== "admin") navigate("/")
  }, [user, navigate])

  const { data } = trpc.admin.getUsers.useQuery({
    limit: 20,
    offset,
    search: search || undefined,
    tier: tier || undefined,
  }, { enabled: user?.role === "admin" })

  const users = data?.users || []
  const total = data?.total || 0

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-gray-900 text-white px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/admin")} className="lg:hidden">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-bold text-lg">Users</h1>
        </div>
      </header>

      <div className="flex">
        <aside className="hidden lg:flex w-64 bg-white min-h-[calc(100vh-48px)] border-r flex-col">
          <nav className="p-4 space-y-1">
            {[
              { icon: BarChart3, label: "Dashboard", path: "/admin" },
              { icon: Users, label: "Users", path: "/admin/users", active: true },
              { icon: Activity, label: "Transactions", path: "/admin/transactions" },
              { icon: Shield, label: "KYC Reviews", path: "/admin/kyc" },
            ].map((item) => {
              const Icon = item.icon
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                    item.active ? "bg-emerald-50 text-emerald-600" : "text-gray-600 hover:bg-gray-50"
                  )}
                >
                  <Icon className="w-4 h-4" /> {item.label}
                </Link>
              )
            })}
          </nav>
        </aside>

        <main className="flex-1 p-4 lg:p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search users..."
                className="w-full pl-9 pr-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <select
              value={tier}
              onChange={(e) => setTier(e.target.value)}
              className="px-3 py-2 border rounded-lg text-sm"
            >
              <option value="">All Tiers</option>
              <option value="tier1">Tier 1</option>
              <option value="tier2">Tier 2</option>
              <option value="tier3">Tier 3</option>
            </select>
          </div>

          <div className="bg-white rounded-xl shadow-sm">
            <div className="p-4 border-b">
              <h3 className="font-semibold">Users ({total})</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Name</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Email</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Tier</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">KYC</th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500">Balance</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {users.map((u: any) => (
                    <tr key={u.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm font-medium">{u.name || "N/A"}</td>
                      <td className="px-4 py-3 text-sm text-gray-500">{u.email || "N/A"}</td>
                      <td className="px-4 py-3">
                        <span className="text-xs bg-emerald-100 text-emerald-600 px-2 py-1 rounded-full">
                          {u.tier?.replace("tier", "Tier ")}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={cn(
                          "text-xs px-2 py-1 rounded-full",
                          u.kycStatus === "verified" ? "bg-emerald-100 text-emerald-600" : "bg-amber-100 text-amber-600"
                        )}>
                          {u.kycStatus}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right text-sm font-medium">
                        ₦{parseFloat(u.wallet?.balance || "0").toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {total > offset + 20 && (
            <div className="mt-4 text-center">
              <button onClick={() => setOffset(offset + 20)} className="text-sm text-emerald-600 font-medium">
                Load More
              </button>
            </div>
          )}
        </main>
      </div>
    </div>
  )
}
