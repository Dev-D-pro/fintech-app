import { useAuth } from "@/hooks/useAuth"
import { trpc } from "@/providers/trpc"
import { Link, useNavigate } from "react-router"
import { useEffect } from "react"
import {
  Users, TrendingUp, Wallet, Shield, ArrowUpRight,
  BarChart3, Activity, ArrowLeft, Bell
} from "lucide-react"
import { cn } from "@/lib/utils"

export default function AdminDashboard() {
  const navigate = useNavigate()
  const { user } = useAuth()

  useEffect(() => {
    if (user && user.role !== "admin") {
      navigate("/")
    }
  }, [user, navigate])

  const { data: stats } = trpc.admin.getDashboardStats.useQuery(undefined, {
    enabled: user?.role === "admin",
  })

  const statCards = [
    { icon: Users, label: "Total Users", value: stats?.users?.total || 0, color: "bg-blue-500" },
    { icon: TrendingUp, label: "Transactions", value: stats?.transactions?.total || 0, color: "bg-emerald-500" },
    { icon: Wallet, label: "Total Volume", value: `₦${parseFloat(stats?.transactions?.totalVolume || "0").toLocaleString()}`, color: "bg-amber-500" },
    { icon: Shield, label: "Pending KYC", value: stats?.kyc?.pending || 0, color: "bg-red-500" },
  ]

  const recentTx = stats?.transactions?.recent || []

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-gray-900 text-white px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/")} className="lg:hidden">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-bold text-lg">NairaFlow Admin</h1>
        </div>
        <div className="flex items-center gap-3">
          <Bell className="w-5 h-5" />
          <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-sm font-bold">
            A
          </div>
        </div>
      </header>

      <div className="flex">
        <aside className="hidden lg:flex w-64 bg-white min-h-[calc(100vh-48px)] border-r flex-col">
          <nav className="p-4 space-y-1">
            {[
              { icon: BarChart3, label: "Dashboard", path: "/admin", active: true },
              { icon: Users, label: "Users", path: "/admin/users" },
              { icon: Activity, label: "Transactions", path: "/admin/transactions" },
              { icon: Shield, label: "KYC Reviews", path: "/admin/kyc" },
            ].map((item) => {
              const Icon = item.icon
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                    item.active
                      ? "bg-emerald-50 text-emerald-600"
                      : "text-gray-600 hover:bg-gray-50"
                  )}
                >
                  <Icon className="w-4 h-4" /> {item.label}
                </Link>
              )
            })}
          </nav>
        </aside>

        <main className="flex-1 p-4 lg:p-6">
          <h2 className="text-xl font-bold mb-6">Dashboard Overview</h2>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {statCards.map((card) => {
              const Icon = card.icon
              return (
                <div key={card.label} className="bg-white rounded-xl p-4 shadow-sm">
                  <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center mb-3", card.color)}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <p className="text-2xl font-bold">{card.value}</p>
                  <p className="text-xs text-gray-500">{card.label}</p>
                </div>
              )
            })}
          </div>

          <div className="bg-white rounded-xl shadow-sm">
            <div className="p-4 border-b flex items-center justify-between">
              <h3 className="font-semibold">Recent Transactions</h3>
              <Link to="/admin/transactions" className="text-sm text-emerald-600">View All</Link>
            </div>
            <div className="divide-y">
              {recentTx.slice(0, 5).map((tx: any) => (
                <div key={tx.id} className="flex items-center gap-3 p-4">
                  <div className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center",
                    tx.type === "transfer_in" ? "bg-emerald-100 text-emerald-600" : "bg-red-100 text-red-600"
                  )}>
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{tx.description || tx.type}</p>
                    <p className="text-xs text-gray-400">{tx.user?.name || "User"}</p>
                  </div>
                  <p className="text-sm font-semibold">₦{parseFloat(tx.amount).toLocaleString()}</p>
                </div>
              ))}
              {recentTx.length === 0 && (
                <p className="p-6 text-center text-gray-400 text-sm">No recent transactions</p>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
