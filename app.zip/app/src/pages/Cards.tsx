import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { ArrowLeft, CreditCard, Plus, Snowflake, Power } from "lucide-react";

export default function Cards() {
  const navigate = useNavigate();
  const { user } = useAuth({ redirectOnUnauthenticated: true });
  const [showCreate, setShowCreate] = useState(false);
  const [cardName, setCardName] = useState("");
  const [cardType, setCardType] = useState("virtual");

  const { data: cards, refetch } = trpc.card.getCards.useQuery(undefined, { enabled: !!user });

  const applyForCard = trpc.card.applyForCard.useMutation({
    onSuccess: () => {
      toast.success("Card created!");
      setShowCreate(false);
      setCardName("");
      refetch();
    },
    onError: (error) => toast.error(error.message),
  });

  const freezeCard = trpc.card.freezeCard.useMutation({
    onSuccess: () => {
      toast.success("Card frozen");
      refetch();
    },
  });

  const unfreezeCard = trpc.card.unfreezeCard.useMutation({
    onSuccess: () => {
      toast.success("Card unfrozen");
      refetch();
    },
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cardName) {
      toast.error("Enter card name");
      return;
    }
    applyForCard.mutate({
      cardType: cardType as any,
      cardName,
      cardBrand: "verve",
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-emerald-600 text-white px-4 py-4 flex items-center gap-3">
        <button onClick={() => navigate("/dashboard")} className="p-1 rounded-full hover:bg-white/20">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-lg font-semibold">My Cards</h1>
        <button
          onClick={() => setShowCreate(!showCreate)}
          className="ml-auto p-1.5 rounded-full bg-white/20 hover:bg-white/30"
        >
          <Plus className="w-5 h-5" />
        </button>
      </div>

      <div className="p-4 space-y-4">
        {/* Create Card Form */}
        {showCreate && (
          <Card>
            <CardContent className="p-4">
              <h3 className="font-semibold mb-3">Create New Card</h3>
              <form onSubmit={handleCreate} className="space-y-3">
                <div>
                  <Label>Card Name</Label>
                  <Input value={cardName} onChange={(e) => setCardName(e.target.value)} placeholder="e.g. Shopping Card" />
                </div>
                <div>
                  <Label>Card Type</Label>
                  <div className="flex gap-2 mt-1">
                    <button
                      type="button"
                      onClick={() => setCardType("virtual")}
                      className={`flex-1 py-2 rounded-lg border text-sm font-medium transition ${
                        cardType === "virtual" ? "border-emerald-500 bg-emerald-50 text-emerald-700" : "border-gray-200"
                      }`}
                    >
                      Virtual
                    </button>
                    <button
                      type="button"
                      onClick={() => setCardType("physical")}
                      className={`flex-1 py-2 rounded-lg border text-sm font-medium transition ${
                        cardType === "physical" ? "border-emerald-500 bg-emerald-50 text-emerald-700" : "border-gray-200"
                      }`}
                    >
                      Physical
                    </button>
                  </div>
                </div>
                <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700">
                  Create Card
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Cards List */}
        <div className="space-y-3">
          {cards?.map((card: any) => (
            <Card key={card.id} className={`overflow-hidden ${card.status === "frozen" ? "opacity-70" : ""}`}>
              <CardContent className="p-4">
                <div className="bg-gradient-to-r from-emerald-600 to-emerald-800 rounded-xl p-4 text-white mb-4">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs opacity-80 capitalize">{card.cardType}</span>
                    <CreditCard className="w-6 h-6" />
                  </div>
                  <p className="text-lg font-mono tracking-wider mb-2">
                    {card.maskedPan || "**** **** **** ****"}
                  </p>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-[10px] opacity-70">CARDHOLDER</p>
                      <p className="text-xs font-medium">{card.cardName}</p>
                    </div>
                    <div>
                      <p className="text-[10px] opacity-70">EXPIRES</p>
                      <p className="text-xs font-medium">{card.expiryMonth || "**"}/{card.expiryYear?.slice(-2) || "**"}</p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  {card.status === "active" ? (
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      onClick={() => freezeCard.mutate({ id: card.id })}
                    >
                      <Snowflake className="w-3 h-3 mr-1" /> Freeze
                    </Button>
                  ) : card.status === "frozen" ? (
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      onClick={() => unfreezeCard.mutate({ id: card.id })}
                    >
                      <Power className="w-3 h-3 mr-1" /> Unfreeze
                    </Button>
                  ) : null}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {(!cards || cards.length === 0) && !showCreate && (
          <div className="text-center py-12 text-gray-500">
            <CreditCard className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>No cards yet</p>
            <Button onClick={() => setShowCreate(true)} className="mt-3 bg-emerald-600">
              Create Card
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
