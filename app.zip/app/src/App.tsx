import { Routes, Route } from 'react-router'
import Home from './pages/Home'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Transfer from './pages/Transfer'
import BankTransfer from './pages/BankTransfer'
import TransactionHistory from './pages/TransactionHistory'
import TransactionSlip from './pages/TransactionSlip'
import KYC from './pages/KYC'
import Profile from './pages/Profile'
import Notifications from './pages/Notifications'
import Airtime from './pages/Airtime'
import Data from './pages/Data'
import Bills from './pages/Bills'
import Savings from './pages/Savings'
import Cards from './pages/Cards'
import Funding from './pages/Funding'
import Admin from './pages/Admin'
import NotFound from './pages/NotFound'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/transfer" element={<Transfer />} />
      <Route path="/transfer/bank" element={<BankTransfer />} />
      <Route path="/transactions" element={<TransactionHistory />} />
      <Route path="/transaction/:id" element={<TransactionSlip />} />
      <Route path="/kyc" element={<KYC />} />
      <Route path="/profile" element={<Profile />} />
      <Route path="/notifications" element={<Notifications />} />
      <Route path="/airtime" element={<Airtime />} />
      <Route path="/data" element={<Data />} />
      <Route path="/bills" element={<Bills />} />
      <Route path="/savings" element={<Savings />} />
      <Route path="/cards" element={<Cards />} />
      <Route path="/funding" element={<Funding />} />
      <Route path="/admin" element={<Admin />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
