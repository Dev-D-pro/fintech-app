import { Link, useLocation } from "react-router"
import { Home, Gift, TrendingUp, CreditCard, User } from "lucide-react"
import { cn } from "@/lib/utils"

interface MobileLayoutProps {
  children: React.ReactNode
  hideNav?: boolean
}

export function MobileLayout({ children, hideNav = false }: MobileLayoutProps) {
  const location = useLocation()
  const path = location.pathname

  const navItems = [
    { path: "/", label: "Home", icon: Home },
    { path: "/rewards", label: "Rewards", icon: Gift },
    { path: "/savings", label: "Finance", icon: TrendingUp },
    { path: "/cards", label: "Cards", icon: CreditCard },
    { path: "/profile", label: "Me", icon: User },
  ]

  return (
    <div className="min-h-screen bg-gray-50 flex justify-center">
      <div className="w-full max-w-md bg-white min-h-screen shadow-xl relative">
        <main className="pb-20">{children}</main>

        {!hideNav && (
          <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-4 py-2 z-50 max-w-md mx-auto">
            <div className="flex justify-around items-center">
              {navItems.map((item) => {
                const isActive = path === item.path || path.startsWith(item.path + "/")
                const Icon = item.icon
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={cn(
                      "flex flex-col items-center gap-0.5 py-1 px-2 rounded-lg transition-colors",
                      isActive ? "text-emerald-600" : "text-gray-400 hover:text-gray-600"
                    )}
                  >
                    <Icon className={cn("w-5 h-5", isActive && "fill-current")} />
                    <span className="text-[10px] font-medium">{item.label}</span>
                  </Link>
                )
              })}
            </div>
          </nav>
        )}
      </div>
    </div>
  )
}
