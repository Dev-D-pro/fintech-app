import { cn } from "@/lib/utils"

interface LoadingProps {
  fullScreen?: boolean
  size?: "sm" | "md" | "lg"
  className?: string
}

export function LoadingSpinner({ fullScreen = false, size = "md", className }: LoadingProps) {
  const sizeClasses = {
    sm: "w-5 h-5 border-2",
    md: "w-8 h-8 border-3",
    lg: "w-12 h-12 border-4",
  }

  const spinner = (
    <div
      className={cn(
        "border-emerald-600 border-t-transparent rounded-full animate-spin",
        sizeClasses[size],
        className
      )}
    />
  )

  if (fullScreen) {
    return (
      <div className="fixed inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center z-50">
        <div className="flex flex-col items-center gap-3">
          {spinner}
          <p className="text-sm text-gray-500 animate-pulse">Loading...</p>
        </div>
      </div>
    )
  }

  return spinner
}

export function SkeletonCard({ className }: { className?: string }) {
  return (
    <div className={cn("bg-white rounded-xl p-4 space-y-3", className)}>
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full skeleton" />
        <div className="flex-1 space-y-2">
          <div className="h-4 w-1/3 skeleton" />
          <div className="h-3 w-1/2 skeleton" />
        </div>
      </div>
    </div>
  )
}

export function SkeletonList({ count = 3 }: { count?: number }) {
  return (
    <div className="space-y-2">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="flex items-center gap-3 p-3 bg-white rounded-xl">
          <div className="w-10 h-10 rounded-full skeleton" />
          <div className="flex-1 space-y-2">
            <div className="h-4 w-2/3 skeleton" />
            <div className="h-3 w-1/3 skeleton" />
          </div>
          <div className="h-4 w-16 skeleton" />
        </div>
      ))}
    </div>
  )
}

export function PageLoader() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="relative w-16 h-16">
          <div className="absolute inset-0 border-4 border-emerald-100 rounded-full" />
          <div className="absolute inset-0 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
        </div>
        <p className="text-sm text-gray-500 font-medium animate-pulse">Loading NairaFlow...</p>
      </div>
    </div>
  )
}
