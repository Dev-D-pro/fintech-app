import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { bankAccounts, beneficiaries } from "@db/schema";
import { eq, desc, and } from "drizzle-orm";

export const bankAccountRouter = createRouter({
  getBankAccounts: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const accounts = await db.query.bankAccounts.findMany({
      where: and(
        eq(bankAccounts.userId, ctx.user.id),
        eq(bankAccounts.isActive, true)
      ),
      orderBy: [desc(bankAccounts.isDefault), desc(bankAccounts.createdAt)],
    });
    return accounts;
  }),

  addBankAccount: authedQuery
    .input(
      z.object({
        bankName: z.string().min(1).max(255),
        bankCode: z.string().min(1).max(20),
        accountNumber: z.string().min(10).max(20),
        accountName: z.string().min(1).max(255),
        isDefault: z.boolean().default(false),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      if (input.isDefault) {
        await db
          .update(bankAccounts)
          .set({ isDefault: false })
          .where(eq(bankAccounts.userId, ctx.user.id));
      }

      const [account] = await db.insert(bankAccounts).values({
        userId: ctx.user.id,
        bankName: input.bankName,
        bankCode: input.bankCode,
        accountNumber: input.accountNumber,
        accountName: input.accountName,
        isDefault: input.isDefault,
      }).$returningId();

      return { success: true, accountId: account.id };
    }),

  deleteBankAccount: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db
        .update(bankAccounts)
        .set({ isActive: false })
        .where(
          and(
            eq(bankAccounts.id, input.id),
            eq(bankAccounts.userId, ctx.user.id)
          )
        );
      return { success: true };
    }),

  getBeneficiaries: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const bene = await db.query.beneficiaries.findMany({
      where: eq(beneficiaries.userId, ctx.user.id),
      orderBy: [desc(beneficiaries.isFavorite), desc(beneficiaries.createdAt)],
    });
    return bene;
  }),

  addBeneficiary: authedQuery
    .input(
      z.object({
        name: z.string().min(1).max(255),
        accountNumber: z.string().min(10).max(20),
        bankCode: z.string().min(1).max(20),
        bankName: z.string().min(1).max(255),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [bene] = await db.insert(beneficiaries).values({
        userId: ctx.user.id,
        name: input.name,
        accountNumber: input.accountNumber,
        bankCode: input.bankCode,
        bankName: input.bankName,
      }).$returningId();

      return { success: true, beneficiaryId: bene.id };
    }),

  deleteBeneficiary: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db
        .delete(beneficiaries)
        .where(
          and(
            eq(beneficiaries.id, input.id),
            eq(beneficiaries.userId, ctx.user.id)
          )
        );
      return { success: true };
    }),
});
