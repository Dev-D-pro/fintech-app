import * as cookie from "cookie";
import { z } from "zod";
import { Session } from "@contracts/constants";
import { env } from "./lib/env";
import { getSessionCookieOptions } from "./lib/cookies";
import { createRouter, authedQuery, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { users } from "@db/schema";
import { eq } from "drizzle-orm";
import { cacheInvalidatePattern } from "./lib/redis";

function buildKimiLoginUrl(redirectUri: string) {
  const params = new URLSearchParams({
    client_id: env.appId,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "profile",
    state: btoa(redirectUri),
  });
  return `${env.kimiAuthUrl}/api/oauth/authorize?${params.toString()}`;
}

function buildGoogleLoginUrl(redirectUri: string) {
  const params = new URLSearchParams({
    client_id: env.googleClientId,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "openid email profile",
    state: btoa(redirectUri),
  });
  return `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
}

export const authRouter = createRouter({
  me: authedQuery.query((opts) => opts.ctx.user),

  logout: authedQuery.mutation(async ({ ctx }) => {
    const opts = getSessionCookieOptions(ctx.req.headers);
    ctx.resHeaders.append(
      "set-cookie",
      cookie.serialize(Session.cookieName, "", {
        httpOnly: opts.httpOnly,
        path: opts.path,
        sameSite: opts.sameSite?.toLowerCase() as "lax" | "none",
        secure: opts.secure,
        maxAge: 0,
      }),
    );
    return { success: true };
  }),

  getAuthUrl: publicQuery
    .input(
      z.object({
        redirectUri: z.string().default("http://localhost:3000/api/oauth/callback"),
        provider: z.enum(["kimi", "google"]).default("kimi"),
      })
    )
    .query(({ input }) => {
      const redirectUri = input.redirectUri;

      if (input.provider === "google") {
        if (!env.googleClientId) {
          throw new Error("Google OAuth not configured");
        }
        return {
          url: buildGoogleLoginUrl(redirectUri),
          provider: "google",
        };
      }

      return {
        url: buildKimiLoginUrl(redirectUri),
        provider: "kimi",
      };
    }),

  updateProfile: authedQuery
    .input(
      z.object({
        name: z.string().min(1).max(255).optional(),
        phone: z.string().min(10).max(20).optional(),
        address: z.string().optional(),
        avatar: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const updateData: Record<string, any> = {};
      if (input.name) updateData.name = input.name;
      if (input.phone) updateData.phone = input.phone;
      if (input.address) updateData.address = input.address;
      if (input.avatar) updateData.avatar = input.avatar;

      if (Object.keys(updateData).length > 0) {
        updateData.updatedAt = new Date();
        await db
          .update(users)
          .set(updateData)
          .where(eq(users.id, ctx.user.id));
      }

      await cacheInvalidatePattern(`user:${ctx.user.id}:*`);
      return { success: true };
    }),

  getUserProfile: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const user = await db.query.users.findFirst({
      where: eq(users.id, ctx.user.id),
      with: {
        wallet: true,
        virtualAccount: true,
        bankAccounts: true,
        cards: true,
        savingsGoals: true,
      },
    });
    return user;
  }),
});
