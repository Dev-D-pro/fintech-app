import { createRouter } from "./middleware";
import { authRouter } from "./auth-router";
import { walletRouter } from "./wallet-router";
import { paystackRouter } from "./paystack-router";
import { kycRouter } from "./kyc-router";
import { savingsRouter } from "./savings-router";
import { cardRouter } from "./card-router";
import { airtimeRouter } from "./airtime-router";
import { billsRouter } from "./bills-router";
import { bankAccountRouter } from "./bank-router";
import { notificationRouter } from "./notification-router";
import { adminRouter } from "./admin-router";
import { dataRouter } from "./data-router";

export const appRouter = createRouter({
  auth: authRouter,
  wallet: walletRouter,
  paystack: paystackRouter,
  kyc: kycRouter,
  savings: savingsRouter,
  card: cardRouter,
  airtime: airtimeRouter,
  data: dataRouter,
  bills: billsRouter,
  bank: bankAccountRouter,
  notification: notificationRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
