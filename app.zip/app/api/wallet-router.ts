import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { wallets, transactions, users } from "@db/schema";
import { eq, desc, and, gte, sql } from "drizzle-orm";
import { cacheGet, cacheSet, cacheInvalidatePattern } from "./lib/redis";
import { nanoid } from "nanoid";
import { sendEmail, getTransactionEmailTemplate } from "./lib/email";

export const walletRouter = createRouter({
  getBalance: authedQuery.query(async ({ ctx }) => {
    const cacheKey = `wallet:${ctx.user.id}:balance`;
    const cached = await cacheGet(cacheKey);
    if (cached) {
      return JSON.parse(cached);
    }

    const db = getDb();
    const wallet = await db.query.wallets.findFirst({
      where: eq(wallets.userId, ctx.user.id),
    });

    if (!wallet) {
      await db.insert(wallets).values({
        userId: ctx.user.id,
        balance: "0.00",
        owealthBalance: "0.00",
        currency: "NGN",
      });

      const newWallet = await db.query.wallets.findFirst({
        where: eq(wallets.userId, ctx.user.id),
      });

      const result = {
        balance: newWallet?.balance || "0.00",
        owealthBalance: newWallet?.owealthBalance || "0.00",
        currency: newWallet?.currency || "NGN",
      };
      await cacheSet(cacheKey, JSON.stringify(result), 60);
      return result;
    }

    const result = {
      balance: wallet.balance,
      owealthBalance: wallet.owealthBalance,
      currency: wallet.currency,
    };
    await cacheSet(cacheKey, JSON.stringify(result), 60);
    return result;
  }),

  getTransactions: authedQuery
    .input(
      z.object({
        limit: z.number().min(1).max(100).default(20),
        offset: z.number().min(0).default(0),
        type: z.string().optional(),
        category: z.string().optional(),
        status: z.string().optional(),
        startDate: z.string().optional(),
        endDate: z.string().optional(),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const conditions = [eq(transactions.userId, ctx.user.id)];

      if (input.type) {
        conditions.push(eq(transactions.type, input.type as any));
      }
      if (input.category) {
        conditions.push(eq(transactions.category, input.category as any));
      }
      if (input.status) {
        conditions.push(eq(transactions.status, input.status as any));
      }
      if (input.startDate) {
        conditions.push(gte(transactions.createdAt, new Date(input.startDate)));
      }

      const txs = await db.query.transactions.findMany({
        where: and(...conditions),
        orderBy: [desc(transactions.createdAt)],
        limit: input.limit,
        offset: input.offset,
      });

      const totalResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(transactions)
        .where(and(...conditions));

      const total = totalResult[0]?.count || 0;

      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const monthlyResult = await db
        .select({
          type: transactions.type,
          total: sql<string>`sum(${transactions.amount})`,
        })
        .from(transactions)
        .where(
          and(
            eq(transactions.userId, ctx.user.id),
            eq(transactions.status, "successful"),
            gte(transactions.createdAt, startOfMonth)
          )
        )
        .groupBy(transactions.type);

      const monthlyIn = monthlyResult
        .filter((r) => ["transfer_in", "deposit", "interest", "bonus", "refund"].includes(r.type))
        .reduce((sum, r) => sum + parseFloat(r.total || "0"), 0);

      const monthlyOut = monthlyResult
        .filter((r) => !["transfer_in", "deposit", "interest", "bonus", "refund"].includes(r.type))
        .reduce((sum, r) => sum + parseFloat(r.total || "0"), 0);

      return {
        transactions: txs,
        total,
        monthlyStats: {
          in: monthlyIn,
          out: monthlyOut,
        },
      };
    }),

  getTransactionById: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const tx = await db.query.transactions.findFirst({
        where: and(
          eq(transactions.id, input.id),
          eq(transactions.userId, ctx.user.id)
        ),
      });

      if (!tx) {
        throw new Error("Transaction not found");
      }

      return tx;
    }),

  getTransactionStats: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfYear = new Date(now.getFullYear(), 0, 1);

    const [monthlyStats, yearlyStats] = await Promise.all([
      db
        .select({
          type: transactions.type,
          total: sql<string>`sum(${transactions.amount})`,
          count: sql<number>`count(*)`,
        })
        .from(transactions)
        .where(
          and(
            eq(transactions.userId, ctx.user.id),
            eq(transactions.status, "successful"),
            gte(transactions.createdAt, startOfMonth)
          )
        )
        .groupBy(transactions.type),
      db
        .select({
          type: transactions.type,
          total: sql<string>`sum(${transactions.amount})`,
          count: sql<number>`count(*)`,
        })
        .from(transactions)
        .where(
          and(
            eq(transactions.userId, ctx.user.id),
            eq(transactions.status, "successful"),
            gte(transactions.createdAt, startOfYear)
          )
        )
        .groupBy(transactions.type),
    ]);

    return { monthlyStats, yearlyStats };
  }),

  walletTransfer: authedQuery
    .input(
      z.object({
        recipientEmail: z.string().email(),
        amount: z.number().min(10).max(5000000),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const reference = `WLT_${nanoid(16)}`;

      const senderWallet = await db.query.wallets.findFirst({
        where: eq(wallets.userId, ctx.user.id),
      });

      if (!senderWallet || parseFloat(senderWallet.balance) < input.amount) {
        throw new Error("Insufficient balance");
      }

      const recipient = await db.query.users.findFirst({
        where: eq(users.email, input.recipientEmail),
      });

      if (!recipient) {
        throw new Error("Recipient not found");
      }

      if (recipient.id === ctx.user.id) {
        throw new Error("Cannot transfer to yourself");
      }

      let recipientWallet = await db.query.wallets.findFirst({
        where: eq(wallets.userId, recipient.id),
      });

      if (!recipientWallet) {
        await db.insert(wallets).values({
          userId: recipient.id,
          balance: "0.00",
          owealthBalance: "0.00",
          currency: "NGN",
        });
        recipientWallet = await db.query.wallets.findFirst({
          where: eq(wallets.userId, recipient.id),
        });
      }

      const newSenderBalance = (parseFloat(senderWallet.balance) - input.amount).toFixed(2);
      const newRecipientBalance = (parseFloat(recipientWallet!.balance) + input.amount).toFixed(2);

      await db
        .update(wallets)
        .set({ balance: newSenderBalance, updatedAt: new Date() })
        .where(eq(wallets.userId, ctx.user.id));

      await db
        .update(wallets)
        .set({ balance: newRecipientBalance, updatedAt: new Date() })
        .where(eq(wallets.userId, recipient.id));

      await db.insert(transactions).values({
        userId: ctx.user.id,
        type: "transfer_out",
        amount: input.amount.toFixed(2),
        fee: "0.00",
        totalAmount: input.amount.toFixed(2),
        status: "successful",
        reference,
        recipientName: recipient.name || recipient.email,
        recipientAccount: recipient.email,
        description: input.description || "Wallet transfer",
        category: "transfer",
      });

      await db.insert(transactions).values({
        userId: recipient.id,
        type: "transfer_in",
        amount: input.amount.toFixed(2),
        fee: "0.00",
        totalAmount: input.amount.toFixed(2),
        status: "successful",
        reference: `WLT_${nanoid(16)}`,
        recipientName: ctx.user.name || ctx.user.email,
        recipientAccount: ctx.user.email,
        description: input.description || "Wallet transfer received",
        category: "transfer",
      });

      await cacheInvalidatePattern(`wallet:${ctx.user.id}:*`);
      await cacheInvalidatePattern(`wallet:${recipient.id}:*`);

      // Send email notifications
      if (ctx.user.email) {
        const template = getTransactionEmailTemplate({
          name: ctx.user.name || "User",
          type: "transfer_out",
          amount: input.amount.toFixed(2),
          reference,
          date: new Date().toLocaleString(),
          description: input.description || "Wallet transfer",
          balance: newSenderBalance,
        });
        await sendEmail({ to: ctx.user.email, ...template });
      }

      if (recipient.email) {
        const template = getTransactionEmailTemplate({
          name: recipient.name || "User",
          type: "transfer_in",
          amount: input.amount.toFixed(2),
          reference,
          date: new Date().toLocaleString(),
          description: input.description || "Wallet transfer received",
          balance: newRecipientBalance,
        });
        await sendEmail({ to: recipient.email, ...template });
      }

      return { success: true, reference, newBalance: newSenderBalance };
    }),
});
