import { z } from "zod";
import { createRouter, authedQuery, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { paystackTransactions, transactions, wallets, virtualAccounts, users, notifications, beneficiaries } from "@db/schema";
import { eq } from "drizzle-orm";
import {
  initializeTransaction,
  verifyTransaction,
  listBanks,
  verifyAccountNumber,
  createTransferRecipient,
  initiateTransfer,
  verifyTransfer,
  createCustomer,
  fetchCustomer,
  createDedicatedVirtualAccount,
} from "./lib/paystack";
import { cacheGet, cacheSet, cacheInvalidatePattern } from "./lib/redis";
import { nanoid } from "nanoid";
import { sendEmail, getTransactionEmailTemplate, getVirtualAccountCreatedTemplate } from "./lib/email";

export const paystackRouter = createRouter({
  initializePayment: authedQuery
    .input(
      z.object({
        amount: z.number().min(50).max(10000000),
        metadata: z.record(z.string(), z.any()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const email = ctx.user.email || `${ctx.user.unionId}@nairaflow.com`;
      const reference = `PSK_${nanoid(16)}`;
      const amountInKobo = Math.round(input.amount * 100);

      try {
        const result = await initializeTransaction({
          email,
          amount: amountInKobo,
          reference,
          metadata: {
            userId: ctx.user.id,
            ...input.metadata,
          },
        });

        if (result.status && result.data) {
          const db = getDb();
          await db.insert(paystackTransactions).values({
            userId: ctx.user.id,
            email,
            amount: input.amount.toFixed(2),
            reference,
            paystackRef: result.data.reference,
            authorizationUrl: result.data.authorization_url,
            accessCode: result.data.access_code,
            status: "pending",
            metadata: input.metadata || {},
          });

          return {
            success: true,
            authorizationUrl: result.data.authorization_url,
            reference,
          };
        }

        throw new Error(result.message || "Payment initialization failed");
      } catch (error: any) {
        console.error("Paystack initialize error:", error);
        throw new Error(error.message || "Payment initialization failed");
      }
    }),

  verifyPayment: publicQuery
    .input(z.object({ reference: z.string() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const pskTx = await db.query.paystackTransactions.findFirst({
        where: eq(paystackTransactions.reference, input.reference),
      });

      if (!pskTx) throw new Error("Transaction not found");
      if (pskTx.status === "success") {
        return { success: true, status: "success", amount: pskTx.amount };
      }

      try {
        const result = await verifyTransaction(input.reference);

        if (result.status && result.data) {
          const isSuccess = result.data.status === "success";

          await db
            .update(paystackTransactions)
            .set({
              status: isSuccess ? "success" : "failed",
              paystackRef: result.data.reference,
              verifiedAt: new Date(),
            })
            .where(eq(paystackTransactions.reference, input.reference));

          if (isSuccess) {
            const wallet = await db.query.wallets.findFirst({
              where: eq(wallets.userId, pskTx.userId),
            });

            if (wallet) {
              const amountFloat = parseFloat(pskTx.amount);
              const newBalance = (parseFloat(wallet.balance) + amountFloat).toFixed(2);

              await db
                .update(wallets)
                .set({ balance: newBalance, updatedAt: new Date() })
                .where(eq(wallets.userId, pskTx.userId));

              await db.insert(transactions).values({
                userId: pskTx.userId,
                type: "deposit",
                amount: pskTx.amount,
                fee: "0.00",
                totalAmount: pskTx.amount,
                status: "successful",
                reference: input.reference,
                paystackRef: result.data.reference,
                description: "Paystack deposit",
                category: "deposit",
              });

              await cacheInvalidatePattern(`wallet:${pskTx.userId}:*`);

              // Send email notification
              const user = await db.query.users.findFirst({
                where: eq(users.id, pskTx.userId),
              });
              if (user?.email) {
                const template = getTransactionEmailTemplate({
                  name: user.name || "User",
                  type: "deposit",
                  amount: pskTx.amount,
                  reference: input.reference,
                  date: new Date().toLocaleString(),
                  description: "Paystack deposit",
                  balance: newBalance,
                });
                await sendEmail({ to: user.email, ...template });
              }
            }
          }

          return {
            success: true,
            status: result.data.status,
            amount: (result.data.amount / 100).toFixed(2),
          };
        }

        throw new Error(result.message || "Verification failed");
      } catch (error: any) {
        console.error("Paystack verify error:", error);
        throw new Error(error.message || "Payment verification failed");
      }
    }),

  getBanks: publicQuery.query(async () => {
    const cacheKey = "paystack:banks";
    const cached = await cacheGet(cacheKey);
    if (cached) return JSON.parse(cached);

    try {
      const result = await listBanks({ country: "nigeria", perPage: 100 });
      if (result.status && result.data) {
        const banks = result.data
          .filter((b) => b.active && !b.is_deleted)
          .map((b) => ({
            id: b.id,
            name: b.name,
            code: b.code,
            slug: b.slug,
            logo: `https://nigerianbanks.xyz/logo/${b.slug}.png`,
          }));
        await cacheSet(cacheKey, JSON.stringify(banks), 86400);
        return banks;
      }
      return [];
    } catch (error) {
      console.error("Get banks error:", error);
      return [
        { id: 1, name: "Access Bank", code: "044", slug: "access-bank", logo: "https://nigerianbanks.xyz/logo/access-bank.png" },
        { id: 2, name: "First Bank of Nigeria", code: "011", slug: "first-bank", logo: "https://nigerianbanks.xyz/logo/first-bank.png" },
        { id: 3, name: "Guaranty Trust Bank", code: "058", slug: "gtbank", logo: "https://nigerianbanks.xyz/logo/gtbank.png" },
        { id: 4, name: "United Bank for Africa", code: "033", slug: "uba", logo: "https://nigerianbanks.xyz/logo/uba.png" },
        { id: 5, name: "Zenith Bank", code: "057", slug: "zenith-bank", logo: "https://nigerianbanks.xyz/logo/zenith-bank.png" },
        { id: 6, name: "Fidelity Bank", code: "070", slug: "fidelity-bank", logo: "https://nigerianbanks.xyz/logo/fidelity-bank.png" },
        { id: 7, name: "Union Bank", code: "032", slug: "union-bank", logo: "https://nigerianbanks.xyz/logo/union-bank.png" },
        { id: 8, name: "Sterling Bank", code: "232", slug: "sterling-bank", logo: "https://nigerianbanks.xyz/logo/sterling-bank.png" },
        { id: 9, name: "Ecobank", code: "050", slug: "ecobank", logo: "https://nigerianbanks.xyz/logo/ecobank.png" },
        { id: 10, name: "Stanbic IBTC Bank", code: "221", slug: "stanbic-ibtc", logo: "https://nigerianbanks.xyz/logo/stanbic-ibtc.png" },
        { id: 11, name: "Wema Bank", code: "035", slug: "wema-bank", logo: "https://nigerianbanks.xyz/logo/wema-bank.png" },
        { id: 12, name: "Polaris Bank", code: "076", slug: "polaris-bank", logo: "https://nigerianbanks.xyz/logo/polaris-bank.png" },
        { id: 13, name: "Keystone Bank", code: "082", slug: "keystone-bank", logo: "https://nigerianbanks.xyz/logo/keystone-bank.png" },
        { id: 14, name: "Unity Bank", code: "215", slug: "unity-bank", logo: "https://nigerianbanks.xyz/logo/unity-bank.png" },
        { id: 15, name: "Opay", code: "999992", slug: "opay", logo: "https://nigerianbanks.xyz/logo/opay.png" },
        { id: 16, name: "Palmpay", code: "999993", slug: "palmpay", logo: "https://nigerianbanks.xyz/logo/palmpay.png" },
        { id: 17, name: "Moniepoint", code: "999990", slug: "moniepoint", logo: "https://nigerianbanks.xyz/logo/moniepoint.png" },
      ];
    }
  }),

  verifyAccount: publicQuery
    .input(
      z.object({
        accountNumber: z.string().length(10),
        bankCode: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const result = await verifyAccountNumber(input.accountNumber, input.bankCode);
        if (result.status && result.data) {
          return {
            success: true,
            accountName: result.data.account_name,
            accountNumber: result.data.account_number,
          };
        }
        throw new Error(result.message || "Account verification failed");
      } catch (error: any) {
        console.error("Verify account error:", error);
        throw new Error(error.message || "Account verification failed");
      }
    }),

  bankTransfer: authedQuery
    .input(
      z.object({
        bankCode: z.string(),
        bankName: z.string(),
        accountNumber: z.string().length(10),
        accountName: z.string(),
        amount: z.number().min(10).max(5000000),
        description: z.string().optional(),
        saveAsBeneficiary: z.boolean().default(false),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const reference = `BNK_${nanoid(16)}`;

      const wallet = await db.query.wallets.findFirst({
        where: eq(wallets.userId, ctx.user.id),
      });

      if (!wallet || parseFloat(wallet.balance) < input.amount) {
        throw new Error("Insufficient balance");
      }

      try {
        const recipientResult = await createTransferRecipient({
          type: "nuban",
          name: input.accountName,
          account_number: input.accountNumber,
          bank_code: input.bankCode,
        });

        if (!recipientResult.status) {
          throw new Error(recipientResult.message || "Failed to create recipient");
        }

        const transferResult = await initiateTransfer({
          source: "balance",
          amount: Math.round(input.amount * 100),
          recipient: recipientResult.data.recipient_code,
          reason: input.description || "Bank transfer",
          reference,
        });

        if (transferResult.status && transferResult.data) {
          const newBalance = (parseFloat(wallet.balance) - input.amount).toFixed(2);

          await db
            .update(wallets)
            .set({ balance: newBalance, updatedAt: new Date() })
            .where(eq(wallets.userId, ctx.user.id));

          await db.insert(transactions).values({
            userId: ctx.user.id,
            type: "transfer_out",
            amount: input.amount.toFixed(2),
            fee: "0.00",
            totalAmount: input.amount.toFixed(2),
            status: "successful",
            reference,
            recipientName: input.accountName,
            recipientAccount: input.accountNumber,
            recipientBank: input.bankName,
            recipientBankCode: input.bankCode,
            description: input.description || "Bank transfer",
            category: "transfer",
          });

          if (input.saveAsBeneficiary) {
            await db.insert(beneficiaries).values({
              userId: ctx.user.id,
              name: input.accountName,
              accountNumber: input.accountNumber,
              bankCode: input.bankCode,
              bankName: input.bankName,
            }).catch(() => {
              // Beneficiary may already exist
            });
          }

          await cacheInvalidatePattern(`wallet:${ctx.user.id}:*`);

          // Send email notification
          if (ctx.user.email) {
            const template = getTransactionEmailTemplate({
              name: ctx.user.name || "User",
              type: "transfer_out",
              amount: input.amount.toFixed(2),
              reference,
              date: new Date().toLocaleString(),
              description: input.description || "Bank transfer",
              balance: newBalance,
            });
            await sendEmail({ to: ctx.user.email, ...template });
          }

          return {
            success: true,
            reference,
            transferCode: transferResult.data.transfer_code,
            newBalance,
          };
        }

        throw new Error(transferResult.message || "Transfer failed");
      } catch (error: any) {
        console.error("Bank transfer error:", error);
        throw new Error(error.message || "Transfer failed");
      }
    }),

  getTransferStatus: authedQuery
    .input(z.object({ reference: z.string() }))
    .query(async ({ input }) => {
      try {
        const result = await verifyTransfer(input.reference);
        return {
          success: true,
          status: result.data.status,
          amount: (result.data.amount / 100).toFixed(2),
        };
      } catch (error: any) {
        return { success: false, error: error.message };
      }
    }),

  createVirtualAccount: authedQuery.mutation(async ({ ctx }) => {
    const db = getDb();

    // Check if user already has a virtual account
    const existing = await db.query.virtualAccounts.findFirst({
      where: eq(virtualAccounts.userId, ctx.user.id),
    });

    if (existing) {
      return { success: true, virtualAccount: existing };
    }

    const email = ctx.user.email || `${ctx.user.unionId}@nairaflow.com`;
    const firstName = ctx.user.name?.split(" ")[0] || "User";
    const lastName = ctx.user.name?.split(" ").slice(1).join(" ") || "NairaFlow";
    const phone = ctx.user.phone || "+2348000000000";

    try {
      // First check if customer exists
      let customerCode = "";
      try {
        const customer = await fetchCustomer(email);
        if (customer.status && customer.data) {
          customerCode = customer.data.customer_code;
        }
      } catch {
        // Customer doesn't exist
      }

      // Create customer if not found
      if (!customerCode) {
        const newCustomer = await createCustomer({
          email,
          first_name: firstName,
          last_name: lastName,
          phone,
        });
        if (newCustomer.status && newCustomer.data) {
          customerCode = newCustomer.data.customer_code;
        }
      }

      if (!customerCode) {
        throw new Error("Failed to create Paystack customer");
      }

      // Create dedicated virtual account
      const dvaResult = await createDedicatedVirtualAccount({
        customer: customerCode,
        preferred_bank: "titan-paystack",
        first_name: firstName,
        last_name: lastName,
        phone,
      });

      if (dvaResult.status && dvaResult.data) {
        const [va] = await db.insert(virtualAccounts).values({
          userId: ctx.user.id,
          customerCode,
          accountNumber: dvaResult.data.account_number,
          bankName: dvaResult.data.bank.name,
          bankSlug: dvaResult.data.bank.slug,
          active: true,
        }).$returningId();

        const newVa = await db.query.virtualAccounts.findFirst({
          where: eq(virtualAccounts.id, va.id),
        });

        // Send email notification
        if (ctx.user.email) {
          const template = getVirtualAccountCreatedTemplate(
            ctx.user.name || "User",
            dvaResult.data.account_number,
            dvaResult.data.bank.name
          );
          await sendEmail({ to: ctx.user.email, ...template });
        }

        // Create notification
        await db.insert(notifications).values({
          userId: ctx.user.id,
          type: "system",
          title: "Virtual Account Created",
          message: `Your dedicated virtual account (${dvaResult.data.account_number}) at ${dvaResult.data.bank.name} is now active. Transfer to this account to fund your wallet.`,
        });

        return { success: true, virtualAccount: newVa };
      }

      throw new Error(dvaResult.message || "Failed to create virtual account");
    } catch (error: any) {
      console.error("Virtual account error:", error);
      throw new Error(error.message || "Virtual account creation failed");
    }
  }),

  getVirtualAccount: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const va = await db.query.virtualAccounts.findFirst({
      where: eq(virtualAccounts.userId, ctx.user.id),
    });
    return va || null;
  }),
});
