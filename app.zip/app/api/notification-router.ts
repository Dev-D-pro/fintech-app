import { z } from "zod";
import { createRouter, authedQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { notifications, users } from "@db/schema";
import { eq, desc, and, sql } from "drizzle-orm";

export const notificationRouter = createRouter({
  getNotifications: authedQuery
    .input(
      z.object({
        limit: z.number().min(1).max(100).default(20),
        offset: z.number().min(0).default(0),
        type: z.string().optional(),
        unreadOnly: z.boolean().default(false),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const conditions = [eq(notifications.userId, ctx.user.id)];

      if (input.type) {
        conditions.push(eq(notifications.type, input.type as any));
      }
      if (input.unreadOnly) {
        conditions.push(eq(notifications.isRead, false));
      }

      const notifs = await db.query.notifications.findMany({
        where: and(...conditions),
        orderBy: [desc(notifications.createdAt)],
        limit: input.limit,
        offset: input.offset,
      });

      const unreadCount = await db
        .select({ count: sql<number>`count(*)` })
        .from(notifications)
        .where(
          and(
            eq(notifications.userId, ctx.user.id),
            eq(notifications.isRead, false)
          )
        );

      return { notifications: notifs, unreadCount: unreadCount[0]?.count || 0 };
    }),

  markAsRead: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db
        .update(notifications)
        .set({ isRead: true })
        .where(
          and(
            eq(notifications.id, input.id),
            eq(notifications.userId, ctx.user.id)
          )
        );
      return { success: true };
    }),

  markAllAsRead: authedQuery.mutation(async ({ ctx }) => {
    const db = getDb();
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(
        and(
          eq(notifications.userId, ctx.user.id),
          eq(notifications.isRead, false)
        )
      );
    return { success: true };
  }),

  deleteNotification: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db
        .delete(notifications)
        .where(
          and(
            eq(notifications.id, input.id),
            eq(notifications.userId, ctx.user.id)
          )
        );
      return { success: true };
    }),

  sendNotification: adminQuery
    .input(
      z.object({
        userId: z.number().optional(),
        broadcast: z.boolean().default(false),
        type: z.enum(["transaction", "promo", "security", "system", "savings", "kyc"]),
        title: z.string().min(1).max(255),
        message: z.string().min(1),
        actionUrl: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      if (input.broadcast) {
        const allUsers = await db.select({ id: sql<number>`id` }).from(users);
        for (const user of allUsers) {
          await db.insert(notifications).values({
            userId: user.id,
            type: input.type,
            title: input.title,
            message: input.message,
            actionUrl: input.actionUrl,
          });
        }
      } else if (input.userId) {
        await db.insert(notifications).values({
          userId: input.userId,
          type: input.type,
          title: input.title,
          message: input.message,
          actionUrl: input.actionUrl,
        });
      }

      return { success: true };
    }),
});
