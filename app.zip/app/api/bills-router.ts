import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { billsPayments, transactions, wallets } from "@db/schema";
import { eq, desc } from "drizzle-orm";
import { cacheInvalidatePattern } from "./lib/redis";
import { nanoid } from "nanoid";

const BILLERS = [
  { code: "DSTV", name: "DSTV", category: "tv", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/DStv_logo.svg/1200px-DStv_logo.svg.png" },
  { code: "GOTV", name: "GOtv", category: "tv", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/GOtv_logo.svg/1200px-GOtv_logo.svg.png" },
  { code: "STARTIMES", name: "StarTimes", category: "tv", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/StarTimes_logo.svg/1200px-StarTimes_logo.svg.png" },
  { code: "PHCN", name: "PHCN/NEPA", category: "electricity", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/PHCN_logo.svg/1200px-PHCN_logo.svg.png" },
  { code: "EKO", name: "Eko Electricity", category: "electricity", logo: "https://ekoelec.com/wp-content/uploads/2021/03/Eko-Electricity-Logo.png" },
  { code: "IKEJA", name: "Ikeja Electric", category: "electricity", logo: "https://ikejaelectric.com/wp-content/uploads/2021/03/Ikeja-Electric-Logo.png" },
  { code: "ABUJA", name: "Abuja Electricity", category: "electricity", logo: "https://aedconline.com/wp-content/uploads/2021/03/AEDC-Logo.png" },
  { code: "SMILE", name: "Smile", category: "internet", logo: "https://smile.com.ng/wp-content/uploads/2021/03/Smile-Logo.png" },
  { code: "SPECTRANET", name: "Spectranet", category: "internet", logo: "https://spectranet.com.ng/wp-content/uploads/2021/03/Spectranet-Logo.png" },
];

export const billsRouter = createRouter({
  getBillers: authedQuery.query(() => {
    return BILLERS;
  }),

  getHistory: authedQuery
    .input(
      z.object({
        limit: z.number().min(1).max(50).default(20),
        offset: z.number().min(0).default(0),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const payments = await db.query.billsPayments.findMany({
        where: eq(billsPayments.userId, ctx.user.id),
        orderBy: [desc(billsPayments.createdAt)],
        limit: input.limit,
        offset: input.offset,
      });
      return payments;
    }),

  payBill: authedQuery
    .input(
      z.object({
        billerCode: z.string(),
        biller: z.string(),
        product: z.string(),
        customerId: z.string(),
        amount: z.number().min(50).max(500000),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const reference = `BIL_${nanoid(16)}`;

      const wallet = await db.query.wallets.findFirst({
        where: eq(wallets.userId, ctx.user.id),
      });

      if (!wallet || parseFloat(wallet.balance) < input.amount) {
        throw new Error("Insufficient balance");
      }

      const newBalance = (parseFloat(wallet.balance) - input.amount).toFixed(2);

      await db
        .update(wallets)
        .set({ balance: newBalance, updatedAt: new Date() })
        .where(eq(wallets.userId, ctx.user.id));

      await db.insert(billsPayments).values({
        userId: ctx.user.id,
        biller: input.biller,
        billerCode: input.billerCode,
        product: input.product,
        customerId: input.customerId,
        amount: input.amount.toFixed(2),
        status: "successful",
        reference,
      });

      await db.insert(transactions).values({
        userId: ctx.user.id,
        type: "bill_payment",
        amount: input.amount.toFixed(2),
        fee: "0.00",
        totalAmount: input.amount.toFixed(2),
        status: "successful",
        reference,
        description: `${input.biller} - ${input.product}`,
        category: "bills",
      });

      await cacheInvalidatePattern(`wallet:${ctx.user.id}:*`);

      return { success: true, reference, newBalance };
    }),
});
