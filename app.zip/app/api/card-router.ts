import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { cards, transactions, wallets } from "@db/schema";
import { eq, desc, and } from "drizzle-orm";
import { nanoid } from "nanoid";

export const cardRouter = createRouter({
  getCards: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userCards = await db.query.cards.findMany({
      where: eq(cards.userId, ctx.user.id),
      orderBy: [desc(cards.createdAt)],
    });
    return userCards;
  }),

  applyForCard: authedQuery
    .input(
      z.object({
        cardType: z.enum(["virtual", "physical"]),
        cardBrand: z.enum(["verve", "visa", "mastercard"]).default("verve"),
        cardName: z.string().min(1).max(255),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      const isVirtual = input.cardType === "virtual";

      const [card] = await db.insert(cards).values({
        userId: ctx.user.id,
        cardType: input.cardType,
        cardBrand: input.cardBrand,
        cardName: input.cardName,
        status: isVirtual ? "active" : "pending",
        maskedPan: isVirtual ? `**** **** **** ${Math.floor(1000 + Math.random() * 9000)}` : null,
        expiryMonth: isVirtual ? String(Math.floor(1 + Math.random() * 12)).padStart(2, "0") : null,
        expiryYear: isVirtual ? String(new Date().getFullYear() + 3) : null,
      }).$returningId();

      return {
        success: true,
        cardId: card.id,
        status: isVirtual ? "active" : "pending",
      };
    }),

  getCardDetails: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const card = await db.query.cards.findFirst({
        where: and(eq(cards.id, input.id), eq(cards.userId, ctx.user.id)),
      });
      if (!card) throw new Error("Card not found");
      return card;
    }),

  freezeCard: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db
        .update(cards)
        .set({ status: "frozen" })
        .where(and(eq(cards.id, input.id), eq(cards.userId, ctx.user.id)));
      return { success: true };
    }),

  unfreezeCard: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db
        .update(cards)
        .set({ status: "active" })
        .where(and(eq(cards.id, input.id), eq(cards.userId, ctx.user.id)));
      return { success: true };
    }),

  fundCard: authedQuery
    .input(
      z.object({
        cardId: z.number(),
        amount: z.number().min(100).max(500000),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const reference = `CRD_${nanoid(16)}`;

      const wallet = await db.query.wallets.findFirst({
        where: eq(wallets.userId, ctx.user.id),
      });

      if (!wallet || parseFloat(wallet.balance) < input.amount) {
        throw new Error("Insufficient balance");
      }

      const newBalance = (parseFloat(wallet.balance) - input.amount).toFixed(2);

      await db
        .update(wallets)
        .set({ balance: newBalance })
        .where(eq(wallets.userId, ctx.user.id));

      await db.insert(transactions).values({
        userId: ctx.user.id,
        type: "card_funding",
        amount: input.amount.toFixed(2),
        fee: "0.00",
        totalAmount: input.amount.toFixed(2),
        status: "successful",
        reference,
        description: `Card funding for card ${input.cardId}`,
        category: "other",
      });

      return { success: true, reference, newBalance };
    }),
});
