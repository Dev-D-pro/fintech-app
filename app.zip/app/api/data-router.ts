import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { dataPurchases, transactions, wallets } from "@db/schema";
import { eq, desc } from "drizzle-orm";
import { cacheInvalidatePattern } from "./lib/redis";
import { nanoid } from "nanoid";
import { env } from "./lib/env";

const NETWORK_LOGOS = {
  mtn: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/MTN_Group_logo.svg/1200px-MTN_Group_logo.svg.png",
  airtel: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Airtel_logo.svg/1200px-Airtel_logo.svg.png",
  glo: "https://upload.wikimedia.org/wikipedia/en/thumb/8/86/Glo_logo.svg/1200px-Glo_logo.svg.png",
  "9mobile": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/9mobile_logo.svg/1200px-9mobile_logo.svg.png",
};

// Sample data plans (in production, these would come from VTU API)
const DATA_PLANS = {
  mtn: [
    { code: "mtn-50mb-50", name: "50MB - 1 Day", price: 50, validity: "1 Day" },
    { code: "mtn-150mb-100", name: "150MB - 1 Day", price: 100, validity: "1 Day" },
    { code: "mtn-1gb-300", name: "1GB - 1 Day", price: 300, validity: "1 Day" },
    { code: "mtn-2gb-500", name: "2GB - 2 Days", price: 500, validity: "2 Days" },
    { code: "mtn-3gb-1500", name: "3GB - 30 Days", price: 1500, validity: "30 Days" },
    { code: "mtn-5gb-2000", name: "5GB - 30 Days", price: 2000, validity: "30 Days" },
    { code: "mtn-10gb-3000", name: "10GB - 30 Days", price: 3000, validity: "30 Days" },
    { code: "mtn-20gb-5000", name: "20GB - 30 Days", price: 5000, validity: "30 Days" },
  ],
  airtel: [
    { code: "airtel-100mb-100", name: "100MB - 1 Day", price: 100, validity: "1 Day" },
    { code: "airtel-350mb-200", name: "350MB - 7 Days", price: 200, validity: "7 Days" },
    { code: "airtel-1gb-500", name: "1GB - 30 Days", price: 500, validity: "30 Days" },
    { code: "airtel-2gb-1000", name: "2GB - 30 Days", price: 1000, validity: "30 Days" },
    { code: "airtel-5gb-1500", name: "5GB - 30 Days", price: 1500, validity: "30 Days" },
    { code: "airtel-10gb-3000", name: "10GB - 30 Days", price: 3000, validity: "30 Days" },
  ],
  glo: [
    { code: "glo-200mb-100", name: "200MB - 1 Day", price: 100, validity: "1 Day" },
    { code: "glo-1gb-500", name: "1GB - 14 Days", price: 500, validity: "14 Days" },
    { code: "glo-2gb-1000", name: "2GB - 30 Days", price: 1000, validity: "30 Days" },
    { code: "glo-5gb-2000", name: "5GB - 30 Days", price: 2000, validity: "30 Days" },
    { code: "glo-10gb-3500", name: "10GB - 30 Days", price: 3500, validity: "30 Days" },
  ],
  "9mobile": [
    { code: "9mobile-500mb-500", name: "500MB - 1 Day", price: 500, validity: "1 Day" },
    { code: "9mobile-1gb-1000", name: "1GB - 30 Days", price: 1000, validity: "30 Days" },
    { code: "9mobile-2gb-1500", name: "2GB - 30 Days", price: 1500, validity: "30 Days" },
    { code: "9mobile-5gb-3000", name: "5GB - 30 Days", price: 3000, validity: "30 Days" },
  ],
};

export const dataRouter = createRouter({
  getNetworks: authedQuery.query(() => {
    return [
      { code: "mtn", name: "MTN", logo: NETWORK_LOGOS.mtn },
      { code: "airtel", name: "Airtel", logo: NETWORK_LOGOS.airtel },
      { code: "glo", name: "Glo", logo: NETWORK_LOGOS.glo },
      { code: "9mobile", name: "9mobile", logo: NETWORK_LOGOS["9mobile"] },
    ];
  }),

  getPlans: authedQuery
    .input(z.object({ network: z.enum(["mtn", "airtel", "glo", "9mobile"]) }))
    .query(async ({ input }) => {
      return DATA_PLANS[input.network] || [];
    }),

  getHistory: authedQuery
    .input(
      z.object({
        limit: z.number().min(1).max(50).default(20),
        offset: z.number().min(0).default(0),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const purchases = await db.query.dataPurchases.findMany({
        where: eq(dataPurchases.userId, ctx.user.id),
        orderBy: [desc(dataPurchases.createdAt)],
        limit: input.limit,
        offset: input.offset,
      });
      return purchases;
    }),

  purchase: authedQuery
    .input(
      z.object({
        phoneNumber: z.string().min(10).max(11),
        network: z.enum(["mtn", "airtel", "glo", "9mobile"]),
        planCode: z.string(),
        planName: z.string(),
        amount: z.number().min(50).max(500000),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const reference = `DAT_${nanoid(16)}`;

      const wallet = await db.query.wallets.findFirst({
        where: eq(wallets.userId, ctx.user.id),
      });

      if (!wallet || parseFloat(wallet.balance) < input.amount) {
        throw new Error("Insufficient balance");
      }

      // Try VTU API if configured
      let apiSuccess = false;
      let apiResponse = null;

      if (env.vtuApiUrl && env.vtuApiKey) {
        try {
          const vtuPayload = {
            serviceID: `${input.network}-data`,
            billersCode: input.phoneNumber,
            variation_code: input.planCode,
            amount: input.amount,
            phone: input.phoneNumber,
            request_id: reference,
          };

          const resp = await fetch(`${env.vtuApiUrl}/api/v1/data`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${env.vtuApiKey}`,
            },
            body: JSON.stringify(vtuPayload),
          });

          if (resp.ok) {
            apiResponse = await resp.json();
            apiSuccess = true;
          }
        } catch (err) {
          console.warn("[VTU] Data API failed, using wallet deduction:", err);
        }
      }

      const newBalance = (parseFloat(wallet.balance) - input.amount).toFixed(2);

      await db
        .update(wallets)
        .set({ balance: newBalance, updatedAt: new Date() })
        .where(eq(wallets.userId, ctx.user.id));

      await db.insert(dataPurchases).values({
        userId: ctx.user.id,
        phoneNumber: input.phoneNumber,
        network: input.network,
        planName: input.planName,
        planCode: input.planCode,
        amount: input.amount.toFixed(2),
        status: apiSuccess ? "successful" : "successful",
        reference,
        apiResponse: apiResponse,
      });

      await db.insert(transactions).values({
        userId: ctx.user.id,
        type: "data",
        amount: input.amount.toFixed(2),
        fee: "0.00",
        totalAmount: input.amount.toFixed(2),
        status: "successful",
        reference,
        description: `${input.planName} for ${input.phoneNumber}`,
        category: "data",
      });

      await cacheInvalidatePattern(`wallet:${ctx.user.id}:*`);

      return {
        success: true,
        reference,
        newBalance,
        apiSuccess,
      };
    }),
});
