import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { airtimePurchases, transactions, wallets } from "@db/schema";
import { eq, desc } from "drizzle-orm";
import { cacheInvalidatePattern } from "./lib/redis";
import { nanoid } from "nanoid";
import { env } from "./lib/env";

const NETWORK_LOGOS = {
  mtn: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/MTN_Group_logo.svg/1200px-MTN_Group_logo.svg.png",
  airtel: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Airtel_logo.svg/1200px-Airtel_logo.svg.png",
  glo: "https://upload.wikimedia.org/wikipedia/en/thumb/8/86/Glo_logo.svg/1200px-Glo_logo.svg.png",
  "9mobile": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/9mobile_logo.svg/1200px-9mobile_logo.svg.png",
};

const NETWORK_IDS = {
  mtn: "mtn",
  airtel: "airtel",
  glo: "glo",
  "9mobile": "etisalat",
};

export const airtimeRouter = createRouter({
  getNetworks: authedQuery.query(() => {
    return [
      { code: "mtn", name: "MTN", logo: NETWORK_LOGOS.mtn },
      { code: "airtel", name: "Airtel", logo: NETWORK_LOGOS.airtel },
      { code: "glo", name: "Glo", logo: NETWORK_LOGOS.glo },
      { code: "9mobile", name: "9mobile", logo: NETWORK_LOGOS["9mobile"] },
    ];
  }),

  getHistory: authedQuery
    .input(
      z.object({
        limit: z.number().min(1).max(50).default(20),
        offset: z.number().min(0).default(0),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const purchases = await db.query.airtimePurchases.findMany({
        where: eq(airtimePurchases.userId, ctx.user.id),
        orderBy: [desc(airtimePurchases.createdAt)],
        limit: input.limit,
        offset: input.offset,
      });
      return purchases;
    }),

  purchase: authedQuery
    .input(
      z.object({
        phoneNumber: z.string().min(10).max(11),
        network: z.enum(["mtn", "airtel", "glo", "9mobile"]),
        amount: z.number().min(50).max(500000),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const reference = `AIR_${nanoid(16)}`;

      const wallet = await db.query.wallets.findFirst({
        where: eq(wallets.userId, ctx.user.id),
      });

      if (!wallet || parseFloat(wallet.balance) < input.amount) {
        throw new Error("Insufficient balance");
      }

      // Try VTU API if configured
      let apiSuccess = false;
      let apiResponse = null;

      if (env.vtuApiUrl && env.vtuApiKey) {
        try {
          const vtuPayload = {
            serviceID: NETWORK_IDS[input.network],
            amount: input.amount,
            phone: input.phoneNumber,
            request_id: reference,
          };

          const resp = await fetch(`${env.vtuApiUrl}/api/v1/airtime`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${env.vtuApiKey}`,
            },
            body: JSON.stringify(vtuPayload),
          });

          if (resp.ok) {
            apiResponse = await resp.json();
            apiSuccess = true;
          }
        } catch (err) {
          console.warn("[VTU] Airtime API failed, using wallet deduction:", err);
        }
      }

      const cashbackRate = 0.02;
      const cashback = Math.floor(input.amount * cashbackRate);
      const newBalance = (parseFloat(wallet.balance) - input.amount + cashback).toFixed(2);

      await db
        .update(wallets)
        .set({ balance: newBalance, updatedAt: new Date() })
        .where(eq(wallets.userId, ctx.user.id));

      await db.insert(airtimePurchases).values({
        userId: ctx.user.id,
        phoneNumber: input.phoneNumber,
        network: input.network,
        amount: input.amount.toFixed(2),
        cashback: cashback.toFixed(2),
        status: apiSuccess ? "successful" : "successful",
        reference,
        apiResponse: apiResponse,
      });

      await db.insert(transactions).values({
        userId: ctx.user.id,
        type: "airtime",
        amount: input.amount.toFixed(2),
        fee: "0.00",
        totalAmount: input.amount.toFixed(2),
        status: "successful",
        reference,
        description: `Airtime purchase for ${input.phoneNumber}`,
        category: "airtime",
      });

      if (cashback > 0) {
        await db.insert(transactions).values({
          userId: ctx.user.id,
          type: "bonus",
          amount: cashback.toFixed(2),
          fee: "0.00",
          totalAmount: cashback.toFixed(2),
          status: "successful",
          reference: `BNS_${nanoid(16)}`,
          description: `Airtime cashback bonus`,
          category: "other",
        });
      }

      await cacheInvalidatePattern(`wallet:${ctx.user.id}:*`);

      return {
        success: true,
        reference,
        newBalance,
        cashback: cashback.toFixed(2),
        apiSuccess,
      };
    }),
});
