import { Resend } from "resend";
import { env } from "./env";

let resend: Resend | null = null;

function getResend() {
  if (!resend && env.resendApiKey) {
    resend = new Resend(env.resendApiKey);
  }
  return resend;
}

export async function sendEmail(params: {
  to: string;
  subject: string;
  html: string;
  text?: string;
}) {
  const client = getResend();
  if (!client) {
    console.warn("[email] Resend not configured, skipping email send");
    return { success: false, error: "Email service not configured" };
  }

  try {
    const { data, error } = await client.emails.send({
      from: env.emailFrom,
      to: params.to,
      subject: params.subject,
      html: params.html,
      text: params.text,
    });

    if (error) {
      console.error("[email] Send failed:", error);
      return { success: false, error: error.message };
    }

    return { success: true, id: data?.id };
  } catch (err: any) {
    console.error("[email] Send error:", err);
    return { success: false, error: err.message };
  }
}

// Email templates
export function getWelcomeEmailTemplate(name: string) {
  return {
    subject: "Welcome to NairaFlow!",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #059669;">Welcome to NairaFlow, ${name}!</h2>
        <p>Thank you for joining Nigeria's most trusted fintech platform.</p>
        <p>With NairaFlow, you can:</p>
        <ul>
          <li>Send and receive money instantly</li>
          <li>Buy airtime and data bundles</li>
          <li>Pay bills and save money</li>
          <li>Get a virtual card for online payments</li>
        </ul>
        <p style="margin-top: 20px;">Get started by completing your KYC verification to unlock all features.</p>
        <div style="margin-top: 30px; padding: 20px; background: #f3f4f6; border-radius: 8px;">
          <p style="margin: 0; font-size: 12px; color: #6b7280;">If you have any questions, reply to this email or contact our support team.</p>
        </div>
      </div>
    `,
  };
}

export function getTransactionEmailTemplate(params: {
  name: string;
  type: string;
  amount: string;
  reference: string;
  date: string;
  description: string;
  balance?: string;
}) {
  const { name, type, amount, reference, date, description, balance } = params;
  const isCredit = ["deposit", "transfer_in", "interest", "bonus", "refund"].includes(type);
  const color = isCredit ? "#059669" : "#dc2626";
  const sign = isCredit ? "+" : "-";

  return {
    subject: `Transaction ${isCredit ? "Received" : "Alert"} - ${reference}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: ${color};">Transaction ${isCredit ? "Received" : "Alert"}</h2>
        <p>Hi ${name},</p>
        <p>A transaction has occurred on your NairaFlow account:</p>
        <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0;"><strong>Type:</strong> ${type.replace("_", " ").toUpperCase()}</p>
          <p style="margin: 5px 0;"><strong>Amount:</strong> <span style="color: ${color}; font-size: 18px;">${sign}₦${amount}</span></p>
          <p style="margin: 5px 0;"><strong>Description:</strong> ${description}</p>
          <p style="margin: 5px 0;"><strong>Reference:</strong> ${reference}</p>
          <p style="margin: 5px 0;"><strong>Date:</strong> ${date}</p>
          ${balance ? `<p style="margin: 5px 0;"><strong>New Balance:</strong> ₦${balance}</p>` : ""}
        </div>
        <p style="font-size: 12px; color: #6b7280;">If you did not authorize this transaction, please contact our support immediately.</p>
      </div>
    `,
  };
}

export function getKycVerifiedEmailTemplate(name: string, tier: string) {
  return {
    subject: "KYC Verification Approved!",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #059669;">KYC Verification Approved</h2>
        <p>Hi ${name},</p>
        <p>Great news! Your KYC verification has been approved and you have been upgraded to <strong>${tier.toUpperCase()}</strong>.</p>
        <p>You now have access to higher transaction limits and all premium features on NairaFlow.</p>
        <div style="margin-top: 30px; padding: 20px; background: #f3f4f6; border-radius: 8px;">
          <p style="margin: 0; font-size: 12px; color: #6b7280;">Thank you for trusting NairaFlow.</p>
        </div>
      </div>
    `,
  };
}

export function getLoginAlertTemplate(name: string, device: string, location: string, time: string) {
  return {
    subject: "New Login to Your NairaFlow Account",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #dc2626;">New Login Detected</h2>
        <p>Hi ${name},</p>
        <p>We detected a new login to your NairaFlow account:</p>
        <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0;"><strong>Device:</strong> ${device}</p>
          <p style="margin: 5px 0;"><strong>Location:</strong> ${location}</p>
          <p style="margin: 5px 0;"><strong>Time:</strong> ${time}</p>
        </div>
        <p style="font-size: 12px; color: #6b7280;">If this was you, you can ignore this email. If not, please change your password immediately and contact support.</p>
      </div>
    `,
  };
}

export function getVirtualAccountCreatedTemplate(name: string, accountNumber: string, bankName: string) {
  return {
    subject: "Your NairaFlow Virtual Account is Ready",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #059669;">Your Virtual Account is Ready</h2>
        <p>Hi ${name},</p>
        <p>You can now fund your NairaFlow wallet by transferring to your dedicated virtual account:</p>
        <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
          <p style="margin: 5px 0; font-size: 14px; color: #6b7280;">Bank Name</p>
          <p style="margin: 5px 0; font-size: 18px; font-weight: bold;">${bankName}</p>
          <p style="margin: 15px 0 5px; font-size: 14px; color: #6b7280;">Account Number</p>
          <p style="margin: 5px 0; font-size: 24px; font-weight: bold; letter-spacing: 2px;">${accountNumber}</p>
          <p style="margin: 15px 0 5px; font-size: 14px; color: #6b7280;">Account Name</p>
          <p style="margin: 5px 0; font-size: 16px; font-weight: bold;">NairaFlow / ${name}</p>
        </div>
        <p style="font-size: 12px; color: #6b7280;">Transfers to this account will be credited to your NairaFlow wallet automatically.</p>
      </div>
    `,
  };
}
