import "dotenv/config";

function required(name: string): string {
  const value = process.env[name];
  if (!value && process.env.NODE_ENV === "production") {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value ?? "";
}

export const env = {
  appId: required("APP_ID"),
  appSecret: required("APP_SECRET"),
  isProduction: process.env.NODE_ENV === "production",
  databaseUrl: required("DATABASE_URL"),
  kimiAuthUrl: required("KIMI_AUTH_URL"),
  kimiOpenUrl: required("KIMI_OPEN_URL"),
  ownerUnionId: process.env.OWNER_UNION_ID ?? "",
  
  // Paystack
  paystackSecretKey: process.env.PAYSTACK_SECRET_KEY ?? "",
  paystackPublicKey: process.env.PAYSTACK_PUBLIC_KEY ?? "",
  
  // Google OAuth
  googleClientId: process.env.GOOGLE_CLIENT_ID ?? "",
  googleClientSecret: process.env.GOOGLE_CLIENT_SECRET ?? "",
  
  // Email (Resend)
  resendApiKey: process.env.RESEND_API_KEY ?? "",
  emailFrom: process.env.EMAIL_FROM ?? "NairaFlow <noreply@nairaflow.com>",
  
  // VTU API (e.g., VTpass, eBills, etc.)
  vtuApiUrl: process.env.VTU_API_URL ?? "",
  vtuApiKey: process.env.VTU_API_KEY ?? "",
  vtuApiSecret: process.env.VTU_API_SECRET ?? "",
  vtuApiUsername: process.env.VTU_API_USERNAME ?? "",
  vtuApiPassword: process.env.VTU_API_PASSWORD ?? "",
};
