import { env } from "./env";

const PAYSTACK_BASE_URL = "https://api.paystack.co";

function getSecretKey(): string {
  const key = env.paystackSecretKey;
  if (!key) {
    throw new Error("Paystack secret key not configured");
  }
  return key;
}

async function paystackFetch<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${PAYSTACK_BASE_URL}${endpoint}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${getSecretKey()}`,
      "Content-Type": "application/json",
      ...options?.headers,
    },
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Paystack API error: ${response.status} - ${error}`);
  }

  return response.json() as Promise<T>;
}

// Initialize transaction
export async function initializeTransaction(params: {
  email: string;
  amount: number;
  reference?: string;
  callback_url?: string;
  metadata?: Record<string, unknown>;
}) {
  return paystackFetch<{
    status: boolean;
    message: string;
    data: {
      authorization_url: string;
      access_code: string;
      reference: string;
    };
  }>("/transaction/initialize", {
    method: "POST",
    body: JSON.stringify(params),
  });
}

// Verify transaction
export async function verifyTransaction(reference: string) {
  return paystackFetch<{
    status: boolean;
    message: string;
    data: {
      id: number;
      status: string;
      reference: string;
      amount: number;
      gateway_response: string;
      paid_at: string;
      created_at: string;
      channel: string;
      currency: string;
      ip_address: string;
      metadata: Record<string, unknown>;
      log: unknown;
      fees: number;
      customer: {
        id: number;
        first_name: string;
        last_name: string;
        email: string;
        customer_code: string;
        phone: string;
      };
      authorization: {
        authorization_code: string;
        bin: string;
        last4: string;
        exp_month: string;
        exp_year: string;
        channel: string;
        card_type: string;
        bank: string;
        country_code: string;
        brand: string;
        reusable: boolean;
        signature: string;
      };
    };
  }>(`/transaction/verify/${reference}`, {
    method: "GET",
  });
}

// List banks
export async function listBanks(params?: { country?: string; perPage?: number; page?: number; pay_with_bank_transfer?: boolean }) {
  const query = new URLSearchParams();
  if (params?.country) query.append("country", params.country);
  if (params?.perPage) query.append("perPage", params.perPage.toString());
  if (params?.page) query.append("page", params.page.toString());
  if (params?.pay_with_bank_transfer) query.append("pay_with_bank_transfer", "true");

  return paystackFetch<{
    status: boolean;
    message: string;
    data: Array<{
      name: string;
      slug: string;
      code: string;
      longcode: string;
      gateway: string;
      pay_with_bank: boolean;
      active: boolean;
      is_deleted: boolean;
      country: string;
      currency: string;
      type: string;
      id: number;
      createdAt: string;
      updatedAt: string;
    }>;
    meta: {
      next: string;
      previous: string;
      perPage: number;
    };
  }>(`/bank?${query.toString()}`, {
    method: "GET",
  });
}

// Verify account number
export async function verifyAccountNumber(accountNumber: string, bankCode: string) {
  return paystackFetch<{
    status: boolean;
    message: string;
    data: {
      account_number: string;
      account_name: string;
      bank_id: number;
    };
  }>(`/bank/resolve?account_number=${accountNumber}&bank_code=${bankCode}`, {
    method: "GET",
  });
}

// Resolve BVN
export async function resolveBVN(bvn: string) {
  return paystackFetch<{
    status: boolean;
    message: string;
    data: {
      bvn: string;
      first_name: string;
      last_name: string;
      middle_name: string;
      date_of_birth: string;
      phone_number: string;
      gender: string;
      nationality: string;
      address: string;
      verified: boolean;
    };
  }>(`/bank/resolve_bvn/${bvn}`, {
    method: "GET",
  });
}

// Match BVN with account
export async function matchBVNAccount(accountNumber: string, bankCode: string, bvn: string) {
  return paystackFetch<{
    status: boolean;
    message: string;
    data: {
      bvn: string;
      account_number: string;
      bank_code: string;
      match_status: string;
    };
  }>(`/bank/match_bvn?account_number=${accountNumber}&bank_code=${bankCode}&bvn=${bvn}`, {
    method: "GET",
  });
}

// Create transfer recipient
export async function createTransferRecipient(params: {
  type: string;
  name: string;
  account_number: string;
  bank_code: string;
  currency?: string;
}) {
  return paystackFetch<{
    status: boolean;
    message: string;
    data: {
      type: string;
      name: string;
      recipient_code: string;
      bank_code: string;
      account_number: string;
      currency: string;
      active: boolean;
      id: number;
      createdAt: string;
      updatedAt: string;
    };
  }>("/transferrecipient", {
    method: "POST",
    body: JSON.stringify(params),
  });
}

// Initiate transfer
export async function initiateTransfer(params: {
  source: string;
  amount: number;
  recipient: string;
  reason?: string;
  reference?: string;
}) {
  return paystackFetch<{
    status: boolean;
    message: string;
    data: {
      reference: string;
      integration: number;
      domain: string;
      amount: number;
      currency: string;
      source: string;
      reason: string;
      recipient: number;
      status: string;
      transfer_code: string;
      id: number;
      createdAt: string;
      updatedAt: string;
    };
  }>("/transfer", {
    method: "POST",
    body: JSON.stringify(params),
  });
}

// Verify transfer
export async function verifyTransfer(reference: string) {
  return paystackFetch<{
    status: boolean;
    message: string;
    data: {
      domain: string;
      amount: number;
      currency: string;
      reference: string;
      source: string;
      source_details: unknown;
      reason: string;
      status: string;
      failures: unknown;
      transfer_code: string;
      titan_code: string;
      transferred_at: string;
      id: number;
      createdAt: string;
      updatedAt: string;
    };
  }>(`/transfer/verify/${reference}`, {
    method: "GET",
  });
}

// Get balance
export async function getBalance() {
  return paystackFetch<{
    status: boolean;
    message: string;
    data: Array<{
      currency: string;
      balance: number;
    }>;
  }>("/balance", {
    method: "GET",
  });
}

// Create customer
export async function createCustomer(params: {
  email: string;
  first_name: string;
  last_name: string;
  phone?: string;
}) {
  return paystackFetch<{
    status: boolean;
    message: string;
    data: {
      id: number;
      first_name: string;
      last_name: string;
      email: string;
      customer_code: string;
      phone: string;
      risk_action: string;
      createdAt: string;
      updatedAt: string;
    };
  }>("/customer", {
    method: "POST",
    body: JSON.stringify(params),
  });
}

// Fetch customer
export async function fetchCustomer(emailOrCode: string) {
  return paystackFetch<{
    status: boolean;
    message: string;
    data: {
      id: number;
      first_name: string;
      last_name: string;
      email: string;
      customer_code: string;
      phone: string;
      metadata: unknown;
      risk_action: string;
      createdAt: string;
      updatedAt: string;
      dedicated_accounts: Array<{
        bank: {
          name: string;
          id: number;
          slug: string;
        };
        account_name: string;
        account_number: string;
        assigned: boolean;
        currency: string;
        active: boolean;
        id: number;
      }>;
    };
  }>(`/customer/${emailOrCode}`, {
    method: "GET",
  });
}

// Create dedicated virtual account
export async function createDedicatedVirtualAccount(params: {
  customer: string;
  preferred_bank?: string;
  subaccount?: string;
  split_code?: string;
  first_name?: string;
  last_name?: string;
  phone?: string;
}) {
  return paystackFetch<{
    status: boolean;
    message: string;
    data: {
      bank: {
        name: string;
        id: number;
        slug: string;
      };
      account_name: string;
      account_number: string;
      assigned: boolean;
      currency: string;
      metadata: unknown;
      active: boolean;
      id: number;
      created_at: string;
      updated_at: string;
      assignment: {
        integration: number;
        assignee_id: number;
        assignee_type: string;
        expired: boolean;
        account_type: string;
        assigned_at: string;
      };
      customer: {
        id: number;
        first_name: string;
        last_name: string;
        email: string;
        customer_code: string;
        phone: string;
        risk_action: string;
      };
    };
  }>("/dedicated_account", {
    method: "POST",
    body: JSON.stringify(params),
  });
}

// Fetch dedicated virtual account providers
export async function fetchVirtualAccountProviders() {
  return paystackFetch<{
    status: boolean;
    message: string;
    data: Array<{
      name: string;
      slug: string;
      id: number;
    }>;
  }>("/dedicated_account/available_providers", {
    method: "GET",
  });
}

// Assign dedicated virtual account (single step)
export async function assignDedicatedVirtualAccount(params: {
  email: string;
  first_name: string;
  last_name: string;
  phone: string;
  preferred_bank: string;
  country?: string;
  account_number?: string;
  bvn?: string;
  bank_code?: string;
  subaccount?: string;
  split_code?: string;
}) {
  return paystackFetch<{
    status: boolean;
    message: string;
    data: {
      status: string;
      message: string;
    };
  }>("/dedicated_account/assign", {
    method: "POST",
    body: JSON.stringify(params),
  });
}

// Charge authorization (for cards)
export async function chargeAuthorization(params: {
  authorization_code: string;
  email: string;
  amount: number;
  reference?: string;
  metadata?: Record<string, unknown>;
}) {
  return paystackFetch<{
    status: boolean;
    message: string;
    data: {
      id: number;
      status: string;
      reference: string;
      amount: number;
      gateway_response: string;
      paid_at: string;
      created_at: string;
      channel: string;
      currency: string;
      authorization: {
        authorization_code: string;
        bin: string;
        last4: string;
        exp_month: string;
        exp_year: string;
        card_type: string;
        bank: string;
        country_code: string;
        brand: string;
        reusable: boolean;
      };
      customer: {
        id: number;
        first_name: string;
        last_name: string;
        email: string;
        customer_code: string;
      };
    };
  }>("/transaction/charge_authorization", {
    method: "POST",
    body: JSON.stringify(params),
  });
}

export { getSecretKey };
