import { env } from "./env";

// In-memory cache fallback when Redis is not configured
const memoryCache = new Map<string, { value: string; expires: number }>();

function cleanupMemoryCache() {
  const now = Date.now();
  for (const [key, entry] of memoryCache.entries()) {
    if (entry.expires < now) {
      memoryCache.delete(key);
    }
  }
}

// Clean up expired entries every 60 seconds
setInterval(cleanupMemoryCache, 60000);

export async function cacheGet(key: string): Promise<string | null> {
  try {
    // Try Redis if URL is configured
    if (env.isProduction && process.env.REDIS_URL) {
      // Redis implementation would go here with Upstash/ioredis
      return null;
    }
  } catch {
    // Fallback to memory cache
  }

  const entry = memoryCache.get(key);
  if (entry && entry.expires > Date.now()) {
    return entry.value;
  }
  if (entry) {
    memoryCache.delete(key);
  }
  return null;
}

export async function cacheSet(key: string, value: string, ttlSeconds: number): Promise<void> {
  try {
    if (env.isProduction && process.env.REDIS_URL) {
      // Redis implementation
      return;
    }
  } catch {
    // Fallback
  }

  memoryCache.set(key, {
    value,
    expires: Date.now() + ttlSeconds * 1000,
  });
}

export async function cacheDelete(key: string): Promise<void> {
  memoryCache.delete(key);
}

export async function cacheInvalidatePattern(pattern: string): Promise<void> {
  const regex = new RegExp(pattern.replace(/\*/g, ".*"));
  for (const key of memoryCache.keys()) {
    if (regex.test(key)) {
      memoryCache.delete(key);
    }
  }
}
