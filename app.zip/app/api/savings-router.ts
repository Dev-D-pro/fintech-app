import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { savingsGoals, transactions, wallets } from "@db/schema";
import { eq, desc, and, sql } from "drizzle-orm";
import { cacheInvalidatePattern } from "./lib/redis";
import { nanoid } from "nanoid";

export const savingsRouter = createRouter({
  getGoals: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const goals = await db.query.savingsGoals.findMany({
      where: and(eq(savingsGoals.userId, ctx.user.id), eq(savingsGoals.isActive, true)),
      orderBy: [desc(savingsGoals.createdAt)],
    });
    return goals;
  }),

  getGoalById: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const goal = await db.query.savingsGoals.findFirst({
        where: and(
          eq(savingsGoals.id, input.id),
          eq(savingsGoals.userId, ctx.user.id)
        ),
      });
      if (!goal) throw new Error("Savings goal not found");
      return goal;
    }),

  createGoal: authedQuery
    .input(
      z.object({
        name: z.string().min(1).max(255),
        type: z.enum(["owealth", "targets", "safebox", "fixed"]),
        targetAmount: z.number().min(100).optional(),
        interestRate: z.number().min(0).max(100).optional(),
        maturityDate: z.string().optional(),
        autoSave: z.boolean().default(false),
        autoSaveAmount: z.number().min(10).optional(),
        autoSaveFrequency: z.enum(["daily", "weekly", "monthly"]).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [goal] = await db.insert(savingsGoals).values({
        userId: ctx.user.id,
        name: input.name,
        type: input.type,
        targetAmount: input.targetAmount?.toFixed(2),
        currentAmount: "0.00",
        interestRate: input.interestRate?.toFixed(2),
        maturityDate: input.maturityDate ? new Date(input.maturityDate) : undefined,
        autoSave: input.autoSave,
        autoSaveAmount: input.autoSaveAmount?.toFixed(2),
        autoSaveFrequency: input.autoSaveFrequency,
      }).$returningId();

      return { success: true, goalId: goal.id };
    }),

  deposit: authedQuery
    .input(
      z.object({
        goalId: z.number(),
        amount: z.number().min(10).max(5000000),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const reference = `SVG_${nanoid(16)}`;

      const wallet = await db.query.wallets.findFirst({
        where: eq(wallets.userId, ctx.user.id),
      });

      if (!wallet || parseFloat(wallet.balance) < input.amount) {
        throw new Error("Insufficient balance");
      }

      const goal = await db.query.savingsGoals.findFirst({
        where: and(eq(savingsGoals.id, input.goalId), eq(savingsGoals.userId, ctx.user.id)),
      });

      if (!goal) throw new Error("Savings goal not found");

      const newBalance = (parseFloat(wallet.balance) - input.amount).toFixed(2);
      const newGoalAmount = (parseFloat(goal.currentAmount) + input.amount).toFixed(2);

      await db
        .update(wallets)
        .set({ balance: newBalance, updatedAt: new Date() })
        .where(eq(wallets.userId, ctx.user.id));

      await db
        .update(savingsGoals)
        .set({ currentAmount: newGoalAmount, updatedAt: new Date() })
        .where(eq(savingsGoals.id, input.goalId));

      await db.insert(transactions).values({
        userId: ctx.user.id,
        type: "savings",
        amount: input.amount.toFixed(2),
        fee: "0.00",
        totalAmount: input.amount.toFixed(2),
        status: "successful",
        reference,
        description: `Savings deposit to ${goal.name}`,
        category: "savings",
      });

      await cacheInvalidatePattern(`wallet:${ctx.user.id}:*`);

      return { success: true, reference, newBalance, newGoalAmount };
    }),

  withdraw: authedQuery
    .input(
      z.object({
        goalId: z.number(),
        amount: z.number().min(10),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const reference = `SVG_W_${nanoid(16)}`;

      const goal = await db.query.savingsGoals.findFirst({
        where: and(eq(savingsGoals.id, input.goalId), eq(savingsGoals.userId, ctx.user.id)),
      });

      if (!goal) throw new Error("Savings goal not found");
      if (parseFloat(goal.currentAmount) < input.amount) {
        throw new Error("Insufficient savings balance");
      }

      const wallet = await db.query.wallets.findFirst({
        where: eq(wallets.userId, ctx.user.id),
      });

      if (!wallet) throw new Error("Wallet not found");

      const newGoalAmount = (parseFloat(goal.currentAmount) - input.amount).toFixed(2);
      const newBalance = (parseFloat(wallet.balance) + input.amount).toFixed(2);

      await db
        .update(wallets)
        .set({ balance: newBalance, updatedAt: new Date() })
        .where(eq(wallets.userId, ctx.user.id));

      await db
        .update(savingsGoals)
        .set({ currentAmount: newGoalAmount, updatedAt: new Date() })
        .where(eq(savingsGoals.id, input.goalId));

      await db.insert(transactions).values({
        userId: ctx.user.id,
        type: "withdrawal",
        amount: input.amount.toFixed(2),
        fee: "0.00",
        totalAmount: input.amount.toFixed(2),
        status: "successful",
        reference,
        description: `Savings withdrawal from ${goal.name}`,
        category: "withdrawal",
      });

      await cacheInvalidatePattern(`wallet:${ctx.user.id}:*`);

      return { success: true, reference, newBalance };
    }),

  deleteGoal: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const goal = await db.query.savingsGoals.findFirst({
        where: and(eq(savingsGoals.id, input.id), eq(savingsGoals.userId, ctx.user.id)),
      });

      if (!goal) throw new Error("Savings goal not found");

      if (parseFloat(goal.currentAmount) > 0) {
        const wallet = await db.query.wallets.findFirst({
          where: eq(wallets.userId, ctx.user.id),
        });
        if (wallet) {
          const newBalance = (parseFloat(wallet.balance) + parseFloat(goal.currentAmount)).toFixed(2);
          await db
            .update(wallets)
            .set({ balance: newBalance, updatedAt: new Date() })
            .where(eq(wallets.userId, ctx.user.id));
        }
      }

      await db
        .update(savingsGoals)
        .set({ isActive: false, updatedAt: new Date() })
        .where(eq(savingsGoals.id, input.id));

      await cacheInvalidatePattern(`wallet:${ctx.user.id}:*`);
      return { success: true };
    }),

  getStats: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const stats = await db
      .select({
        totalSaved: sql<string>`sum(${savingsGoals.currentAmount})`,
        goalCount: sql<number>`count(*)`,
        activeGoals: sql<number>`sum(case when ${savingsGoals.isActive} = 1 then 1 else 0 end)`,
      })
      .from(savingsGoals)
      .where(eq(savingsGoals.userId, ctx.user.id));

    const interest = await db
      .select({
        totalInterest: sql<string>`sum(${transactions.amount})`,
      })
      .from(transactions)
      .where(
        and(
          eq(transactions.userId, ctx.user.id),
          eq(transactions.type, "interest"),
          eq(transactions.status, "successful")
        )
      );

    return {
      totalSaved: parseFloat(stats[0]?.totalSaved || "0"),
      goalCount: stats[0]?.goalCount || 0,
      activeGoals: parseInt(stats[0]?.activeGoals as unknown as string) || 0,
      totalInterest: parseFloat(interest[0]?.totalInterest || "0"),
    };
  }),
});
