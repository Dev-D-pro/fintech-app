import { z } from "zod";
import { createRouter, authedQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { kycDocuments, users } from "@db/schema";
import { eq, desc } from "drizzle-orm";
import { cacheInvalidatePattern } from "./lib/redis";
import { resolveBVN, matchBVNAccount } from "./lib/paystack";
import { sendEmail, getKycVerifiedEmailTemplate } from "./lib/email";

export const kycRouter = createRouter({
  getStatus: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const documents = await db.query.kycDocuments.findMany({
      where: eq(kycDocuments.userId, ctx.user.id),
      orderBy: [desc(kycDocuments.createdAt)],
    });

    return {
      kycStatus: ctx.user.kycStatus,
      tier: ctx.user.tier,
      bvn: ctx.user.bvn,
      nin: ctx.user.nin,
      documents,
      limits: getTierLimits(ctx.user.tier),
    };
  }),

  submitDocument: authedQuery
    .input(
      z.object({
        type: z.enum(["bvn", "nin", "passport", "drivers_license", "voters_card", "utility_bill"]),
        documentNumber: z.string().optional(),
        documentUrl: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      await db.insert(kycDocuments).values({
        userId: ctx.user.id,
        type: input.type,
        documentNumber: input.documentNumber,
        documentUrl: input.documentUrl,
        status: "submitted",
      });

      await db
        .update(users)
        .set({ kycStatus: "submitted", updatedAt: new Date() })
        .where(eq(users.id, ctx.user.id));

      await cacheInvalidatePattern(`user:${ctx.user.id}:*`);

      return { success: true };
    }),

  verifyBVN: authedQuery
    .input(z.object({ bvn: z.string().length(11) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      try {
        const result = await resolveBVN(input.bvn);

        if (result.status && result.data) {
          // Update user with BVN info
          await db
            .update(users)
            .set({
              bvn: input.bvn,
              name: `${result.data.first_name} ${result.data.last_name}`,
              phone: result.data.phone_number || ctx.user.phone,
              dateOfBirth: result.data.date_of_birth,
              kycStatus: "verified",
              tier: "tier2" as any,
              updatedAt: new Date(),
            })
            .where(eq(users.id, ctx.user.id));

          // Add KYC document record
          await db.insert(kycDocuments).values({
            userId: ctx.user.id,
            type: "bvn",
            documentNumber: input.bvn,
            status: "verified",
            reviewNotes: `BVN verified via Paystack. Name: ${result.data.first_name} ${result.data.last_name}`,
          });

          await cacheInvalidatePattern(`user:${ctx.user.id}:*`);

          // Send email notification
          if (ctx.user.email) {
            const template = getKycVerifiedEmailTemplate(
              ctx.user.name || "User",
              "tier2"
            );
            await sendEmail({ to: ctx.user.email, ...template });
          }

          return {
            success: true,
            bvnData: {
              firstName: result.data.first_name,
              lastName: result.data.last_name,
              phoneNumber: result.data.phone_number,
              dateOfBirth: result.data.date_of_birth,
            },
            tier: "tier2",
          };
        }

        throw new Error(result.message || "BVN verification failed");
      } catch (error: any) {
        console.error("BVN verify error:", error);
        throw new Error(error.message || "BVN verification failed");
      }
    }),

  matchBVNAccount: authedQuery
    .input(
      z.object({
        bvn: z.string().length(11),
        accountNumber: z.string().length(10),
        bankCode: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const result = await matchBVNAccount(input.accountNumber, input.bankCode, input.bvn);
        return {
          success: result.status,
          matchStatus: result.data?.match_status || "unknown",
        };
      } catch (error: any) {
        console.error("BVN match error:", error);
        throw new Error(error.message || "BVN account matching failed");
      }
    }),

  updateProfile: authedQuery
    .input(
      z.object({
        name: z.string().optional(),
        phone: z.string().optional(),
        dateOfBirth: z.string().optional(),
        address: z.string().optional(),
        avatar: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      const updateData: Record<string, any> = {};
      if (input.name) updateData.name = input.name;
      if (input.phone) updateData.phone = input.phone;
      if (input.dateOfBirth) updateData.dateOfBirth = input.dateOfBirth;
      if (input.address) updateData.address = input.address;
      if (input.avatar) updateData.avatar = input.avatar;

      if (Object.keys(updateData).length > 0) {
        updateData.updatedAt = new Date();
        await db.update(users).set(updateData).where(eq(users.id, ctx.user.id));
      }

      await cacheInvalidatePattern(`user:${ctx.user.id}:*`);
      return { success: true };
    }),

  // Admin endpoints
  getPendingKyc: adminQuery.query(async () => {
    const db = getDb();
    const docs = await db.query.kycDocuments.findMany({
      where: eq(kycDocuments.status, "submitted"),
      orderBy: [desc(kycDocuments.createdAt)],
      with: { user: true },
    });
    return docs;
  }),

  reviewKyc: adminQuery
    .input(
      z.object({
        documentId: z.number(),
        status: z.enum(["verified", "rejected"]),
        reviewNotes: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      const doc = await db.query.kycDocuments.findFirst({
        where: eq(kycDocuments.id, input.documentId),
      });

      if (!doc) throw new Error("Document not found");

      await db
        .update(kycDocuments)
        .set({
          status: input.status,
          reviewNotes: input.reviewNotes,
          reviewedBy: ctx.user.id,
          reviewedAt: new Date(),
        })
        .where(eq(kycDocuments.id, input.documentId));

      if (input.status === "verified") {
        const user = await db.query.users.findFirst({
          where: eq(users.id, doc.userId),
        });

        let newTier = user?.tier || "tier1";
        if (newTier === "tier1") newTier = "tier2";
        else if (newTier === "tier2") newTier = "tier3";

        await db
          .update(users)
          .set({
            kycStatus: "verified",
            tier: newTier as any,
            updatedAt: new Date(),
          })
          .where(eq(users.id, doc.userId));

        // Send email notification
        const targetUser = await db.query.users.findFirst({
          where: eq(users.id, doc.userId),
        });
        if (targetUser?.email) {
          const template = getKycVerifiedEmailTemplate(
            targetUser.name || "User",
            newTier
          );
          await sendEmail({ to: targetUser.email, ...template });
        }
      }

      return { success: true };
    }),
});

function getTierLimits(tier: string) {
  const limits = {
    tier1: { daily: 50000, maxBalance: 300000, singleTransaction: 10000 },
    tier2: { daily: 200000, maxBalance: 500000, singleTransaction: 50000 },
    tier3: { daily: 5000000, maxBalance: -1, singleTransaction: 1000000 },
  };
  return limits[tier as keyof typeof limits] || limits.tier1;
}
