import { z } from "zod";
import { createRouter, adminQuery, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  users,
  transactions,
  wallets,
  savingsGoals,
  kycDocuments,
  airtimePurchases,
  billsPayments,
} from "@db/schema";
import { eq, desc, and, count, sum } from "drizzle-orm";

export const adminRouter = createRouter({
  getDashboardStats: adminQuery.query(async () => {
    const db = getDb();

    const [
      userCount,
      totalBalance,
      txCount,
      totalTxVolume,
      pendingKyc,
      savingsTotal,
      airtimeTotal,
      billsTotal,
    ] = await Promise.all([
      db.select({ count: count() }).from(users),
      db.select({ total: sum(wallets.balance) }).from(wallets),
      db.select({ count: count() }).from(transactions),
      db
        .select({ total: sum(transactions.amount) })
        .from(transactions)
        .where(eq(transactions.status, "successful")),
      db
        .select({ count: count() })
        .from(kycDocuments)
        .where(eq(kycDocuments.status, "submitted")),
      db.select({ total: sum(savingsGoals.currentAmount) }).from(savingsGoals),
      db.select({ total: sum(airtimePurchases.amount) }).from(airtimePurchases),
      db.select({ total: sum(billsPayments.amount) }).from(billsPayments),
    ]);

    const recentTransactions = await db.query.transactions.findMany({
      orderBy: [desc(transactions.createdAt)],
      limit: 10,
      with: { user: true },
    });

    const tierDistribution = await db
      .select({
        tier: users.tier,
        count: count(),
      })
      .from(users)
      .groupBy(users.tier);

    return {
      users: {
        total: userCount[0]?.count || 0,
        tierDistribution,
      },
      wallets: {
        totalBalance: totalBalance[0]?.total || "0.00",
      },
      transactions: {
        total: txCount[0]?.count || 0,
        totalVolume: totalTxVolume[0]?.total || "0.00",
        recent: recentTransactions,
      },
      kyc: {
        pending: pendingKyc[0]?.count || 0,
      },
      savings: {
        total: savingsTotal[0]?.total || "0.00",
      },
      airtime: {
        total: airtimeTotal[0]?.total || "0.00",
      },
      bills: {
        total: billsTotal[0]?.total || "0.00",
      },
    };
  }),

  getUsers: adminQuery
    .input(
      z.object({
        limit: z.number().min(1).max(100).default(20),
        offset: z.number().min(0).default(0),
        search: z.string().optional(),
        tier: z.string().optional(),
        kycStatus: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input.tier) conditions.push(eq(users.tier, input.tier as any));
      if (input.kycStatus) conditions.push(eq(users.kycStatus, input.kycStatus as any));

      const userList = await db.query.users.findMany({
        where: conditions.length > 0 ? and(...conditions) : undefined,
        orderBy: [desc(users.createdAt)],
        limit: input.limit,
        offset: input.offset,
        with: {
          wallet: true,
          kycDocuments: true,
        },
      });

      const total = await db
        .select({ count: count() })
        .from(users)
        .where(conditions.length > 0 ? and(...conditions) : undefined);

      return { users: userList, total: total[0]?.count || 0 };
    }),

  getUserDetails: adminQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const user = await db.query.users.findFirst({
        where: eq(users.id, input.id),
        with: {
          wallet: true,
          transactions: { limit: 20, orderBy: [desc(transactions.createdAt)] },
          kycDocuments: true,
          savingsGoals: true,
          cards: true,
          bankAccounts: true,
          beneficiaries: true,
        },
      });

      if (!user) throw new Error("User not found");
      return user;
    }),

  updateUserTier: adminQuery
    .input(
      z.object({
        userId: z.number(),
        tier: z.enum(["tier1", "tier2", "tier3"]),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(users)
        .set({ tier: input.tier, updatedAt: new Date() })
        .where(eq(users.id, input.userId));
      return { success: true };
    }),

  getTransactions: adminQuery
    .input(
      z.object({
        limit: z.number().min(1).max(100).default(20),
        offset: z.number().min(0).default(0),
        status: z.string().optional(),
        type: z.string().optional(),
        userId: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input.status) conditions.push(eq(transactions.status, input.status as any));
      if (input.type) conditions.push(eq(transactions.type, input.type as any));
      if (input.userId) conditions.push(eq(transactions.userId, input.userId));

      const txList = await db.query.transactions.findMany({
        where: conditions.length > 0 ? and(...conditions) : undefined,
        orderBy: [desc(transactions.createdAt)],
        limit: input.limit,
        offset: input.offset,
        with: { user: true },
      });

      const total = await db
        .select({ count: count() })
        .from(transactions)
        .where(conditions.length > 0 ? and(...conditions) : undefined);

      return { transactions: txList, total: total[0]?.count || 0 };
    }),

  getKycReviews: adminQuery
    .input(
      z.object({
        limit: z.number().min(1).max(100).default(20),
        offset: z.number().min(0).default(0),
        status: z.string().optional(),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input.status) conditions.push(eq(kycDocuments.status, input.status as any));

      const docs = await db.query.kycDocuments.findMany({
        where: conditions.length > 0 ? and(...conditions) : undefined,
        orderBy: [desc(kycDocuments.createdAt)],
        limit: input.limit,
        offset: input.offset,
        with: { user: true },
      });

      const total = await db
        .select({ count: count() })
        .from(kycDocuments)
        .where(conditions.length > 0 ? and(...conditions) : undefined);

      return { documents: docs, total: total[0]?.count || 0 };
    }),

  adminStats: publicQuery.query(async () => {
    const db = getDb();

    const stats = await Promise.all([
      db.select({ count: count() }).from(users),
      db.select({ total: sum(transactions.amount) }).from(transactions).where(eq(transactions.status, "successful")),
      db.select({ count: count() }).from(transactions).where(eq(transactions.status, "successful")),
      db.select({ count: count() }).from(savingsGoals),
      db.select({ count: count() }).from(kycDocuments).where(eq(kycDocuments.status, "submitted")),
    ]);

    return {
      totalUsers: stats[0][0]?.count || 0,
      totalVolume: stats[1][0]?.total || "0.00",
      totalTransactions: stats[2][0]?.count || 0,
      totalSavingsGoals: stats[3][0]?.count || 0,
      pendingKyc: stats[4][0]?.count || 0,
    };
  }),
});
